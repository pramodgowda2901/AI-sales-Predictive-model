/**
 * Authentication API Endpoints
 * Handles signup, login, password reset, and validation
 */

import express, { Request, Response } from 'express'
import crypto from 'crypto'

const router = express.Router()

// In-memory user store (replace with database in production)
const users: Map<string, any> = new Map()
const resetTokens: Map<string, any> = new Map()

// Password validation rules
const validatePassword = (password: string): { valid: boolean; errors: string[] } => {
  const errors: string[] = []

  if (password.length < 8) {
    errors.push('Password must be at least 8 characters long')
  }
  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter')
  }
  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter')
  }
  if (!/[0-9]/.test(password)) {
    errors.push('Password must contain at least one number')
  }
  if (!/[!@#$%^&*]/.test(password)) {
    errors.push('Password must contain at least one special character (!@#$%^&*)')
  }

  return {
    valid: errors.length === 0,
    errors,
  }
}

// Hash password (simple implementation - use bcrypt in production)
const hashPassword = (password: string): string => {
  return crypto.createHash('sha256').update(password).digest('hex')
}

// Generate JWT token (simple implementation - use jsonwebtoken in production)
const generateToken = (userId: string): string => {
  return crypto.randomBytes(32).toString('hex')
}

// SIGNUP endpoint
router.post('/signup', (req: Request, res: Response) => {
  const { email, password, fullName, company } = req.body

  // Validation
  if (!email || !password || !fullName) {
    return res.status(400).json({
      success: false,
      message: 'Email, password, and full name are required',
    })
  }

  // Check if user exists
  if (users.has(email)) {
    return res.status(409).json({
      success: false,
      message: 'Email already registered',
    })
  }

  // Validate password
  const passwordValidation = validatePassword(password)
  if (!passwordValidation.valid) {
    return res.status(400).json({
      success: false,
      message: 'Password does not meet requirements',
      errors: passwordValidation.errors,
    })
  }

  // Create user
  const userId = crypto.randomUUID()
  const user = {
    id: userId,
    email,
    password: hashPassword(password),
    fullName,
    company,
    tier: 'starter',
    createdAt: new Date(),
    verified: false,
  }

  users.set(email, user)

  // Generate token
  const token = generateToken(userId)

  res.status(201).json({
    success: true,
    message: 'Account created successfully',
    user: {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      tier: user.tier,
    },
    token,
  })
})

// LOGIN endpoint
router.post('/login', (req: Request, res: Response) => {
  const { email, password } = req.body

  if (!email || !password) {
    return res.status(400).json({
      success: false,
      message: 'Email and password are required',
    })
  }

  const user = users.get(email)
  if (!user) {
    return res.status(401).json({
      success: false,
      message: 'Invalid email or password',
    })
  }

  // Check password
  if (user.password !== hashPassword(password)) {
    return res.status(401).json({
      success: false,
      message: 'Invalid email or password',
    })
  }

  // Generate token
  const token = generateToken(user.id)

  res.json({
    success: true,
    message: 'Login successful',
    user: {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      tier: user.tier,
    },
    token,
  })
})

// FORGOT PASSWORD endpoint
router.post('/forgot-password', (req: Request, res: Response) => {
  const { email } = req.body

  if (!email) {
    return res.status(400).json({
      success: false,
      message: 'Email is required',
    })
  }

  const user = users.get(email)
  if (!user) {
    // Don't reveal if email exists (security best practice)
    return res.json({
      success: true,
      message: 'If email exists, password reset link has been sent',
    })
  }

  // Generate reset token
  const resetToken = crypto.randomBytes(32).toString('hex')
  const resetTokenHash = hashPassword(resetToken)

  resetTokens.set(resetTokenHash, {
    email,
    expiresAt: new Date(Date.now() + 3600000), // 1 hour
  })

  // In production, send email with reset link
  console.log(`Password reset token for ${email}: ${resetToken}`)

  res.json({
    success: true,
    message: 'Password reset link sent to email',
    // For demo purposes, return token (remove in production)
    resetToken,
  })
})

// RESET PASSWORD endpoint
router.post('/reset-password', (req: Request, res: Response) => {
  const { resetToken, newPassword } = req.body

  if (!resetToken || !newPassword) {
    return res.status(400).json({
      success: false,
      message: 'Reset token and new password are required',
    })
  }

  // Validate password
  const passwordValidation = validatePassword(newPassword)
  if (!passwordValidation.valid) {
    return res.status(400).json({
      success: false,
      message: 'Password does not meet requirements',
      errors: passwordValidation.errors,
    })
  }

  const resetTokenHash = hashPassword(resetToken)
  const tokenData = resetTokens.get(resetTokenHash)

  if (!tokenData) {
    return res.status(400).json({
      success: false,
      message: 'Invalid or expired reset token',
    })
  }

  if (new Date() > tokenData.expiresAt) {
    resetTokens.delete(resetTokenHash)
    return res.status(400).json({
      success: false,
      message: 'Reset token has expired',
    })
  }

  // Update password
  const user = users.get(tokenData.email)
  if (user) {
    user.password = hashPassword(newPassword)
    users.set(tokenData.email, user)
  }

  resetTokens.delete(resetTokenHash)

  res.json({
    success: true,
    message: 'Password reset successfully',
  })
})

// VALIDATE PASSWORD endpoint
router.post('/validate-password', (req: Request, res: Response) => {
  const { password } = req.body

  if (!password) {
    return res.status(400).json({
      success: false,
      message: 'Password is required',
    })
  }

  const validation = validatePassword(password)

  res.json({
    success: validation.valid,
    valid: validation.valid,
    errors: validation.errors,
  })
})

// CHANGE PASSWORD endpoint
router.post('/change-password', (req: Request, res: Response) => {
  const { email, currentPassword, newPassword } = req.body

  if (!email || !currentPassword || !newPassword) {
    return res.status(400).json({
      success: false,
      message: 'Email, current password, and new password are required',
    })
  }

  const user = users.get(email)
  if (!user) {
    return res.status(401).json({
      success: false,
      message: 'User not found',
    })
  }

  // Verify current password
  if (user.password !== hashPassword(currentPassword)) {
    return res.status(401).json({
      success: false,
      message: 'Current password is incorrect',
    })
  }

  // Validate new password
  const passwordValidation = validatePassword(newPassword)
  if (!passwordValidation.valid) {
    return res.status(400).json({
      success: false,
      message: 'New password does not meet requirements',
      errors: passwordValidation.errors,
    })
  }

  // Update password
  user.password = hashPassword(newPassword)
  users.set(email, user)

  res.json({
    success: true,
    message: 'Password changed successfully',
  })
})

export default router
