// Self-contained mock data for the backend server

export interface Deal {
  id: string
  name: string
  value: number
  stage: string
  winProbability: number
  closeDate: string
  accountName: string
  contact: string
  email: string
  phone: string
  createdAt: string
  updatedAt: string
  signals: any[]
}

export interface Forecast {
  id: string
  horizon: string
  projectedValue: number
  confidenceLow: number
  confidenceHigh: number
  periodStart: string
  periodEnd: string
  createdAt: string
}

export interface Insight {
  id: string
  dealId: string
  type: string
  text: string
  revenueImpact: number
  status: string
  dismissedUntil?: string
  createdAt: string
}

export interface BillingInfo {
  currentTier: string
  monthlyPrice: number
  nextBillingDate: string
  status: string
  usageMetrics: {
    apiRequests: number
    predictions: number
    users: number
    deals: number
  }
  tierLimits: {
    maxUsers: number
    maxDeals: number
    maxApiRequests: number
  }
}

const stages = ['Prospecting', 'Qualification', 'Proposal', 'Negotiation', 'Closed Won']
const companies = ['Acme Corp', 'TechVision Inc', 'Global Solutions', 'Digital Dynamics', 'CloudFirst Systems', 'DataFlow Analytics', 'NextGen Software', 'Enterprise Plus', 'Innovation Labs', 'Future Tech']
const contacts = ['John Smith', 'Sarah Johnson', 'Michael Chen', 'Emily Davis', 'Robert Wilson', 'Jessica Martinez', 'David Brown', 'Lisa Anderson']
const signalTypes = ['Email Opened', 'Link Clicked', 'Demo Attended', 'Proposal Viewed', 'Call Scheduled', 'Document Downloaded']

function rnd<T>(arr: T[]): T { return arr[Math.floor(Math.random() * arr.length)] }
function rndNum(min: number, max: number): number { return Math.floor(Math.random() * (max - min + 1)) + min }
function rndDate(daysAgo = 90): string { const d = new Date(); d.setDate(d.getDate() - rndNum(0, daysAgo)); return d.toISOString() }
function rndFuture(days = 90): string { const d = new Date(); d.setDate(d.getDate() + rndNum(1, days)); return d.toISOString() }

function makeDeals(count = 25): Deal[] {
  return Array.from({ length: count }, (_, i) => {
    const stage = rnd(stages)
    const wp = stage === 'Closed Won' ? 100 : stage === 'Prospecting' ? rndNum(5, 25) : rndNum(25, 85)
    return {
      id: `deal-${i + 1}`,
      name: `${rnd(companies)} - ${rndNum(10, 500)}k Deal`,
      value: rndNum(50000, 500000),
      stage,
      winProbability: wp,
      closeDate: rndFuture(120),
      accountName: rnd(companies),
      contact: rnd(contacts),
      email: `contact${i + 1}@example.com`,
      phone: `+1-555-${rndNum(100, 999)}-${rndNum(1000, 9999)}`,
      createdAt: rndDate(180),
      updatedAt: rndDate(30),
      signals: Array.from({ length: rndNum(3, 6) }, (_, j) => ({
        id: `sig-${i}-${j}`,
        dealId: `deal-${i + 1}`,
        type: rnd(signalTypes),
        value: `Signal ${j + 1}`,
        timestamp: rndDate(30),
        source: rnd(['Email', 'Website', 'CRM', 'Calendar']),
      })),
    }
  })
}

function makeForecasts(count = 12): Forecast[] {
  const now = new Date()
  return Array.from({ length: count }, (_, i) => {
    const start = new Date(now.getFullYear(), now.getMonth() + i, 1)
    const end = new Date(now.getFullYear(), now.getMonth() + i + 1, 0)
    const base = rndNum(500000, 2000000)
    return {
      id: `forecast-${i}`,
      horizon: i < 4 ? 'weekly' : i < 8 ? 'monthly' : 'quarterly',
      projectedValue: base,
      confidenceLow: base - 150000,
      confidenceHigh: base + 150000,
      periodStart: start.toISOString(),
      periodEnd: end.toISOString(),
      createdAt: new Date().toISOString(),
    }
  })
}

function makeInsights(deals: Deal[], count = 15): Insight[] {
  const types = ['Stalled Deal', 'High Win Probability', 'Engagement Spike', 'Next Best Action', 'Timeline Risk']
  const actions = ['Schedule follow-up call', 'Send proposal', 'Check in with stakeholder', 'Review pricing']
  return Array.from({ length: count }, (_, i) => {
    const deal = rnd(deals)
    const type = rnd(types)
    return {
      id: `insight-${i + 1}`,
      dealId: deal.id,
      type,
      text: `${type} detected for ${deal.name}. Recommended: ${rnd(actions)}`,
      revenueImpact: rndNum(10000, 200000),
      status: rnd(['active', 'active', 'active', 'acted', 'dismissed']),
      createdAt: rndDate(30),
    }
  }).sort((a, b) => b.revenueImpact - a.revenueImpact)
}

export const mockDeals: Deal[] = makeDeals(25)
export const mockForecasts: Forecast[] = makeForecasts(12)
export const mockInsights: Insight[] = makeInsights(mockDeals, 15)
export const mockBillingInfo: BillingInfo = {
  currentTier: 'starter',
  monthlyPrice: 99,
  nextBillingDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
  status: 'active',
  usageMetrics: { apiRequests: 4230, predictions: 312, users: 3, deals: 25 },
  tierLimits: { maxUsers: 5, maxDeals: 100, maxApiRequests: 10000 },
}

export function getMockPredictionsForDeal(dealId: string) {
  let base = rndNum(20, 80)
  return Array.from({ length: 12 }, (_, i) => {
    const prob = Math.max(0, Math.min(100, base + rndNum(-15, 15)))
    base = prob
    return {
      id: `pred-${dealId}-${i}`,
      dealId,
      winProbability: prob,
      confidenceLow: Math.max(0, prob - 15),
      confidenceHigh: Math.min(100, prob + 15),
      topFactors: ['Deal Age', 'Engagement Score', 'Stage Velocity', 'Historical Close Rate', 'Contact Seniority'],
      computedAt: new Date(Date.now() - (12 - i) * 7 * 24 * 60 * 60 * 1000).toISOString(),
    }
  })
}

export function getMockPipelineView() {
  return stages.map((stage) => ({
    stage,
    deals: mockDeals.filter((d) => d.stage === stage),
    totalValue: mockDeals.filter((d) => d.stage === stage).reduce((s, d) => s + d.value, 0),
    dealCount: mockDeals.filter((d) => d.stage === stage).length,
  }))
}

export function getMockFunnelData() {
  return stages.map((stage) => {
    const sd = mockDeals.filter((d) => d.stage === stage)
    return { stage, value: sd.reduce((s, d) => s + d.value, 0), count: sd.length }
  })
}

export function getMockHeatmapData() {
  const users = ['Alice Johnson', 'Bob Smith', 'Carol White', 'David Brown', 'Emma Davis']
  return users.map((user) => ({
    user,
    stages: stages.map((stage) => ({ stage, probability: rndNum(20, 90), dealCount: rndNum(1, 5) })),
  }))
}
