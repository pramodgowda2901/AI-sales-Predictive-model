/**
 * Dashboard Server - Simple HTTP Server
 * Serves the system dashboard on port 9000
 */

const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 9000;

// Serve static files
app.use(express.static(path.join(__dirname, '../frontend/public')));

// Dashboard route
app.get('/', (req, res) => {
  const dashboardPath = path.join(__dirname, '../frontend/public/system-dashboard.html');
  if (fs.existsSync(dashboardPath)) {
    res.sendFile(dashboardPath);
  } else {
    res.send('<h1>Dashboard not found</h1>');
  }
});

// API status endpoint
app.get('/api/status', (req, res) => {
  res.json({
    frontend: {
      url: 'http://localhost:3000',
      status: 'running',
      framework: 'React 18 + TypeScript'
    },
    backend: {
      url: 'http://localhost:8000',
      status: 'running',
      framework: 'Express.js + TypeScript'
    },
    dashboard: {
      url: 'http://localhost:9000',
      status: 'running'
    },
    timestamp: new Date().toISOString()
  });
});

app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║         SYSTEM DASHBOARD SERVER                           ║
║         Running on http://localhost:${PORT}                 ║
║                                                            ║
║  Open your browser and navigate to:                       ║
║  👉 http://localhost:${PORT}                                ║
║                                                            ║
║  You will see:                                            ║
║  ✅ Frontend Status (http://localhost:3000)              ║
║  ✅ Mock API Status (http://localhost:8000)              ║
║  ✅ All Services Overview                                ║
║  ✅ API Endpoints                                        ║
║  ✅ Technology Stack                                     ║
║  ✅ Project Statistics                                   ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
  `);
});
