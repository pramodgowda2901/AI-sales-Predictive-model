/**
 * Mock API Server for AI Sales Predictive Management Platform
 * Serves mock data for frontend development and testing
 * Run with: npx ts-node backend/mock-api.ts
 */

import express, { Express, Request, Response } from 'express'
import cors from 'cors'
import crypto from 'crypto'
import {
  mockDeals,
  mockForecasts,
  mockInsights,
  mockBillingInfo,
  getMockPredictionsForDeal,
  getMockPipelineView,
  getMockFunnelData,
  getMockHeatmapData,
  Deal,
} from './mock-data'

const app: Express = express()
const PORT = process.env.PORT || 8000

// In-memory stores for auth
const users: Map<string, any> = new Map()
const resetTokens: Map<string, any> = new Map()
const paymentSessions: Map<string, any> = new Map()

// ============ AUTHENTICATION ENDPOINTS ============
app.use(cors())
app.use(express.json())

// Request logging
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} ${req.method} ${req.path}`)
  next()
})

// ============ PASSWORD VALIDATION ============

const validatePassword = (password: string): { valid: boolean; errors: string[] } => {
  const errors: string[] = []

  if (password.length < 8) {
    errors.push('Password must be at least 8 characters long')
  }
  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter')
  }
  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter')
  }
  if (!/[0-9]/.test(password)) {
    errors.push('Password must contain at least one number')
  }
  if (!/[!@#$%^&*]/.test(password)) {
    errors.push('Password must contain at least one special character (!@#$%^&*)')
  }

  return {
    valid: errors.length === 0,
    errors,
  }
}

const hashPassword = (password: string): string => {
  return crypto.createHash('sha256').update(password).digest('hex')
}

const generateToken = (_userId: string): string => {
  return crypto.randomBytes(32).toString('hex')
}

// Seed demo user on startup
users.set('demo@example.com', {
  id: 'demo-user-id',
  email: 'demo@example.com',
  password: hashPassword('demo123'),
  fullName: 'Demo User',
  company: 'Demo Corp',
  tier: 'starter',
  createdAt: new Date(),
  verified: true,
})

// ============ AUTHENTICATION ENDPOINTS ============

app.post('/api/v1/auth/signup', (req: Request, res: Response) => {
  const { email, password, fullName, company } = req.body

  if (!email || !password || !fullName) {
    return res.status(400).json({
      success: false,
      message: 'Email, password, and full name are required',
    })
  }

  if (users.has(email)) {
    return res.status(409).json({
      success: false,
      message: 'Email already registered',
    })
  }

  const passwordValidation = validatePassword(password)
  if (!passwordValidation.valid) {
    return res.status(400).json({
      success: false,
      message: 'Password does not meet requirements',
      errors: passwordValidation.errors,
    })
  }

  const userId = crypto.randomUUID()
  const user = {
    id: userId,
    email,
    password: hashPassword(password),
    fullName,
    company,
    tier: 'starter',
    createdAt: new Date(),
    verified: false,
  }

  users.set(email, user)

  const token = generateToken(userId)

  res.status(201).json({
    success: true,
    message: 'Account created successfully',
    user: {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      tier: user.tier,
    },
    token,
  })
})

app.post('/api/v1/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body

  if (!email || !password) {
    return res.status(400).json({
      success: false,
      message: 'Email and password are required',
    })
  }

  const user = users.get(email)
  if (!user) {
    return res.status(401).json({
      success: false,
      message: 'Invalid email or password',
    })
  }

  if (user.password !== hashPassword(password)) {
    return res.status(401).json({
      success: false,
      message: 'Invalid email or password',
    })
  }

  const token = generateToken(user.id)

  res.json({
    success: true,
    message: 'Login successful',
    user: {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      tier: user.tier,
    },
    token,
  })
})

app.post('/api/v1/auth/forgot-password', (req: Request, res: Response) => {
  const { email } = req.body

  if (!email) {
    return res.status(400).json({
      success: false,
      message: 'Email is required',
    })
  }

  const user = users.get(email)
  if (!user) {
    return res.json({
      success: true,
      message: 'If email exists, password reset link has been sent',
    })
  }

  const resetToken = crypto.randomBytes(32).toString('hex')
  const resetTokenHash = hashPassword(resetToken)

  resetTokens.set(resetTokenHash, {
    email,
    expiresAt: new Date(Date.now() + 3600000),
  })

  console.log(`Password reset token for ${email}: ${resetToken}`)

  res.json({
    success: true,
    message: 'Password reset link sent to email',
    resetToken,
  })
})

app.post('/api/v1/auth/reset-password', (req: Request, res: Response) => {
  const { resetToken, newPassword } = req.body

  if (!resetToken || !newPassword) {
    return res.status(400).json({
      success: false,
      message: 'Reset token and new password are required',
    })
  }

  const passwordValidation = validatePassword(newPassword)
  if (!passwordValidation.valid) {
    return res.status(400).json({
      success: false,
      message: 'Password does not meet requirements',
      errors: passwordValidation.errors,
    })
  }

  const resetTokenHash = hashPassword(resetToken)
  const tokenData = resetTokens.get(resetTokenHash)

  if (!tokenData) {
    return res.status(400).json({
      success: false,
      message: 'Invalid or expired reset token',
    })
  }

  if (new Date() > tokenData.expiresAt) {
    resetTokens.delete(resetTokenHash)
    return res.status(400).json({
      success: false,
      message: 'Reset token has expired',
    })
  }

  const user = users.get(tokenData.email)
  if (user) {
    user.password = hashPassword(newPassword)
    users.set(tokenData.email, user)
  }

  resetTokens.delete(resetTokenHash)

  res.json({
    success: true,
    message: 'Password reset successfully',
  })
})

app.post('/api/v1/auth/validate-password', (req: Request, res: Response) => {
  const { password } = req.body

  if (!password) {
    return res.status(400).json({
      success: false,
      message: 'Password is required',
    })
  }

  const validation = validatePassword(password)

  res.json({
    success: validation.valid,
    valid: validation.valid,
    errors: validation.errors,
  })
})

// ============ PAYMENT ENDPOINTS ============

app.post('/api/v1/billing/payment-session', (req: Request, res: Response) => {
  const { email, tier, amount } = req.body

  if (!email || !tier || !amount) {
    return res.status(400).json({
      success: false,
      message: 'Email, tier, and amount are required',
    })
  }

  const sessionId = crypto.randomUUID()
  const paymentSession = {
    id: sessionId,
    email,
    tier,
    amount,
    status: 'pending',
    createdAt: new Date(),
    expiresAt: new Date(Date.now() + 900000), // 15 minutes
  }

  paymentSessions.set(sessionId, paymentSession)

  res.json({
    success: true,
    message: 'Payment session created',
    sessionId,
    clientSecret: `cs_${crypto.randomBytes(16).toString('hex')}`,
  })
})

app.post('/api/v1/billing/process-payment', (req: Request, res: Response) => {
  const { sessionId, cardToken, cardDetails } = req.body

  if (!sessionId || !cardToken) {
    return res.status(400).json({
      success: false,
      message: 'Session ID and card token are required',
    })
  }

  const session = paymentSessions.get(sessionId)
  if (!session) {
    return res.status(400).json({
      success: false,
      message: 'Invalid or expired payment session',
    })
  }

  if (new Date() > session.expiresAt) {
    paymentSessions.delete(sessionId)
    return res.status(400).json({
      success: false,
      message: 'Payment session has expired',
    })
  }

  // Simulate payment processing
  const isSuccessful = Math.random() > 0.1 // 90% success rate for demo

  if (isSuccessful) {
    session.status = 'completed'
    const user = users.get(session.email)
    if (user) {
      user.tier = session.tier
      users.set(session.email, user)
    }

    // Update billing info
    mockBillingInfo.currentTier = session.tier as any
    mockBillingInfo.monthlyPrice = session.amount
    mockBillingInfo.status = 'active'

    res.json({
      success: true,
      message: 'Payment processed successfully',
      transactionId: `txn_${crypto.randomBytes(16).toString('hex')}`,
      tier: session.tier,
      amount: session.amount,
    })
  } else {
    session.status = 'failed'
    res.status(402).json({
      success: false,
      message: 'Payment processing failed. Please try again.',
      code: 'PAYMENT_DECLINED',
    })
  }
})

app.get('/api/v1/billing/payment-session/:sessionId', (req: Request, res: Response) => {
  const session = paymentSessions.get(req.params.sessionId)

  if (!session) {
    return res.status(404).json({
      success: false,
      message: 'Payment session not found',
    })
  }

  res.json({
    success: true,
    session: {
      id: session.id,
      status: session.status,
      tier: session.tier,
      amount: session.amount,
    },
  })
})

// ============ DEALS ============

app.get('/api/v1/deals', (req: Request, res: Response) => {
  res.json(mockDeals)
})

app.post('/api/v1/deals', (req: Request, res: Response) => {
  const newDeal: Deal = {
    id: `deal-${Date.now()}`,
    name: req.body.name || 'New Deal',
    value: req.body.value || 0,
    stage: req.body.stage || 'Prospecting',
    winProbability: 25,
    closeDate: req.body.closeDate || new Date().toISOString(),
    accountName: req.body.accountName || '',
    contact: req.body.contact || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    signals: [],
  }
  mockDeals.push(newDeal)
  res.status(201).json(newDeal)
})

app.get('/api/v1/deals/:id', (req: Request, res: Response) => {
  const deal = mockDeals.find((d) => d.id === req.params.id)
  if (!deal) {
    return res.status(404).json({ error: 'Deal not found' })
  }
  res.json(deal)
})

app.put('/api/v1/deals/:id', (req: Request, res: Response) => {
  const index = mockDeals.findIndex((d) => d.id === req.params.id)
  if (index === -1) {
    return res.status(404).json({ error: 'Deal not found' })
  }
  mockDeals[index] = { ...mockDeals[index], ...req.body, updatedAt: new Date().toISOString() }
  res.json(mockDeals[index])
})

app.delete('/api/v1/deals/:id', (req: Request, res: Response) => {
  const index = mockDeals.findIndex((d) => d.id === req.params.id)
  if (index === -1) {
    return res.status(404).json({ error: 'Deal not found' })
  }
  mockDeals.splice(index, 1)
  res.status(204).send()
})

// ============ PIPELINE ============

app.get('/api/v1/pipeline', (req: Request, res: Response) => {
  res.json(getMockPipelineView())
})

app.get('/api/v1/pipeline/funnel', (req: Request, res: Response) => {
  res.json(getMockFunnelData())
})

app.get('/api/v1/pipeline/heatmap', (req: Request, res: Response) => {
  res.json(getMockHeatmapData())
})

// ============ PREDICTIONS ============

app.get('/api/v1/deals/:id/predictions', (req: Request, res: Response) => {
  res.json(getMockPredictionsForDeal(req.params.id))
})

// ============ FORECASTS ============

app.get('/api/v1/forecasts', (req: Request, res: Response) => {
  res.json(mockForecasts)
})

app.get('/api/v1/forecasts/:id', (req: Request, res: Response) => {
  const forecast = mockForecasts.find((f) => f.id === req.params.id)
  if (!forecast) {
    return res.status(404).json({ error: 'Forecast not found' })
  }
  res.json(forecast)
})

app.get('/api/v1/forecasts/:id/export', (req: Request, res: Response) => {
  const format = req.query.format || 'csv'
  const forecast = mockForecasts.find((f) => f.id === req.params.id)

  if (!forecast) {
    return res.status(404).json({ error: 'Forecast not found' })
  }

  if (format === 'csv') {
    res.setHeader('Content-Type', 'text/csv')
    res.setHeader('Content-Disposition', `attachment; filename="forecast-${req.params.id}.csv"`)
    const csv = `Period Start,Period End,Projected Value,Confidence Low,Confidence High\n${forecast.periodStart},${forecast.periodEnd},${forecast.projectedValue},${forecast.confidenceLow},${forecast.confidenceHigh}`
    res.send(csv)
  } else {
    res.setHeader('Content-Type', 'application/json')
    res.setHeader('Content-Disposition', `attachment; filename="forecast-${req.params.id}.json"`)
    res.json([forecast])
  }
})

// ============ INSIGHTS ============

app.get('/api/v1/insights', (req: Request, res: Response) => {
  res.json(mockInsights.filter((i) => i.status !== 'dismissed'))
})

app.put('/api/v1/insights/:id/act', (req: Request, res: Response) => {
  const insight = mockInsights.find((i) => i.id === req.params.id)
  if (!insight) {
    return res.status(404).json({ error: 'Insight not found' })
  }
  insight.status = 'acted'
  res.json(insight)
})

app.put('/api/v1/insights/:id/dismiss', (req: Request, res: Response) => {
  const insight = mockInsights.find((i) => i.id === req.params.id)
  if (!insight) {
    return res.status(404).json({ error: 'Insight not found' })
  }
  insight.status = 'dismissed'
  insight.dismissedUntil = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
  res.json(insight)
})

// ============ BILLING ============

app.get('/api/v1/billing', (req: Request, res: Response) => {
  res.json(mockBillingInfo)
})

app.put('/api/v1/billing/tier', (req: Request, res: Response) => {
  mockBillingInfo.currentTier = req.body.newTier
  res.json(mockBillingInfo)
})

// ============ PROFILE & USER MANAGEMENT ============

app.put('/api/v1/profile', (req: Request, res: Response) => {
  const { fullName, timezone, phone } = req.body
  res.json({ success: true, message: 'Profile updated', user: { fullName, timezone, phone } })
})

app.post('/api/v1/admin/users/invite', (req: Request, res: Response) => {
  const { email, role } = req.body
  if (!email || !role) {
    return res.status(400).json({ success: false, message: 'Email and role are required' })
  }
  res.json({ success: true, message: `Invitation sent to ${email}` })
})

app.get('/api/v1/admin/users', (req: Request, res: Response) => {
  res.json([
    { id: '1', email: 'john@example.com', fullName: 'John Doe', role: 'admin', status: 'active', createdAt: '2024-01-15', lastLogin: '2024-04-20' },
    { id: '2', email: 'jane@example.com', fullName: 'Jane Smith', role: 'manager', status: 'active', createdAt: '2024-02-01', lastLogin: '2024-04-19' },
    { id: '3', email: 'bob@example.com', fullName: 'Bob Johnson', role: 'sales_rep', status: 'active', createdAt: '2024-02-15', lastLogin: '2024-04-20' },
  ])
})

// ============ API KEYS ============

const apiKeys: Map<string, any> = new Map()

app.get('/api/v1/api-keys', (req: Request, res: Response) => {
  res.json(Array.from(apiKeys.values()))
})

app.post('/api/v1/api-keys', (req: Request, res: Response) => {
  const { name } = req.body
  if (!name) {
    return res.status(400).json({ success: false, message: 'Key name is required' })
  }
  const id = crypto.randomUUID()
  const key = `sk_live_${crypto.randomBytes(24).toString('hex')}`
  const newKey = {
    id,
    name,
    key,
    maskedKey: `sk_live_...${key.slice(-4)}`,
    createdAt: new Date().toISOString().split('T')[0],
    status: 'active',
  }
  apiKeys.set(id, newKey)
  res.status(201).json({ success: true, apiKey: newKey })
})

app.delete('/api/v1/api-keys/:id', (req: Request, res: Response) => {
  const key = apiKeys.get(req.params.id)
  if (!key) return res.status(404).json({ success: false, message: 'API key not found' })
  key.status = 'revoked'
  res.json({ success: true, message: 'API key revoked' })
})

// ============ NOTIFICATIONS ============

app.get('/api/v1/notifications', (req: Request, res: Response) => {
  res.json([
    { id: '1', type: 'deal_alert', message: 'Acme Corp deal probability dropped to 25%', read: false, createdAt: new Date().toISOString() },
    { id: '2', type: 'insight', message: 'New insight: TechVision deal stalled for 14 days', read: false, createdAt: new Date(Date.now() - 3600000).toISOString() },
    { id: '3', type: 'forecast', message: 'Q2 forecast generated: $2.5M projected', read: true, createdAt: new Date(Date.now() - 86400000).toISOString() },
  ])
})

app.put('/api/v1/notifications/preferences', (req: Request, res: Response) => {
  res.json({ success: true, message: 'Preferences updated' })
})

// ============ ANALYTICS ============

app.get('/api/v1/analytics', (req: Request, res: Response) => {
  res.json({
    totalPipelineValue: mockDeals.reduce((s, d) => s + d.value, 0),
    weightedPipelineValue: mockDeals.reduce((s, d) => s + d.value * (d.winProbability / 100), 0),
    averageDealCycle: 45,
    winRate: 32,
    forecastAccuracy: 87,
    activeDeals: mockDeals.filter((d) => d.stage !== 'Closed Won').length,
    closedDeals: mockDeals.filter((d) => d.stage === 'Closed Won').length,
  })
})

// ============ GDPR / DATA PRIVACY ============

app.post('/api/v1/admin/data-export', (req: Request, res: Response) => {
  res.json({
    success: true,
    message: 'Data export request submitted. You will receive an email with a download link within 72 hours.',
    requestId: crypto.randomUUID(),
    estimatedDelivery: new Date(Date.now() + 72 * 3600000).toISOString(),
  })
})

app.post('/api/v1/admin/data-delete', (req: Request, res: Response) => {
  res.json({
    success: true,
    message: 'Data deletion scheduled. All data will be permanently removed within 30 days.',
    requestId: crypto.randomUUID(),
    scheduledDeletion: new Date(Date.now() + 30 * 24 * 3600000).toISOString(),
  })
})

app.put('/api/v1/notifications/read-all', (req: Request, res: Response) => {
  res.json({ success: true, message: 'All notifications marked as read' })
})

// ============ HEALTH CHECK ============

app.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() })
})

// ============ ERROR HANDLING ============

app.use((req: Request, res: Response) => {
  res.status(404).json({ error: 'Not found' })
})

app.use((err: any, req: Request, res: Response) => {
  console.error('Error:', err)
  res.status(500).json({ error: 'Internal server error' })
})

// Start server
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════════════════╗
║  AI Sales Predictive Management - Mock API Server         ║
║  Running on http://localhost:${PORT}                        ║
║  Endpoints:                                                ║
║  - POST /api/v1/auth/signup                                ║
║  - POST /api/v1/auth/login                                 ║
║  - POST /api/v1/auth/forgot-password                        ║
║  - POST /api/v1/auth/reset-password                         ║
║  - POST /api/v1/auth/validate-password                      ║
║  - POST /api/v1/billing/payment-session                     ║
║  - POST /api/v1/billing/process-payment                     ║
║  - GET  /api/v1/deals                                      ║
║  - POST /api/v1/deals                                      ║
║  - GET  /api/v1/deals/:id                                  ║
║  - PUT  /api/v1/deals/:id                                  ║
║  - GET  /api/v1/pipeline                                   ║
║  - GET  /api/v1/forecasts                                  ║
║  - GET  /api/v1/insights                                   ║
║  - GET  /api/v1/billing                                    ║
║  - GET  /health                                            ║
╚════════════════════════════════════════════════════════════╝
  `)
})
