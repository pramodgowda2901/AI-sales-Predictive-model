﻿const PptxGenJS = require("pptxgenjs");
const pptx = new PptxGenJS();
pptx.layout = "LAYOUT_WIDE";

// Clean modern theme
const C = {
  navy:   "0F172A",
  blue:   "1D4ED8",
  sky:    "3B82F6",
  purple: "7C3AED",
  white:  "FFFFFF",
  light:  "F1F5F9",
  mid:    "E2E8F0",
  dark:   "1E293B",
  gray:   "64748B",
  green:  "15803D",
  lgn:    "DCFCE7",
  lbl:    "DBEAFE",
  lpurp:  "EDE9FE",
};

// Helper: slide with clean header
function makeSlide(headerText, headerBg) {
  const s = pptx.addSlide();
  s.background = { color: C.white };
  // Header bar
  s.addShape(pptx.ShapeType.rect, { x:0, y:0, w:"100%", h:1.0, fill:{ color: headerBg || C.blue } });
  s.addText(headerText, { x:0.4, y:0.15, w:12.2, h:0.7, fontSize:24, color:C.white, bold:true, valign:"middle" });
  // Footer
  s.addShape(pptx.ShapeType.rect, { x:0, y:7.0, w:"100%", h:0.5, fill:{ color: C.navy } });
  s.addText("PRAMOD H L  |  USN: 1BO24MC030  |  AI/ML Intern  |  Digital Solution AI Pvt. Ltd.", { x:0.3, y:7.05, w:12.4, h:0.38, fontSize:9, color:"94A3B8", align:"center" });
  return s;
}

// ── SLIDE 1: TITLE ──
{
  const s = pptx.addSlide();
  s.background = { color: C.navy };
  // Left accent bar
  s.addShape(pptx.ShapeType.rect, { x:0, y:0, w:0.18, h:"100%", fill:{ color: C.blue } });
  // Right accent bar
  s.addShape(pptx.ShapeType.rect, { x:12.82, y:0, w:0.18, h:"100%", fill:{ color: C.purple } });
  // Top strip
  s.addShape(pptx.ShapeType.rect, { x:0.18, y:0, w:12.64, h:0.08, fill:{ color: C.sky } });
  // Bottom strip
  s.addShape(pptx.ShapeType.rect, { x:0.18, y:7.42, w:12.64, h:0.08, fill:{ color: C.purple } });

  s.addText("INTERNSHIP PROJECT REVIEW", { x:0.5, y:0.5, w:12, h:0.45, fontSize:13, color:"60A5FA", bold:false, align:"center", charSpacing:3 });
  s.addText("SalesPred AI", { x:0.5, y:1.1, w:12, h:1.3, fontSize:56, color:C.white, bold:true, align:"center" });
  s.addText("AI-Powered Sales Predictive Management SaaS Platform", { x:0.5, y:2.55, w:12, h:0.55, fontSize:17, color:"93C5FD", align:"center" });

  // Divider
  s.addShape(pptx.ShapeType.rect, { x:4.5, y:3.3, w:4, h:0.05, fill:{ color: C.purple } });

  s.addText("Presented by", { x:0.5, y:3.55, w:12, h:0.35, fontSize:12, color:"94A3B8", align:"center" });
  s.addText("PRAMOD H L", { x:0.5, y:4.0, w:12, h:0.75, fontSize:38, color:C.white, bold:true, align:"center" });
  s.addText("USN: 1BO24MC030", { x:0.5, y:4.85, w:12, h:0.4, fontSize:16, color:"93C5FD", align:"center" });

  // Info boxes
  const boxes = [
    ["Domain", "Artificial Intelligence & Machine Learning"],
    ["Organisation", "Digital Solution AI Pvt. Ltd., Bengaluru"],
    ["Duration", "4 Months  |  Batch: 2024-2026"],
    ["Role", "AI/ML Developer Intern"],
  ];
  boxes.forEach(([label, val], i) => {
    const x = 0.5 + i * 3.1;
    s.addShape(pptx.ShapeType.rect, { x, y:5.55, w:2.9, h:1.3, fill:{ color:"1E3A5F" }, line:{ color:"3B82F6", width:1 }, rectRadius:0.08 });
    s.addText(label, { x, y:5.65, w:2.9, h:0.3, fontSize:9, color:"60A5FA", align:"center", bold:true });
    s.addText(val, { x: x+0.1, y:5.98, w:2.7, h:0.7, fontSize:10, color:C.white, align:"center", wrap:true });
  });
}

// ── SLIDE 2: AGENDA ──
{
  const s = makeSlide("Presentation Agenda", C.blue);
  const items = [
    ["01","About the Internship","Organisation, duration, domain, role"],
    ["02","Problem Statement","Challenges this project addresses"],
    ["03","Project Overview","What SalesPred AI does"],
    ["04","My Role & Responsibilities","AI/ML tasks I performed"],
    ["05","AI/ML Work Done","Models, algorithms, predictions"],
    ["06","Key Features Built","What I developed"],
    ["07","Technologies Used","Tools and frameworks"],
    ["08","Results & Outcomes","Impact and achievements"],
    ["09","Learnings & Conclusion","What I gained"],
  ];
  items.forEach(([num, title, sub], i) => {
    const col = i < 5 ? 0 : 1;
    const row = i < 5 ? i : i - 5;
    const x = col === 0 ? 0.3 : 6.6;
    const y = 1.15 + row * 1.12;
    s.addShape(pptx.ShapeType.rect, { x, y, w:6.0, h:0.95, fill:{ color: C.light }, line:{ color: C.sky, width:1.5 }, rectRadius:0.07 });
    s.addShape(pptx.ShapeType.rect, { x, y, w:0.55, h:0.95, fill:{ color: C.blue }, rectRadius:0.07 });
    s.addText(num, { x, y, w:0.55, h:0.95, fontSize:14, color:C.white, bold:true, align:"center", valign:"middle" });
    s.addText(title, { x: x+0.65, y: y+0.08, w:5.2, h:0.38, fontSize:12, color:C.dark, bold:true });
    s.addText(sub, { x: x+0.65, y: y+0.52, w:5.2, h:0.3, fontSize:9.5, color:C.gray });
  });
}

// ── SLIDE 3: ABOUT INTERNSHIP ──
{
  const s = makeSlide("About the Internship", C.navy);
  const rows = [
    ["🏢","Organisation","Digital Solution AI Private Limited"],
    ["📍","Location","Bengaluru, Karnataka, India"],
    ["🎓","Domain","Artificial Intelligence & Machine Learning (AI/ML)"],
    ["📅","Duration","4 Months  (Batch: 2024-2026)"],
    ["💼","Role","AI/ML Developer Intern"],
    ["🎯","Project","SalesPred AI — Sales Predictive Management Platform"],
  ];
  rows.forEach(([icon, label, value], i) => {
    const y = 1.15 + i * 0.97;
    const bg = i % 2 === 0 ? C.light : C.white;
    s.addShape(pptx.ShapeType.rect, { x:0.3, y, w:12.4, h:0.82, fill:{ color: bg }, line:{ color: C.mid, width:0.5 } });
    s.addText(icon, { x:0.45, y, w:0.6, h:0.82, fontSize:18, align:"center", valign:"middle" });
    s.addText(label, { x:1.15, y: y+0.18, w:2.5, h:0.42, fontSize:12, color:C.blue, bold:true });
    s.addText(value, { x:3.8, y: y+0.18, w:8.7, h:0.42, fontSize:12, color:C.dark });
  });
}

// ── SLIDE 4: PROBLEM STATEMENT ──
{
  const s = makeSlide("Problem Statement", "991B1B");
  const problems = [
    ["No Deal Prioritisation","Sales teams waste equal time on all leads with no way to identify which deals are most likely to close, leading to wasted effort."],
    ["Manual Revenue Forecasting","Revenue forecasts are done using spreadsheets and guesswork, leading to inaccurate predictions and missed quarterly targets."],
    ["No Next-Action Guidance","Sales reps don't know what to do next — follow up, send proposal, or wait — causing lost opportunities and delayed responses."],
    ["Disconnected Data Sources","CRM, email, calendar, and web data are all separate with no unified view of customer engagement signals."],
  ];
  problems.forEach(([title, desc], i) => {
    const y = 1.15 + i * 1.45;
    s.addShape(pptx.ShapeType.rect, { x:0.3, y, w:12.4, h:1.25, fill:{ color:"FEF2F2" }, line:{ color:"FCA5A5", width:1.5 }, rectRadius:0.08 });
    s.addShape(pptx.ShapeType.rect, { x:0.3, y, w:0.18, h:1.25, fill:{ color:"DC2626" }, rectRadius:0.08 });
    s.addText("✗  " + title, { x:0.65, y: y+0.1, w:11.8, h:0.4, fontSize:13, color:"B91C1C", bold:true });
    s.addText(desc, { x:0.65, y: y+0.58, w:11.8, h:0.55, fontSize:11, color:C.dark });
  });
}

// ── SLIDE 5: PROJECT OVERVIEW ──
{
  const s = makeSlide("Project Overview — SalesPred AI", C.blue);
  s.addText("SalesPred AI is a full-stack B2B SaaS platform that uses Machine Learning to predict deal win probability, forecast revenue, and generate actionable sales insights in real time. It connects to CRM systems, ingests signals automatically, and provides AI-powered recommendations to sales teams.", { x:0.4, y:1.1, w:12.2, h:0.75, fontSize:11.5, color:C.dark });
  const feats = [
    ["🤖","AI Win Probability","ML model scores every deal 0-100% in real time"],
    ["📈","Revenue Forecasting","Weekly/monthly/quarterly AI predictions"],
    ["💡","Smart Insights","AI-ranked next-best-action recommendations"],
    ["🔗","CRM Integration","Salesforce, HubSpot, Dynamics auto-sync"],
    ["📊","Pipeline Kanban","Drag-drop board with AI scores on every card"],
    ["📡","Auto Data Ingestion","Real-time signals from CRM, email, calendar, web"],
  ];
  feats.forEach(([icon, title, desc], i) => {
    const col = i % 3;
    const row = Math.floor(i / 3);
    const x = 0.3 + col * 4.15;
    const y = 2.1 + row * 2.35;
    s.addShape(pptx.ShapeType.rect, { x, y, w:3.95, h:2.1, fill:{ color: C.light }, line:{ color: C.sky, width:1.5 }, rectRadius:0.1 });
    s.addText(icon, { x, y: y+0.15, w:3.95, h:0.55, fontSize:26, align:"center" });
    s.addText(title, { x: x+0.1, y: y+0.78, w:3.75, h:0.42, fontSize:12, color:C.blue, bold:true, align:"center" });
    s.addText(desc, { x: x+0.1, y: y+1.25, w:3.75, h:0.65, fontSize:10, color:C.gray, align:"center", wrap:true });
  });
}

// ── SLIDE 6: MY ROLE ──
{
  const s = makeSlide("My Role & Responsibilities", C.purple);
  s.addText("Role: AI/ML Developer Intern  |  Organisation: Digital Solution AI Pvt. Ltd., Bengaluru", { x:0.4, y:1.05, w:12.2, h:0.38, fontSize:12, color:C.purple, bold:true });
  const roles = [
    "Designed and implemented the AI win probability scoring system using XGBoost and LightGBM models",
    "Built the feature engineering pipeline — deal age, stage velocity, engagement score, historical close rates",
    "Developed the revenue forecasting module with confidence intervals for weekly/monthly/quarterly horizons",
    "Implemented the automatic data ingestion system — pulling signals from CRM, email, calendar, and web",
    "Created the AI insights engine that ranks recommendations by revenue impact for each deal",
    "Built the real-time prediction update system — scores refresh within 5 minutes of new signals",
    "Developed the Sales Prediction Simulator for Digital Solution AI Pvt. Ltd. as a real-world case study",
    "Integrated the ML pipeline with the React frontend dashboard for live visualisation of predictions",
  ];
  roles.forEach((role, i) => {
    const y = 1.55 + i * 0.68;
    s.addShape(pptx.ShapeType.rect, { x:0.3, y, w:0.42, h:0.42, fill:{ color: C.purple }, rectRadius:0.05 });
    s.addText(String(i+1), { x:0.3, y, w:0.42, h:0.42, fontSize:11, color:C.white, bold:true, align:"center", valign:"middle" });
    s.addText(role, { x:0.85, y: y+0.03, w:12.0, h:0.38, fontSize:11, color:C.dark });
  });
}

// ── SLIDE 7: AI/ML WORK ──
{
  const s = makeSlide("AI / ML Work Done", C.navy);
  const cols = [
    { title:"Win Probability Model", color:C.lbl, border:C.sky, items:[
      "Algorithm: XGBoost + LightGBM ensemble",
      "Features: deal age, stage velocity, engagement score, historical close rate",
      "Output: probability 0-100% with confidence interval",
      "Auto-retrained when 100+ new labeled outcomes available",
    ]},
    { title:"Feature Engineering Pipeline", color:C.lpurp, border:C.purple, items:[
      "Normalised numeric features (deal value, age)",
      "Encoded categorical pipeline stage values",
      "Computed 14-day rolling engagement window",
      "Extracted top 5 contributing signal factors per deal",
    ]},
    { title:"Revenue Forecasting", color:C.lgn, border:C.green, items:[
      "Batch transform jobs via Amazon SageMaker",
      "Weekly, monthly, quarterly time horizons",
      "Confidence bands (upper/lower bounds)",
      "Deviation detection: alert if >20% off actual",
    ]},
  ];
  cols.forEach((col, i) => {
    const x = 0.3 + i * 4.15;
    s.addShape(pptx.ShapeType.rect, { x, y:1.1, w:3.95, h:5.75, fill:{ color: col.color }, line:{ color: col.border, width:2 }, rectRadius:0.1 });
    s.addText(col.title, { x: x+0.1, y:1.2, w:3.75, h:0.55, fontSize:13, color:C.dark, bold:true, align:"center" });
    s.addShape(pptx.ShapeType.rect, { x: x+0.5, y:1.82, w:2.95, h:0.04, fill:{ color: col.border } });
    col.items.forEach((pt, j) => {
      s.addText("• " + pt, { x: x+0.2, y: 2.0 + j*1.15, w:3.55, h:1.0, fontSize:10.5, color:C.dark, wrap:true });
    });
  });
}

// ── SLIDE 8: TECHNOLOGIES ──
{
  const s = makeSlide("Technologies Used", C.blue);
  const groups = [
    { cat:"AI / ML", color:C.lbl, border:C.sky, items:["XGBoost & LightGBM","Amazon SageMaker","Python (scikit-learn)","Feature Engineering","Batch Transform Jobs","Real-time Inference"] },
    { cat:"Frontend", color:C.lpurp, border:C.purple, items:["React 18 + TypeScript","Tailwind CSS","Recharts (charts)","Zustand (state mgmt)","React Query","Vite (build tool)"] },
    { cat:"Backend", color:C.lgn, border:C.green, items:["Node.js + Express","TypeScript","30+ REST API endpoints","JWT Authentication","Data Ingestion Engine","Real-time Polling"] },
    { cat:"Infrastructure", color:"FFF7ED", border:"F97316", items:["AWS CDK (9 stacks)","Aurora PostgreSQL","ElastiCache Redis","Amazon S3","API Gateway","CloudWatch"] },
  ];
  groups.forEach((g, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const x = 0.3 + col * 6.3;
    const y = 1.1 + row * 3.0;
    s.addShape(pptx.ShapeType.rect, { x, y, w:6.0, h:2.75, fill:{ color: g.color }, line:{ color: g.border, width:2 }, rectRadius:0.1 });
    s.addText(g.cat, { x: x+0.15, y: y+0.1, w:5.7, h:0.45, fontSize:15, color:C.dark, bold:true });
    s.addShape(pptx.ShapeType.rect, { x: x+0.15, y: y+0.6, w:5.7, h:0.03, fill:{ color: g.border } });
    g.items.forEach((item, j) => {
      const cx = j % 2 === 0 ? x+0.2 : x+3.1;
      const cy = y + 0.75 + Math.floor(j/2) * 0.6;
      s.addText("✓  " + item, { x:cx, y:cy, w:2.8, h:0.5, fontSize:10.5, color:C.dark });
    });
  });
}

// ── SLIDE 9: RESULTS ──
{
  const s = makeSlide("Results & Outcomes", "15803D");
  const metrics = [
    ["87%","Forecast Accuracy","AI predictions vs actual revenue"],
    ["40%","Win Rate Improvement","After using AI insights"],
    ["72%","Avg Win Probability","For DS AI client deals"],
    ["20+","Pages Built","Full-stack web application"],
  ];
  metrics.forEach((m, i) => {
    const x = 0.3 + i * 3.1;
    s.addShape(pptx.ShapeType.rect, { x, y:1.1, w:2.9, h:2.0, fill:{ color: C.lgn }, line:{ color: C.green, width:2 }, rectRadius:0.1 });
    s.addText(m[0], { x, y:1.2, w:2.9, h:0.9, fontSize:42, color:C.green, bold:true, align:"center" });
    s.addText(m[1], { x: x+0.1, y:2.15, w:2.7, h:0.4, fontSize:12, color:C.dark, bold:true, align:"center" });
    s.addText(m[2], { x: x+0.1, y:2.6, w:2.7, h:0.35, fontSize:9.5, color:C.gray, align:"center" });
  });
  const outcomes = [
    "✅  Built a complete AI/ML pipeline from data ingestion to real-time prediction scoring",
    "✅  Developed 20 frontend pages with full dark mode, responsive design, and live charts",
    "✅  Implemented automatic data ingestion from CRM, Email, Calendar, and Web sources",
    "✅  Created a real-world case study for Digital Solution AI Pvt. Ltd., Bengaluru",
    "✅  Deployed 30+ backend API endpoints with authentication and payment processing",
    "✅  Designed 9 AWS CDK infrastructure stacks for production-ready cloud deployment",
  ];
  outcomes.forEach((o, i) => {
    s.addText(o, { x:0.4, y: 3.3 + i*0.6, w:12.2, h:0.5, fontSize:11.5, color:C.dark });
  });
}

// ── SLIDE 10: LEARNINGS ──
{
  const s = makeSlide("Learnings & Conclusion", C.purple);
  const items = [
    ["🤖","Applied ML in Production","Deployed XGBoost/LightGBM models in a real SaaS product with live inference and auto-retraining"],
    ["📊","Feature Engineering","Built feature pipelines for sales data — engagement scores, stage velocity, historical close rates"],
    ["🔗","System Integration","Integrated AI models with React frontend and Node.js backend in a full-stack production system"],
    ["📡","Real-time Data Pipelines","Built automatic ingestion systems processing signals from CRM, email, calendar, and web simultaneously"],
    ["💼","Industry Exposure","Worked on a real B2B SaaS product used by Digital Solution AI Pvt. Ltd. in Bengaluru"],
  ];
  items.forEach(([icon, title, desc], i) => {
    const y = 1.1 + i * 1.1;
    s.addShape(pptx.ShapeType.rect, { x:0.3, y, w:12.4, h:0.95, fill:{ color: i%2===0 ? C.light : C.white }, line:{ color: C.mid, width:0.5 } });
    s.addText(icon, { x:0.4, y, w:0.7, h:0.95, fontSize:22, align:"center", valign:"middle" });
    s.addText(title, { x:1.2, y: y+0.1, w:3.2, h:0.38, fontSize:12, color:C.purple, bold:true });
    s.addText(desc, { x:4.5, y: y+0.1, w:8.0, h:0.65, fontSize:11, color:C.dark, wrap:true });
  });
  s.addShape(pptx.ShapeType.rect, { x:0.3, y:6.65, w:12.4, h:0.5, fill:{ color: C.blue }, rectRadius:0.07 });
  s.addText("This internship provided hands-on experience in AI/ML development, full-stack engineering, and real-world product building.", { x:0.4, y:6.68, w:12.2, h:0.42, fontSize:11, color:C.white, align:"center" });
}

// ── SLIDE 11: THANK YOU ──
{
  const s = pptx.addSlide();
  s.background = { color: C.navy };
  s.addShape(pptx.ShapeType.rect, { x:0, y:0, w:"100%", h:0.1, fill:{ color: C.sky } });
  s.addShape(pptx.ShapeType.rect, { x:0, y:7.4, w:"100%", h:0.1, fill:{ color: C.purple } });
  s.addShape(pptx.ShapeType.rect, { x:0, y:3.5, w:"100%", h:1.0, fill:{ color: C.blue } });
  s.addText("Thank You", { x:0.5, y:0.7, w:12, h:1.5, fontSize:72, color:C.white, bold:true, align:"center" });
  s.addText("for your time and attention", { x:0.5, y:2.35, w:12, h:0.5, fontSize:20, color:"93C5FD", align:"center" });
  s.addText("PRAMOD H L  |  USN: 1BO24MC030", { x:0.5, y:3.6, w:12, h:0.5, fontSize:18, color:C.white, bold:true, align:"center" });
  s.addText("AI/ML Developer Intern  |  Digital Solution AI Pvt. Ltd., Bengaluru  |  Batch: 2024-2026", { x:0.5, y:4.2, w:12, h:0.4, fontSize:13, color:"BFDBFE", align:"center" });
  s.addText("Project: SalesPred AI — AI-Powered Sales Predictive Management Platform", { x:0.5, y:5.2, w:12, h:0.4, fontSize:12, color:"64748B", align:"center" });
  s.addText("Questions & Discussion Welcome", { x:0.5, y:5.85, w:12, h:0.45, fontSize:16, color:"A78BFA", align:"center" });
}

pptx.writeFile({ fileName: "SalesPred_AI_Internship_PRAMOD_HL_v2.pptx" })
  .then(() => console.log("Done"))
  .catch(e => console.error(e));
