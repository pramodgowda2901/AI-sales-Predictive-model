"use strict";
/**
 * Mock API Server for AI Sales Predictive Management Platform
 * Serves mock data for frontend development and testing
 * Run with: npx ts-node backend/mock-api.ts
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
var express_1 = require("express");
var cors_1 = require("cors");
var crypto_1 = require("crypto");
var mockData_1 = require("../frontend/src/services/mockData");
var app = (0, express_1.default)();
var PORT = process.env.PORT || 8000;
// In-memory stores for auth
var users = new Map();
var resetTokens = new Map();
var paymentSessions = new Map();
// Middleware
app.use((0, cors_1.default)());
app.use(express_1.default.json());
// Request logging
app.use(function (req, res, next) {
    console.log("".concat(new Date().toISOString(), " ").concat(req.method, " ").concat(req.path));
    next();
});
// ============ PASSWORD VALIDATION ============
var validatePassword = function (password) {
    var errors = [];
    if (password.length < 8) {
        errors.push('Password must be at least 8 characters long');
    }
    if (!/[A-Z]/.test(password)) {
        errors.push('Password must contain at least one uppercase letter');
    }
    if (!/[a-z]/.test(password)) {
        errors.push('Password must contain at least one lowercase letter');
    }
    if (!/[0-9]/.test(password)) {
        errors.push('Password must contain at least one number');
    }
    if (!/[!@#$%^&*]/.test(password)) {
        errors.push('Password must contain at least one special character (!@#$%^&*)');
    }
    return {
        valid: errors.length === 0,
        errors: errors,
    };
};
var hashPassword = function (password) {
    return crypto_1.default.createHash('sha256').update(password).digest('hex');
};
var generateToken = function (userId) {
    return crypto_1.default.randomBytes(32).toString('hex');
};
// ============ AUTHENTICATION ENDPOINTS ============
app.post('/api/v1/auth/signup', function (req, res) {
    var _a = req.body, email = _a.email, password = _a.password, fullName = _a.fullName, company = _a.company;
    if (!email || !password || !fullName) {
        return res.status(400).json({
            success: false,
            message: 'Email, password, and full name are required',
        });
    }
    if (users.has(email)) {
        return res.status(409).json({
            success: false,
            message: 'Email already registered',
        });
    }
    var passwordValidation = validatePassword(password);
    if (!passwordValidation.valid) {
        return res.status(400).json({
            success: false,
            message: 'Password does not meet requirements',
            errors: passwordValidation.errors,
        });
    }
    var userId = crypto_1.default.randomUUID();
    var user = {
        id: userId,
        email: email,
        password: hashPassword(password),
        fullName: fullName,
        company: company,
        tier: 'starter',
        createdAt: new Date(),
        verified: false,
    };
    users.set(email, user);
    var token = generateToken(userId);
    res.status(201).json({
        success: true,
        message: 'Account created successfully',
        user: {
            id: user.id,
            email: user.email,
            fullName: user.fullName,
            tier: user.tier,
        },
        token: token,
    });
});
app.post('/api/v1/auth/login', function (req, res) {
    var _a = req.body, email = _a.email, password = _a.password;
    if (!email || !password) {
        return res.status(400).json({
            success: false,
            message: 'Email and password are required',
        });
    }
    var user = users.get(email);
    if (!user) {
        return res.status(401).json({
            success: false,
            message: 'Invalid email or password',
        });
    }
    if (user.password !== hashPassword(password)) {
        return res.status(401).json({
            success: false,
            message: 'Invalid email or password',
        });
    }
    var token = generateToken(user.id);
    res.json({
        success: true,
        message: 'Login successful',
        user: {
            id: user.id,
            email: user.email,
            fullName: user.fullName,
            tier: user.tier,
        },
        token: token,
    });
});
app.post('/api/v1/auth/forgot-password', function (req, res) {
    var email = req.body.email;
    if (!email) {
        return res.status(400).json({
            success: false,
            message: 'Email is required',
        });
    }
    var user = users.get(email);
    if (!user) {
        return res.json({
            success: true,
            message: 'If email exists, password reset link has been sent',
        });
    }
    var resetToken = crypto_1.default.randomBytes(32).toString('hex');
    var resetTokenHash = hashPassword(resetToken);
    resetTokens.set(resetTokenHash, {
        email: email,
        expiresAt: new Date(Date.now() + 3600000),
    });
    console.log("Password reset token for ".concat(email, ": ").concat(resetToken));
    res.json({
        success: true,
        message: 'Password reset link sent to email',
        resetToken: resetToken,
    });
});
app.post('/api/v1/auth/reset-password', function (req, res) {
    var _a = req.body, resetToken = _a.resetToken, newPassword = _a.newPassword;
    if (!resetToken || !newPassword) {
        return res.status(400).json({
            success: false,
            message: 'Reset token and new password are required',
        });
    }
    var passwordValidation = validatePassword(newPassword);
    if (!passwordValidation.valid) {
        return res.status(400).json({
            success: false,
            message: 'Password does not meet requirements',
            errors: passwordValidation.errors,
        });
    }
    var resetTokenHash = hashPassword(resetToken);
    var tokenData = resetTokens.get(resetTokenHash);
    if (!tokenData) {
        return res.status(400).json({
            success: false,
            message: 'Invalid or expired reset token',
        });
    }
    if (new Date() > tokenData.expiresAt) {
        resetTokens.delete(resetTokenHash);
        return res.status(400).json({
            success: false,
            message: 'Reset token has expired',
        });
    }
    var user = users.get(tokenData.email);
    if (user) {
        user.password = hashPassword(newPassword);
        users.set(tokenData.email, user);
    }
    resetTokens.delete(resetTokenHash);
    res.json({
        success: true,
        message: 'Password reset successfully',
    });
});
app.post('/api/v1/auth/validate-password', function (req, res) {
    var password = req.body.password;
    if (!password) {
        return res.status(400).json({
            success: false,
            message: 'Password is required',
        });
    }
    var validation = validatePassword(password);
    res.json({
        success: validation.valid,
        valid: validation.valid,
        errors: validation.errors,
    });
});
// ============ PAYMENT ENDPOINTS ============
app.post('/api/v1/billing/payment-session', function (req, res) {
    var _a = req.body, email = _a.email, tier = _a.tier, amount = _a.amount;
    if (!email || !tier || !amount) {
        return res.status(400).json({
            success: false,
            message: 'Email, tier, and amount are required',
        });
    }
    var sessionId = crypto_1.default.randomUUID();
    var paymentSession = {
        id: sessionId,
        email: email,
        tier: tier,
        amount: amount,
        status: 'pending',
        createdAt: new Date(),
        expiresAt: new Date(Date.now() + 900000), // 15 minutes
    };
    paymentSessions.set(sessionId, paymentSession);
    res.json({
        success: true,
        message: 'Payment session created',
        sessionId: sessionId,
        clientSecret: "cs_".concat(crypto_1.default.randomBytes(16).toString('hex')),
    });
});
app.post('/api/v1/billing/process-payment', function (req, res) {
    var _a = req.body, sessionId = _a.sessionId, cardToken = _a.cardToken, cardDetails = _a.cardDetails;
    if (!sessionId || !cardToken) {
        return res.status(400).json({
            success: false,
            message: 'Session ID and card token are required',
        });
    }
    var session = paymentSessions.get(sessionId);
    if (!session) {
        return res.status(400).json({
            success: false,
            message: 'Invalid or expired payment session',
        });
    }
    if (new Date() > session.expiresAt) {
        paymentSessions.delete(sessionId);
        return res.status(400).json({
            success: false,
            message: 'Payment session has expired',
        });
    }
    // Simulate payment processing
    var isSuccessful = Math.random() > 0.1; // 90% success rate for demo
    if (isSuccessful) {
        session.status = 'completed';
        var user = users.get(session.email);
        if (user) {
            user.tier = session.tier;
            users.set(session.email, user);
        }
        // Update billing info
        mockData_1.mockBillingInfo.currentTier = session.tier;
        mockData_1.mockBillingInfo.monthlyPrice = session.amount;
        mockData_1.mockBillingInfo.status = 'active';
        res.json({
            success: true,
            message: 'Payment processed successfully',
            transactionId: "txn_".concat(crypto_1.default.randomBytes(16).toString('hex')),
            tier: session.tier,
            amount: session.amount,
        });
    }
    else {
        session.status = 'failed';
        res.status(402).json({
            success: false,
            message: 'Payment processing failed. Please try again.',
            code: 'PAYMENT_DECLINED',
        });
    }
});
app.get('/api/v1/billing/payment-session/:sessionId', function (req, res) {
    var session = paymentSessions.get(req.params.sessionId);
    if (!session) {
        return res.status(404).json({
            success: false,
            message: 'Payment session not found',
        });
    }
    res.json({
        success: true,
        session: {
            id: session.id,
            status: session.status,
            tier: session.tier,
            amount: session.amount,
        },
    });
});
// ============ DEALS ============
app.get('/api/v1/deals', function (req, res) {
    res.json(mockData_1.mockDeals);
});
app.post('/api/v1/deals', function (req, res) {
    var newDeal = {
        id: "deal-".concat(Date.now()),
        name: req.body.name || 'New Deal',
        value: req.body.value || 0,
        stage: req.body.stage || 'Prospecting',
        winProbability: 25,
        closeDate: req.body.closeDate || new Date().toISOString(),
        accountName: req.body.accountName || '',
        contact: req.body.contact || '',
        email: req.body.email || '',
        phone: req.body.phone || '',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        signals: [],
    };
    mockData_1.mockDeals.push(newDeal);
    res.status(201).json(newDeal);
});
app.get('/api/v1/deals/:id', function (req, res) {
    var deal = mockData_1.mockDeals.find(function (d) { return d.id === req.params.id; });
    if (!deal) {
        return res.status(404).json({ error: 'Deal not found' });
    }
    res.json(deal);
});
app.put('/api/v1/deals/:id', function (req, res) {
    var index = mockData_1.mockDeals.findIndex(function (d) { return d.id === req.params.id; });
    if (index === -1) {
        return res.status(404).json({ error: 'Deal not found' });
    }
    mockData_1.mockDeals[index] = __assign(__assign(__assign({}, mockData_1.mockDeals[index]), req.body), { updatedAt: new Date().toISOString() });
    res.json(mockData_1.mockDeals[index]);
});
app.delete('/api/v1/deals/:id', function (req, res) {
    var index = mockData_1.mockDeals.findIndex(function (d) { return d.id === req.params.id; });
    if (index === -1) {
        return res.status(404).json({ error: 'Deal not found' });
    }
    mockData_1.mockDeals.splice(index, 1);
    res.status(204).send();
});
// ============ PIPELINE ============
app.get('/api/v1/pipeline', function (req, res) {
    res.json((0, mockData_1.getMockPipelineView)());
});
app.get('/api/v1/pipeline/funnel', function (req, res) {
    res.json((0, mockData_1.getMockFunnelData)());
});
app.get('/api/v1/pipeline/heatmap', function (req, res) {
    res.json((0, mockData_1.getMockHeatmapData)());
});
// ============ PREDICTIONS ============
app.get('/api/v1/deals/:id/predictions', function (req, res) {
    res.json((0, mockData_1.getMockPredictionsForDeal)(req.params.id));
});
// ============ FORECASTS ============
app.get('/api/v1/forecasts', function (req, res) {
    res.json(mockData_1.mockForecasts);
});
app.get('/api/v1/forecasts/:id', function (req, res) {
    var forecast = mockData_1.mockForecasts.find(function (f) { return f.id === req.params.id; });
    if (!forecast) {
        return res.status(404).json({ error: 'Forecast not found' });
    }
    res.json(forecast);
});
app.get('/api/v1/forecasts/:id/export', function (req, res) {
    var format = req.query.format || 'csv';
    var forecast = mockData_1.mockForecasts.find(function (f) { return f.id === req.params.id; });
    if (!forecast) {
        return res.status(404).json({ error: 'Forecast not found' });
    }
    if (format === 'csv') {
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', "attachment; filename=\"forecast-".concat(req.params.id, ".csv\""));
        var csv = "Period Start,Period End,Projected Value,Confidence Low,Confidence High\n".concat(forecast.periodStart, ",").concat(forecast.periodEnd, ",").concat(forecast.projectedValue, ",").concat(forecast.confidenceLow, ",").concat(forecast.confidenceHigh);
        res.send(csv);
    }
    else {
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Content-Disposition', "attachment; filename=\"forecast-".concat(req.params.id, ".json\""));
        res.json([forecast]);
    }
});
// ============ INSIGHTS ============
app.get('/api/v1/insights', function (req, res) {
    res.json(mockData_1.mockInsights.filter(function (i) { return i.status !== 'dismissed'; }));
});
app.put('/api/v1/insights/:id/act', function (req, res) {
    var insight = mockData_1.mockInsights.find(function (i) { return i.id === req.params.id; });
    if (!insight) {
        return res.status(404).json({ error: 'Insight not found' });
    }
    insight.status = 'acted';
    res.json(insight);
});
app.put('/api/v1/insights/:id/dismiss', function (req, res) {
    var insight = mockData_1.mockInsights.find(function (i) { return i.id === req.params.id; });
    if (!insight) {
        return res.status(404).json({ error: 'Insight not found' });
    }
    insight.status = 'dismissed';
    insight.dismissedUntil = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    res.json(insight);
});
// ============ BILLING ============
app.get('/api/v1/billing', function (req, res) {
    res.json(mockData_1.mockBillingInfo);
});
app.put('/api/v1/billing/tier', function (req, res) {
    mockData_1.mockBillingInfo.currentTier = req.body.newTier;
    res.json(mockData_1.mockBillingInfo);
});
// ============ HEALTH CHECK ============
app.get('/health', function (req, res) {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});
// ============ ERROR HANDLING ============
app.use(function (req, res) {
    res.status(404).json({ error: 'Not found' });
});
app.use(function (err, req, res) {
    console.error('Error:', err);
    res.status(500).json({ error: 'Internal server error' });
});
// Start server
app.listen(PORT, function () {
    console.log("\n\u2554\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557\n\u2551  AI Sales Predictive Management - Mock API Server         \u2551\n\u2551  Running on http://localhost:".concat(PORT, "                        \u2551\n\u2551  Endpoints:                                                \u2551\n\u2551  - POST /api/v1/auth/signup                                \u2551\n\u2551  - POST /api/v1/auth/login                                 \u2551\n\u2551  - POST /api/v1/auth/forgot-password                        \u2551\n\u2551  - POST /api/v1/auth/reset-password                         \u2551\n\u2551  - POST /api/v1/auth/validate-password                      \u2551\n\u2551  - POST /api/v1/billing/payment-session                     \u2551\n\u2551  - POST /api/v1/billing/process-payment                     \u2551\n\u2551  - GET  /api/v1/deals                                      \u2551\n\u2551  - POST /api/v1/deals                                      \u2551\n\u2551  - GET  /api/v1/deals/:id                                  \u2551\n\u2551  - PUT  /api/v1/deals/:id                                  \u2551\n\u2551  - GET  /api/v1/pipeline                                   \u2551\n\u2551  - GET  /api/v1/forecasts                                  \u2551\n\u2551  - GET  /api/v1/insights                                   \u2551\n\u2551  - GET  /api/v1/billing                                    \u2551\n\u2551  - GET  /health                                            \u2551\n\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255D\n  "));
});
