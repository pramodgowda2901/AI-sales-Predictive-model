const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// Serve static files from dist folder
app.use(express.static(path.join(__dirname, 'dist')));

// Fallback to index.html for SPA routing
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

// Catch all other routes and serve index.html
app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║  AI Sales Predictive Management - Frontend Server         ║
║  ✅ Running on http://localhost:${PORT}                     ║
║                                                            ║
║  Open your browser and navigate to:                       ║
║  http://localhost:${PORT}                                   ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
  `);
});
