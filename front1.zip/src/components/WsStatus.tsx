import { useEffect } from 'react'
import { useUIStore } from '../store/uiStore'

export default function WsStatus() {
  const { wsStatus, setWsStatus } = useUIStore()

  // Simulate WebSocket lifecycle for demo
  useEffect(() => {
    setWsStatus('connected')
    const interval = setInterval(() => {
      // Randomly simulate brief reconnects for realism
      if (Math.random() < 0.02) {
        setWsStatus('reconnecting')
        setTimeout(() => setWsStatus('connected'), 2000)
      }
    }, 10000)
    return () => clearInterval(interval)
  }, [])

  const config = {
    connected: { dot: 'bg-green-400 animate-pulse', text: 'Live', color: 'text-green-600 dark:text-green-400' },
    reconnecting: { dot: 'bg-yellow-400 animate-ping', text: 'Reconnecting…', color: 'text-yellow-600' },
    disconnected: { dot: 'bg-red-400', text: 'Offline', color: 'text-red-600' },
  }[wsStatus]

  return (
    <div className="flex items-center gap-1.5" title={`WebSocket: ${wsStatus}`}>
      <span className={`w-2 h-2 rounded-full ${config.dot}`} />
      <span className={`text-xs font-medium hidden sm:block ${config.color}`}>{config.text}</span>
    </div>
  )
}
