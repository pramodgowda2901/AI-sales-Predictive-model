import { useState } from 'react'
import { Outlet, Link, useLocation } from 'react-router-dom'
import { useAuthStore } from '../store/authStore'
import { useUIStore } from '../store/uiStore'
import NotificationCenter from './NotificationCenter'
import GlobalSearch from './GlobalSearch'
import WsStatus from './WsStatus'
import { useRealTimeUpdates } from '../hooks/useRealTimeUpdates'
import { useDataIngestion } from '../hooks/useDataIngestion'
import CompanySearch from './CompanySearch'
import IngestionPanel from './IngestionPanel'

export default function Layout() {
  const { logout } = useAuthStore()
  const { darkMode, toggleDarkMode } = useUIStore()
  const location = useLocation()
  const [sidebarOpen, setSidebarOpen] = useState(true)

  // Real-time polling — refreshes all data every 15 seconds
  useRealTimeUpdates(15000)
  // Automatic data ingestion — pulls signals from CRM, Email, Calendar, Web, AI
  useDataIngestion()

  const isActive = (path: string) => location.pathname === path || location.pathname.startsWith(path + '/')

  const navGroups = [
    {
      label: 'Sales',
      items: [
        { path: '/pipeline', label: 'Pipeline', icon: '📊' },
        { path: '/deals', label: 'Deals', icon: '💼' },
        { path: '/insights', label: 'Insights', icon: '💡' },
        { path: '/company', label: 'Company Profile', icon: '🏢' },
        { path: '/sales-prediction', label: 'DS AI Prediction', icon: '🎯' },
      ],
    },
    {
      label: 'Analytics',
      items: [
        { path: '/forecasts', label: 'Forecasts', icon: '📈' },
        { path: '/analytics', label: 'Analytics', icon: '📉' },
      ],
    },
    {
      label: 'Platform',
      items: [
        { path: '/notifications', label: 'Notifications', icon: '🔔' },
        { path: '/email-preferences', label: 'Email Prefs', icon: '📧' },
        { path: '/crm-integrations', label: 'CRM Integrations', icon: '🔗' },
        { path: '/reports', label: 'Reports', icon: '📋' },
        { path: '/billing', label: 'Billing', icon: '💳' },
        { path: '/api-keys', label: 'API Keys', icon: '🔑' },
      ],
    },
    {
      label: 'Admin',
      items: [
        { path: '/admin', label: 'User Mgmt', icon: '👥' },
        { path: '/super-admin', label: 'Super Admin', icon: '🛡️' },
        { path: '/onboarding', label: 'Onboarding', icon: '🚀' },
        { path: '/data-privacy', label: 'Data Privacy', icon: '🔐' },
        { path: '/settings', label: 'Settings', icon: '⚙️' },
      ],
    },
  ]

  const allNavItems = navGroups.flatMap((g) => g.items)

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'w-56' : 'w-16'} bg-gradient-to-b from-blue-900 to-blue-800 dark:from-slate-900 dark:to-slate-800 shadow-lg transition-all duration-300 flex flex-col overflow-hidden`}>
        <div className="p-4 border-b border-blue-700 flex items-center justify-between">
          {sidebarOpen && <h1 className="text-lg font-bold text-white truncate">SalesPred AI</h1>}
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-white hover:bg-blue-700 p-1 rounded flex-shrink-0">
            {sidebarOpen ? '←' : '→'}
          </button>
        </div>

        <nav className="mt-4 flex-1 overflow-y-auto">
          {navGroups.map((group) => (
            <div key={group.label}>
              {sidebarOpen && (
                <p className="px-4 py-1 text-xs font-semibold text-blue-300 uppercase tracking-wider">{group.label}</p>
              )}
              {group.items.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center px-4 py-2.5 text-sm font-medium transition-colors ${
                    isActive(item.path)
                      ? 'bg-blue-700 text-white border-l-4 border-white'
                      : 'text-blue-100 hover:bg-blue-700 hover:text-white'
                  }`}
                >
                  <span className="text-base flex-shrink-0">{item.icon}</span>
                  {sidebarOpen && <span className="ml-3 truncate">{item.label}</span>}
                </Link>
              ))}
              {sidebarOpen && <div className="my-1 mx-4 border-t border-blue-700/50" />}
            </div>
          ))}
        </nav>

        <div className="p-4 border-t border-blue-700">
          <button
            onClick={logout}
            className="w-full px-3 py-2 bg-red-600 text-white rounded hover:bg-red-700 font-medium transition-colors text-sm"
          >
            {sidebarOpen ? '🚪 Logout' : '🚪'}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto flex flex-col min-w-0 bg-gray-100 dark:bg-slate-900">
        {/* Header */}
        <div className="bg-white dark:bg-slate-800 shadow-sm border-b border-gray-200 dark:border-slate-700 px-6 py-3 flex-shrink-0">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">
              {allNavItems.find((item) => isActive(item.path))?.label || 'Dashboard'}
            </h2>
            <div className="flex items-center gap-3">
              <WsStatus />
              <GlobalSearch />
              <IngestionPanel />
              <CompanySearch />
              <button
                onClick={toggleDarkMode}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 dark:text-slate-400 dark:hover:text-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                title={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
              >
                {darkMode ? '☀️' : '🌙'}
              </button>
              <NotificationCenter />
            </div>
          </div>
        </div>

        {/* Page Content */}
        <div className="flex-1 overflow-auto p-6">
          <Outlet />
        </div>
      </div>
    </div>
  )
}
