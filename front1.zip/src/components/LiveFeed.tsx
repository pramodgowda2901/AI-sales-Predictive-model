import { useState, useCallback } from 'react'
import { useLiveActivityFeed, LiveEvent } from '../hooks/useRealTimeUpdates'

export default function LiveFeed() {
  const [events, setEvents] = useState<(LiveEvent & { id: number })[]>([])
  const [counter, setCounter] = useState(0)

  const handleEvent = useCallback((event: LiveEvent) => {
    setCounter((c) => {
      const id = c + 1
      setEvents((prev) => [{ ...event, id, time: 'just now' }, ...prev].slice(0, 5))
      return id
    })
  }, [])

  useLiveActivityFeed(handleEvent)

  if (events.length === 0) return null

  return (
    <div className="mb-6 bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 shadow-sm overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 dark:bg-slate-900 border-b border-gray-200 dark:border-slate-700">
        <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
        <span className="text-xs font-semibold text-gray-600 dark:text-slate-400 uppercase tracking-wide">Live Activity</span>
      </div>
      <div className="divide-y divide-gray-100 dark:divide-slate-700">
        {events.map((event) => (
          <div key={event.id} className="flex items-center gap-3 px-4 py-2.5 animate-fade-in">
            <span className="text-base flex-shrink-0">{event.icon}</span>
            <p className="text-sm text-gray-700 dark:text-slate-300 flex-1 truncate">{event.message}</p>
            <span className="text-xs text-gray-400 dark:text-slate-500 flex-shrink-0">{event.time}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
