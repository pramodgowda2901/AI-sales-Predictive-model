import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery } from 'react-query'
import { apiClient } from '../services/api'

interface SearchResult {
  id: string
  type: 'deal' | 'forecast' | 'insight'
  title: string
  subtitle: string
  href: string
}

export default function GlobalSearch() {
  const [query, setQuery] = useState('')
  const [open, setOpen] = useState(false)
  const [selected, setSelected] = useState(-1)
  const ref = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const navigate = useNavigate()

  const { data: deals = [] } = useQuery('deals', () => apiClient.getDeals(), { staleTime: 30000 })
  const { data: insights = [] } = useQuery('insights', () => apiClient.getInsights(), { staleTime: 30000 })
  const { data: forecasts = [] } = useQuery('forecasts', () => apiClient.getForecasts(), { staleTime: 30000 })

  const results: SearchResult[] = query.trim().length < 2 ? [] : [
    ...(deals as any[])
      .filter((d) =>
        d.name?.toLowerCase().includes(query.toLowerCase()) ||
        d.accountName?.toLowerCase().includes(query.toLowerCase())
      )
      .slice(0, 4)
      .map((d) => ({
        id: d.id,
        type: 'deal' as const,
        title: d.name,
        subtitle: `${d.stage} · $${(d.value / 1000).toFixed(0)}K · ${d.winProbability}% win`,
        href: `/deals/${d.id}`,
      })),
    ...(insights as any[])
      .filter((i) => i.text?.toLowerCase().includes(query.toLowerCase()) || i.type?.toLowerCase().includes(query.toLowerCase()))
      .slice(0, 3)
      .map((i) => ({
        id: i.id,
        type: 'insight' as const,
        title: i.type,
        subtitle: i.text?.slice(0, 60) + '...',
        href: '/insights',
      })),
    ...(forecasts as any[])
      .filter((f) => f.horizon?.toLowerCase().includes(query.toLowerCase()))
      .slice(0, 2)
      .map((f) => ({
        id: f.id,
        type: 'forecast' as const,
        title: `${f.horizon?.charAt(0).toUpperCase() + f.horizon?.slice(1)} Forecast`,
        subtitle: `$${(f.projectedValue / 1000000).toFixed(1)}M projected`,
        href: '/forecasts',
      })),
  ]

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  // Keyboard shortcut: Cmd/Ctrl+K
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault()
        inputRef.current?.focus()
        setOpen(true)
      }
      if (e.key === 'Escape') setOpen(false)
    }
    document.addEventListener('keydown', handler)
    return () => document.removeEventListener('keydown', handler)
  }, [])

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setSelected((s) => Math.min(s + 1, results.length - 1)) }
    if (e.key === 'ArrowUp') { e.preventDefault(); setSelected((s) => Math.max(s - 1, -1)) }
    if (e.key === 'Enter' && selected >= 0) { navigate(results[selected].href); setQuery(''); setOpen(false) }
  }

  const typeIcon: Record<string, string> = { deal: '💼', forecast: '📈', insight: '💡' }
  const typeColor: Record<string, string> = {
    deal: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
    forecast: 'bg-purple-100 text-purple-700',
    insight: 'bg-yellow-100 text-yellow-700',
  }

  return (
    <div ref={ref} className="relative w-72">
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => { setQuery(e.target.value); setOpen(true); setSelected(-1) }}
          onFocus={() => setOpen(true)}
          onKeyDown={handleKeyDown}
          placeholder="Search… (⌘K)"
          className="w-full pl-9 pr-4 py-2 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100 dark:placeholder-slate-400"
        />
        <svg className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
      </div>

      {open && query.trim().length >= 2 && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl shadow-2xl z-50 overflow-hidden max-h-80 overflow-y-auto">
          {results.length === 0 ? (
            <div className="px-4 py-6 text-center text-sm text-gray-500">No results for "{query}"</div>
          ) : (
            <>
              {results.map((r, i) => (
                <button
                  key={r.id + r.type}
                  onClick={() => { navigate(r.href); setQuery(''); setOpen(false) }}
                  className={`w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-gray-50 dark:hover:bg-slate-700 border-b border-gray-100 dark:border-slate-700 last:border-0 transition-colors ${i === selected ? 'bg-blue-50 dark:bg-slate-700' : ''}`}
                >
                  <span className="text-lg">{typeIcon[r.type]}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 dark:text-slate-100 truncate">{r.title}</p>
                    <p className="text-xs text-gray-500 dark:text-slate-400 truncate">{r.subtitle}</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium flex-shrink-0 ${typeColor[r.type]}`}>{r.type}</span>
                </button>
              ))}
              <div className="px-4 py-2 bg-gray-50 dark:bg-slate-900 text-xs text-gray-400 flex gap-3">
                <span>↑↓ navigate</span><span>↵ open</span><span>esc close</span>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  )
}
