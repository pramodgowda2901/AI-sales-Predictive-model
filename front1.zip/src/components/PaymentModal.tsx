import { useState } from 'react'
import { apiClient } from '../services/api'

interface PaymentModalProps {
  isOpen: boolean
  tier: string
  amount: number
  email: string
  onClose: () => void
  onSuccess: (tier: string) => void
}

export default function PaymentModal({ isOpen, tier, amount, email, onClose, onSuccess }: PaymentModalProps) {
  const [step, setStep] = useState<'details' | 'processing' | 'success' | 'error'>('details')
  const [cardDetails, setCardDetails] = useState({
    cardNumber: '',
    expiryMonth: '',
    expiryYear: '',
    cvc: '',
    cardholderName: '',
  })
  const [error, setError] = useState('')
  const [sessionId, setSessionId] = useState('')
  const [loading, setLoading] = useState(false)

  if (!isOpen) return null

  const handleCardChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    let formattedValue = value

    if (name === 'cardNumber') {
      formattedValue = value.replace(/\s/g, '').replace(/(\d{4})/g, '$1 ').trim()
    } else if (name === 'expiryMonth' || name === 'expiryYear') {
      formattedValue = value.replace(/\D/g, '')
    } else if (name === 'cvc') {
      formattedValue = value.replace(/\D/g, '').slice(0, 4)
    }

    setCardDetails((prev) => ({ ...prev, [name]: formattedValue }))
  }

  const validateCardDetails = (): boolean => {
    if (!cardDetails.cardNumber || cardDetails.cardNumber.replace(/\s/g, '').length !== 16) {
      setError('Invalid card number')
      return false
    }
    if (!cardDetails.expiryMonth || !cardDetails.expiryYear) {
      setError('Invalid expiry date')
      return false
    }
    if (!cardDetails.cvc || cardDetails.cvc.length < 3) {
      setError('Invalid CVC')
      return false
    }
    if (!cardDetails.cardholderName) {
      setError('Cardholder name is required')
      return false
    }
    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    if (!validateCardDetails()) {
      return
    }

    setLoading(true)
    setStep('processing')

    try {
      // Create payment session
      const sessionResult = await apiClient.createPaymentSession(email, tier, amount)
      setSessionId(sessionResult.sessionId)

      // Process payment
      const paymentResult = await apiClient.processPayment(
        sessionResult.sessionId,
        `tok_${Math.random().toString(36).substr(2, 9)}`,
        cardDetails
      )

      if (paymentResult.success) {
        setStep('success')
        setTimeout(() => {
          onSuccess(tier)
          onClose()
        }, 2000)
      } else {
        setError(paymentResult.message)
        setStep('error')
      }
    } catch (error: any) {
      setError(error.response?.data?.message || 'Payment failed. Please try again.')
      setStep('error')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-white">Complete Payment</h2>
          {step !== 'processing' && (
            <button
              onClick={onClose}
              className="text-white hover:text-gray-200 text-2xl leading-none"
            >
              ×
            </button>
          )}
        </div>

        {/* Content */}
        <div className="p-6">
          {step === 'details' && (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg mb-6">
                <p className="text-sm text-gray-600">Upgrading to</p>
                <p className="text-2xl font-bold text-gray-900 capitalize">{tier}</p>
                <p className="text-lg font-semibold text-blue-600 mt-2">${amount}/month</p>
              </div>

              {error && (
                <div className="p-3 bg-red-100 border border-red-400 text-red-700 rounded-lg text-sm">
                  {error}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Cardholder Name</label>
                <input
                  type="text"
                  name="cardholderName"
                  value={cardDetails.cardholderName}
                  onChange={handleCardChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  placeholder="John Doe"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Card Number</label>
                <input
                  type="text"
                  name="cardNumber"
                  value={cardDetails.cardNumber}
                  onChange={handleCardChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  placeholder="4242 4242 4242 4242"
                  maxLength={19}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Month</label>
                  <input
                    type="text"
                    name="expiryMonth"
                    value={cardDetails.expiryMonth}
                    onChange={handleCardChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    placeholder="MM"
                    maxLength={2}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Year</label>
                  <input
                    type="text"
                    name="expiryYear"
                    value={cardDetails.expiryYear}
                    onChange={handleCardChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    placeholder="YY"
                    maxLength={2}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">CVC</label>
                  <input
                    type="text"
                    name="cvc"
                    value={cardDetails.cvc}
                    onChange={handleCardChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    placeholder="123"
                    maxLength={4}
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 disabled:from-gray-400 disabled:to-gray-400 font-medium"
                >
                  {loading ? 'Processing...' : 'Pay Now'}
                </button>
              </div>

              <p className="text-xs text-gray-500 text-center mt-4">
                💳 Demo: Use 4242 4242 4242 4242 with any future date
              </p>
            </form>
          )}

          {step === 'processing' && (
            <div className="text-center py-8">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
                <div className="animate-spin">
                  <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <p className="text-lg font-semibold text-gray-900">Processing Payment</p>
              <p className="text-sm text-gray-600 mt-2">Please wait while we process your payment...</p>
            </div>
          )}

          {step === 'success' && (
            <div className="text-center py-8">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <p className="text-lg font-semibold text-gray-900">Payment Successful!</p>
              <p className="text-sm text-gray-600 mt-2">Your plan has been upgraded to {tier}</p>
              <p className="text-xs text-gray-500 mt-4">Redirecting...</p>
            </div>
          )}

          {step === 'error' && (
            <div className="text-center py-8">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-red-100 rounded-full mb-4">
                <svg className="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </div>
              <p className="text-lg font-semibold text-gray-900">Payment Failed</p>
              <p className="text-sm text-red-600 mt-2">{error}</p>
              <button
                onClick={() => {
                  setStep('details')
                  setError('')
                }}
                className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
              >
                Try Again
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
