import { useState, useRef, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useCompanyStore } from '../store/companyStore'

const POPULAR = [
  'Digital Solution AI',
  'Salesforce',
  'HubSpot',
  'Microsoft',
  'Google',
  'Amazon',
  'Infosys',
  'Wipro',
  'TCS',
  'Zoho',
]

export default function CompanySearch() {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  const navigate = useNavigate()
  const { setCompany, currentCompany } = useCompanyStore()

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const filtered = query.trim()
    ? POPULAR.filter((c) => c.toLowerCase().includes(query.toLowerCase()))
    : POPULAR

  const handleSelect = async (name: string) => {
    setLoading(true)
    setOpen(false)
    setQuery('')
    await setCompany(name)
    setLoading(false)
    navigate('/company')
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim()) handleSelect(query.trim())
  }

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-lg hover:border-blue-400 hover:text-blue-600 dark:hover:text-blue-400 transition-all shadow-sm"
        title="Search company profile"
      >
        {loading ? (
          <span className="animate-spin text-base">⏳</span>
        ) : (
          <span className="text-base">🏢</span>
        )}
        <span className="hidden sm:block max-w-28 truncate">
          {loading ? 'Loading…' : currentCompany || 'Company'}
        </span>
        <span className="text-gray-400 dark:text-slate-500 text-xs">▾</span>
      </button>

      {open && (
        <div className="absolute right-0 top-12 w-72 bg-white dark:bg-slate-800 rounded-xl shadow-2xl border border-gray-200 dark:border-slate-700 z-50">
          <div className="p-3 border-b border-gray-100 dark:border-slate-700">
            <p className="text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wide mb-2">
              Search Company
            </p>
            <form onSubmit={handleSubmit}>
              <div className="relative">
                <input
                  autoFocus
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Type company name…"
                  className="w-full pl-8 pr-3 py-2 text-sm border border-gray-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-slate-700 dark:text-slate-100 dark:placeholder-slate-400"
                />
                <span className="absolute left-2.5 top-2.5 text-gray-400 text-sm">🔍</span>
              </div>
              {query.trim() && !filtered.includes(query.trim()) && (
                <button
                  type="submit"
                  className="mt-2 w-full px-3 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700"
                >
                  Search "{query.trim()}"
                </button>
              )}
            </form>
          </div>

          <div className="py-2 max-h-64 overflow-y-auto">
            <p className="px-3 py-1 text-xs text-gray-400 dark:text-slate-500 font-medium">
              {query ? 'Suggestions' : 'Popular Companies'}
            </p>
            {filtered.length === 0 ? (
              <p className="px-3 py-3 text-sm text-gray-500 dark:text-slate-400 text-center">
                No matches — press Enter to search
              </p>
            ) : (
              filtered.map((name) => (
                <button
                  key={name}
                  onClick={() => handleSelect(name)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 text-left hover:bg-blue-50 dark:hover:bg-slate-700 transition-colors ${
                    currentCompany === name ? 'bg-blue-50 dark:bg-blue-900/20' : ''
                  }`}
                >
                  <span className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                    {name.slice(0, 2).toUpperCase()}
                  </span>
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-slate-100">{name}</p>
                    <p className="text-xs text-gray-400 dark:text-slate-500">View company profile</p>
                  </div>
                  {currentCompany === name && (
                    <span className="ml-auto text-blue-500 text-xs font-bold">Active</span>
                  )}
                </button>
              ))
            )}
          </div>

          <div className="p-3 border-t border-gray-100 dark:border-slate-700">
            <p className="text-xs text-gray-400 dark:text-slate-500 text-center">
              Type any company name and press Enter
            </p>
          </div>
        </div>
      )}
    </div>
  )
}
