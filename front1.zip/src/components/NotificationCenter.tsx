import { useState, useEffect, useRef } from 'react'
import { useQuery, useMutation, useQueryClient } from 'react-query'
import { apiClient } from '../services/api'

interface Notification {
  id: string
  type: string
  message: string
  read: boolean
  createdAt: string
}

export default function NotificationCenter() {
  const [isOpen, setIsOpen] = useState(false)
  const panelRef = useRef<HTMLDivElement>(null)
  const queryClient = useQueryClient()

  const { data: notifications = [] } = useQuery<Notification[]>('notifications', () =>
    apiClient.getNotifications()
  )

  const unreadCount = notifications.filter((n) => !n.read).length

  const markAllReadMutation = useMutation(
    () => apiClient.markNotificationsRead(),
    { onSuccess: () => queryClient.invalidateQueries('notifications') }
  )

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) {
        setIsOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const handleOpen = () => {
    setIsOpen(!isOpen)
    if (!isOpen && unreadCount > 0) {
      markAllReadMutation.mutate()
    }
  }

  const getTypeIcon = (type: string) => {
    const icons: Record<string, string> = {
      deal_alert: '📊',
      insight: '💡',
      forecast: '📈',
      billing: '💳',
      system: '⚙️',
    }
    return icons[type] || '🔔'
  }

  const groupByDate = (notifs: Notification[]) => {
    const groups: Record<string, Notification[]> = {}
    notifs.forEach((n) => {
      const date = new Date(n.createdAt)
      const today = new Date()
      const yesterday = new Date(today)
      yesterday.setDate(yesterday.getDate() - 1)
      let label = date.toLocaleDateString()
      if (date.toDateString() === today.toDateString()) label = 'Today'
      else if (date.toDateString() === yesterday.toDateString()) label = 'Yesterday'
      if (!groups[label]) groups[label] = []
      groups[label].push(n)
    })
    return groups
  }

  const grouped = groupByDate(notifications)

  return (
    <div className="relative" ref={panelRef}>
      {/* Bell button */}
      <button
        onClick={handleOpen}
        className="relative p-2 text-gray-600 dark:text-slate-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
      >
        <span className="text-xl">🔔</span>
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-bold">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {/* Panel */}
      {isOpen && (
        <div className="absolute right-0 top-12 w-96 bg-white dark:bg-slate-800 rounded-xl shadow-2xl border border-gray-200 dark:border-slate-700 z-50 max-h-[32rem] flex flex-col">

          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200 dark:border-slate-700">
            <h3 className="font-bold text-gray-900 dark:text-slate-100">Notifications</h3>
            <button
              onClick={() => setIsOpen(false)}
              className="text-gray-400 dark:text-slate-500 hover:text-gray-700 dark:hover:text-slate-200 text-xl leading-none transition-colors"
            >
              ×
            </button>
          </div>

          {/* Body */}
          <div className="overflow-y-auto flex-1">
            {notifications.length === 0 ? (
              <div className="text-center py-12 text-gray-500 dark:text-slate-400">
                <div className="text-4xl mb-2">🔔</div>
                <p>No notifications yet</p>
              </div>
            ) : (
              Object.entries(grouped).map(([date, notifs]) => (
                <div key={date}>
                  {/* Date group label */}
                  <div className="px-4 py-2 bg-gray-50 dark:bg-slate-900 text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wide border-b border-gray-100 dark:border-slate-700">
                    {date}
                  </div>

                  {notifs.map((n) => (
                    <div
                      key={n.id}
                      className={`px-4 py-3 border-b border-gray-100 dark:border-slate-700 transition-colors ${
                        !n.read
                          ? 'bg-blue-50 dark:bg-blue-900/20 hover:bg-blue-100 dark:hover:bg-blue-900/30'
                          : 'hover:bg-gray-50 dark:hover:bg-slate-700'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <span className="text-lg mt-0.5 flex-shrink-0">{getTypeIcon(n.type)}</span>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm text-gray-800 dark:text-slate-200 leading-snug">
                            {n.message}
                          </p>
                          <p className="text-xs text-gray-400 dark:text-slate-500 mt-1">
                            {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                        {!n.read && (
                          <span className="w-2 h-2 bg-blue-500 rounded-full mt-1.5 flex-shrink-0" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          <div className="px-4 py-3 border-t border-gray-200 dark:border-slate-700 text-center bg-gray-50 dark:bg-slate-900 rounded-b-xl">
            <a
              href="/settings"
              className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium transition-colors"
            >
              Manage notification preferences →
            </a>
          </div>
        </div>
      )}
    </div>
  )
}
