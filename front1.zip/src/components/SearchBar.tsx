import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'

interface SearchResult {
  id: string
  type: 'deal' | 'forecast' | 'insight'
  title: string
  subtitle: string
  value?: number
  probability?: number
}

interface SearchBarProps {
  onSearch?: (query: string) => void
  placeholder?: string
}

export default function SearchBar({ onSearch, placeholder = 'Search deals, forecasts, insights...' }: SearchBarProps) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SearchResult[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const [selectedIndex, setSelectedIndex] = useState(-1)
  const searchRef = useRef<HTMLDivElement>(null)
  const navigate = useNavigate()

  // Mock search function - replace with actual API call
  const performSearch = (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([])
      return
    }

    const mockResults: SearchResult[] = [
      {
        id: '1',
        type: 'deal' as const,
        title: 'Acme Corp Deal',
        subtitle: 'Prospecting • $50,000',
        value: 50000,
        probability: 25,
      },
      {
        id: '2',
        type: 'deal' as const,
        title: 'TechStart Integration',
        subtitle: 'Negotiation • $120,000',
        value: 120000,
        probability: 65,
      },
      {
        id: '3',
        type: 'forecast' as const,
        title: 'Q2 Revenue Forecast',
        subtitle: 'Projected: $2.5M',
        value: 2500000,
      },
      {
        id: '4',
        type: 'insight' as const,
        title: 'Stalled Deal Alert',
        subtitle: 'Acme Corp - No activity for 14 days',
      },
    ].filter(
      (result) =>
        result.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        result.subtitle.toLowerCase().includes(searchQuery.toLowerCase())
    )

    setResults(mockResults)
    setSelectedIndex(-1)
  }

  useEffect(() => {
    const timer = setTimeout(() => {
      performSearch(query)
      if (onSearch) onSearch(query)
    }, 300)

    return () => clearTimeout(timer)
  }, [query, onSearch])

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const handleKeyDown = (e: React.KeyboardEvent) => {
    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault()
        setSelectedIndex((prev) => (prev < results.length - 1 ? prev + 1 : prev))
        break
      case 'ArrowUp':
        e.preventDefault()
        setSelectedIndex((prev) => (prev > 0 ? prev - 1 : -1))
        break
      case 'Enter':
        e.preventDefault()
        if (selectedIndex >= 0) {
          handleSelectResult(results[selectedIndex])
        }
        break
      case 'Escape':
        setIsOpen(false)
        break
    }
  }

  const handleSelectResult = (result: SearchResult) => {
    switch (result.type) {
      case 'deal':
        navigate(`/deals/${result.id}`)
        break
      case 'forecast':
        navigate('/forecasts')
        break
      case 'insight':
        navigate('/insights')
        break
    }
    setQuery('')
    setIsOpen(false)
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'deal':
        return '📊'
      case 'forecast':
        return '📈'
      case 'insight':
        return '💡'
      default:
        return '🔍'
    }
  }

  return (
    <div ref={searchRef} className="relative w-full max-w-md">
      <div className="relative">
        <input
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value)
            setIsOpen(true)
          }}
          onFocus={() => setIsOpen(true)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
        <span className="absolute left-3 top-2.5 text-gray-400">🔍</span>
      </div>

      {isOpen && results.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-lg shadow-lg z-50 max-h-96 overflow-y-auto">
          {results.map((result, index) => (
            <button
              key={result.id}
              onClick={() => handleSelectResult(result)}
              className={`w-full px-4 py-3 text-left border-b border-gray-100 hover:bg-blue-50 transition-colors ${
                index === selectedIndex ? 'bg-blue-100' : ''
              }`}
            >
              <div className="flex items-start gap-3">
                <span className="text-lg mt-0.5">{getTypeIcon(result.type)}</span>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-gray-900 truncate">{result.title}</p>
                  <p className="text-sm text-gray-600 truncate">{result.subtitle}</p>
                </div>
                {result.probability && (
                  <span className="text-sm font-semibold text-blue-600 whitespace-nowrap ml-2">
                    {result.probability}%
                  </span>
                )}
              </div>
            </button>
          ))}
        </div>
      )}

      {isOpen && query && results.length === 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-lg shadow-lg z-50 p-4 text-center text-gray-500">
          No results found for "{query}"
        </div>
      )}
    </div>
  )
}
