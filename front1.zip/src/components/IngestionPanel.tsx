import { useState, useEffect } from 'react'
import { ingestionLog, ingestionListeners, IngestionEvent } from '../hooks/useDataIngestion'

const SOURCE_COLORS: Record<string, string> = {
  CRM:      'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300',
  Email:    'bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300',
  Calendar: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300',
  Web:      'bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300',
  Signal:   'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-300',
  AI:       'bg-pink-100 text-pink-700 dark:bg-pink-900/40 dark:text-pink-300',
}

const IMPACT_DOT: Record<string, string> = {
  high:   'bg-red-500',
  medium: 'bg-yellow-500',
  low:    'bg-green-500',
}

const SOURCE_ICON: Record<string, string> = {
  CRM: '🔗', Email: '📧', Calendar: '📅', Web: '🌐', Signal: '📡', AI: '🤖',
}

export default function IngestionPanel() {
  const [events, setEvents] = useState<IngestionEvent[]>([...ingestionLog])
  const [totalCount, setTotalCount] = useState(ingestionLog.length)
  const [isOpen, setIsOpen] = useState(false)
  const [newFlash, setNewFlash] = useState(false)

  useEffect(() => {
    const update = () => {
      setEvents([...ingestionLog])
      setTotalCount(ingestionLog.length)
      setNewFlash(true)
      setTimeout(() => setNewFlash(false), 1000)
    }
    ingestionListeners.add(update)
    return () => { ingestionListeners.delete(update) }
  }, [])

  const highCount = events.filter((e) => e.impact === 'high').length

  return (
    <div className="relative">
      {/* Trigger button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-lg border transition-all shadow-sm ${
          newFlash
            ? 'bg-green-50 border-green-400 text-green-700 dark:bg-green-900/30 dark:border-green-600 dark:text-green-400'
            : 'bg-white dark:bg-slate-700 border-gray-300 dark:border-slate-600 text-gray-700 dark:text-slate-300 hover:border-blue-400'
        }`}
        title="Data Ingestion Feed"
      >
        <span className={`w-2 h-2 rounded-full flex-shrink-0 ${events.length > 0 ? 'bg-green-400 animate-pulse' : 'bg-gray-300'}`} />
        <span className="hidden sm:block">Ingestion</span>
        {highCount > 0 && (
          <span className="bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
            {highCount > 9 ? '9+' : highCount}
          </span>
        )}
      </button>

      {/* Panel */}
      {isOpen && (
        <div className="absolute right-0 top-12 w-96 bg-white dark:bg-slate-800 rounded-xl shadow-2xl border border-gray-200 dark:border-slate-700 z-50 max-h-[32rem] flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-900 rounded-t-xl">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <h3 className="font-bold text-gray-900 dark:text-slate-100 text-sm">Live Data Ingestion</h3>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-500 dark:text-slate-400">{totalCount} events</span>
              <button onClick={() => setIsOpen(false)} className="text-gray-400 hover:text-gray-600 dark:hover:text-slate-200 text-xl leading-none">×</button>
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-3 gap-2 px-4 py-3 border-b border-gray-100 dark:border-slate-700">
            {[
              { label: 'High Priority', count: events.filter((e) => e.impact === 'high').length, color: 'text-red-600 dark:text-red-400' },
              { label: 'Medium', count: events.filter((e) => e.impact === 'medium').length, color: 'text-yellow-600 dark:text-yellow-400' },
              { label: 'Low', count: events.filter((e) => e.impact === 'low').length, color: 'text-green-600 dark:text-green-400' },
            ].map((s) => (
              <div key={s.label} className="text-center">
                <p className={`text-lg font-bold ${s.color}`}>{s.count}</p>
                <p className="text-xs text-gray-500 dark:text-slate-400">{s.label}</p>
              </div>
            ))}
          </div>

          {/* Events list */}
          <div className="overflow-y-auto flex-1">
            {events.length === 0 ? (
              <div className="text-center py-8 text-gray-500 dark:text-slate-400">
                <div className="text-3xl mb-2">📡</div>
                <p className="text-sm">Waiting for incoming data…</p>
              </div>
            ) : (
              events.map((event, i) => (
                <div
                  key={event.id}
                  className={`px-4 py-3 border-b border-gray-100 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors ${
                    i === 0 ? 'bg-blue-50/50 dark:bg-blue-900/10' : ''
                  }`}
                >
                  <div className="flex items-start gap-2">
                    <span className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${IMPACT_DOT[event.impact]}`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${SOURCE_COLORS[event.source]}`}>
                          {SOURCE_ICON[event.source]} {event.source}
                        </span>
                        <span className="text-xs text-gray-500 dark:text-slate-400 truncate">{event.type}</span>
                      </div>
                      <p className="text-xs font-semibold text-gray-900 dark:text-slate-100">{event.entity}</p>
                      <p className="text-xs text-gray-600 dark:text-slate-400 mt-0.5 leading-snug">{event.detail}</p>
                    </div>
                    <span className="text-xs text-gray-400 dark:text-slate-500 flex-shrink-0 ml-1">
                      {new Date(event.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          <div className="px-4 py-3 border-t border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-900 rounded-b-xl">
            <p className="text-xs text-gray-500 dark:text-slate-400 text-center">
              Auto-ingesting from CRM · Email · Calendar · Web · AI every 6–12s
            </p>
          </div>
        </div>
      )}
    </div>
  )
}
