import { useState } from 'react'
import { apiClient } from '../services/api'
import BackButton from '../components/BackButton'

interface User {
  id: string
  email: string
  fullName: string
  role: 'admin' | 'manager' | 'sales_rep'
  status: 'active' | 'inactive'
  createdAt: string
  lastLogin?: string
}

const INITIAL_USERS: User[] = [
  { id: '1', email: 'john@example.com', fullName: 'John Doe', role: 'admin', status: 'active', createdAt: '2024-01-15', lastLogin: '2024-04-20' },
  { id: '2', email: 'jane@example.com', fullName: 'Jane Smith', role: 'manager', status: 'active', createdAt: '2024-02-01', lastLogin: '2024-04-19' },
  { id: '3', email: 'bob@example.com', fullName: 'Bob Johnson', role: 'sales_rep', status: 'active', createdAt: '2024-02-15', lastLogin: '2024-04-20' },
]

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState<'users' | 'roles' | 'audit' | 'system'>('users')
  const [users, setUsers] = useState<User[]>(INITIAL_USERS)

  // Invite modal
  const [showInviteModal, setShowInviteModal] = useState(false)
  const [inviteEmail, setInviteEmail] = useState('')
  const [inviteFullName, setInviteFullName] = useState('')
  const [inviteRole, setInviteRole] = useState<User['role']>('sales_rep')
  const [inviteLoading, setInviteLoading] = useState(false)
  const [inviteSuccess, setInviteSuccess] = useState('')

  // Edit modal
  const [editUser, setEditUser] = useState<User | null>(null)
  const [editLoading, setEditLoading] = useState(false)

  // Remove confirm
  const [removeUserId, setRemoveUserId] = useState<string | null>(null)

  const getRoleBadge = (role: string) => {
    const map: Record<string, string> = {
      admin: 'bg-red-100 text-red-800',
      manager: 'bg-blue-100 text-blue-800',
      sales_rep: 'bg-green-100 text-green-800',
    }
    return map[role] || 'bg-gray-100 text-gray-800'
  }

  const handleInvite = async () => {
    if (!inviteEmail || !inviteFullName) return
    setInviteLoading(true)
    try {
      await apiClient.inviteUser({ email: inviteEmail, role: inviteRole })
      const newUser: User = {
        id: `user-${Date.now()}`,
        email: inviteEmail,
        fullName: inviteFullName,
        role: inviteRole,
        status: 'active',
        createdAt: new Date().toISOString().split('T')[0],
      }
      setUsers((prev) => [...prev, newUser])
      setInviteSuccess(`Invitation sent to ${inviteEmail}`)
      setInviteEmail('')
      setInviteFullName('')
      setInviteRole('sales_rep')
      setTimeout(() => {
        setInviteSuccess('')
        setShowInviteModal(false)
      }, 1500)
    } catch {
      // still add locally for demo
      const newUser: User = {
        id: `user-${Date.now()}`,
        email: inviteEmail,
        fullName: inviteFullName,
        role: inviteRole,
        status: 'active',
        createdAt: new Date().toISOString().split('T')[0],
      }
      setUsers((prev) => [...prev, newUser])
      setShowInviteModal(false)
      setInviteEmail('')
      setInviteFullName('')
    } finally {
      setInviteLoading(false)
    }
  }

  const handleEditSave = async () => {
    if (!editUser) return
    setEditLoading(true)
    try {
      await apiClient.updateProfile({ fullName: editUser.fullName, role: editUser.role })
    } catch {}
    setUsers((prev) => prev.map((u) => (u.id === editUser.id ? editUser : u)))
    setEditUser(null)
    setEditLoading(false)
  }

  const handleRemove = (id: string) => {
    setUsers((prev) => prev.filter((u) => u.id !== id))
    setRemoveUserId(null)
  }

  const handleToggleStatus = (id: string) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === id ? { ...u, status: u.status === 'active' ? 'inactive' : 'active' } : u))
    )
  }

  return (
    <div>
      <BackButton />
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">Administration</h1>
        {activeTab === 'users' && (
          <button onClick={() => setShowInviteModal(true)} className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            + Invite User
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-4 mb-8 border-b border-gray-200">
        {(['users', 'roles', 'audit', 'system'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 font-medium border-b-2 transition-colors ${
              activeTab === tab ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* Users Tab */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="px-6 py-3 bg-gray-50 border-b border-gray-200 text-sm text-gray-500">
            {users.length} user{users.length !== 1 ? 's' : ''} total · {users.filter((u) => u.status === 'active').length} active
          </div>
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Name</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Email</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Role</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Status</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Last Login</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">{user.fullName}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{user.email}</td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getRoleBadge(user.role)}`}>
                      {user.role.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <button
                      onClick={() => handleToggleStatus(user.id)}
                      className={`px-3 py-1 rounded-full text-xs font-medium cursor-pointer ${
                        user.status === 'active' ? 'bg-green-100 text-green-800 hover:bg-green-200' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {user.status}
                    </button>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">{user.lastLogin || 'Never'}</td>
                  <td className="px-6 py-4 text-sm flex gap-3">
                    <button onClick={() => setEditUser({ ...user })} className="text-blue-600 hover:text-blue-800 font-medium">
                      Edit
                    </button>
                    <button onClick={() => setRemoveUserId(user.id)} className="text-red-600 hover:text-red-800 font-medium">
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Roles Tab */}
      {activeTab === 'roles' && (
        <div className="grid grid-cols-3 gap-6">
          {[
            { name: 'Admin', color: 'red', permissions: ['Manage users', 'Configure integrations', 'View analytics', 'Manage billing', 'Access audit logs'] },
            { name: 'Manager', color: 'blue', permissions: ['View team deals', 'View analytics', 'Create reports', 'Manage team members', 'View forecasts'] },
            { name: 'Sales Rep', color: 'green', permissions: ['Create/edit own deals', 'View insights', 'View forecasts', 'Track activities', 'Export data'] },
          ].map((role) => (
            <div key={role.name} className="bg-white p-6 rounded-lg shadow">
              <div className={`inline-block px-3 py-1 rounded-full text-xs font-medium mb-3 bg-${role.color}-100 text-${role.color}-800`}>
                {role.name}
              </div>
              <div className="space-y-2 mt-2">
                {role.permissions.map((perm) => (
                  <div key={perm} className="flex items-center text-sm text-gray-700">
                    <span className="text-green-500 mr-2">✓</span>{perm}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Audit Tab */}
      {activeTab === 'audit' && (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Timestamp</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">User</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Action</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Resource</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {[
                { timestamp: '2024-04-20 14:30', user: 'John Doe', action: 'Created', resource: 'Deal: Acme Corp', status: 'Success' },
                { timestamp: '2024-04-20 13:15', user: 'Jane Smith', action: 'Updated', resource: 'User: Bob Johnson', status: 'Success' },
                { timestamp: '2024-04-20 12:00', user: 'John Doe', action: 'Deleted', resource: 'Deal: Old Deal', status: 'Success' },
                { timestamp: '2024-04-20 11:45', user: 'Jane Smith', action: 'Accessed', resource: 'Analytics', status: 'Success' },
                { timestamp: '2024-04-20 10:30', user: 'Bob Johnson', action: 'Exported', resource: 'Forecast Report', status: 'Success' },
              ].map((log, idx) => (
                <tr key={idx} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm text-gray-500">{log.timestamp}</td>
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">{log.user}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{log.action}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{log.resource}</td>
                  <td className="px-6 py-4 text-sm">
                    <span className="px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">{log.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* System Tab */}
      {activeTab === 'system' && (
        <div className="grid grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-bold mb-4">System Health</h3>
            <div className="space-y-3">
              {[
                { label: 'API Status', value: 'Operational', ok: true },
                { label: 'Database', value: 'Healthy', ok: true },
                { label: 'Cache', value: 'Operational', ok: true },
                { label: 'Uptime', value: '99.9%', ok: true },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between">
                  <span className="text-gray-700">{item.label}</span>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${item.ok ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {item.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-bold mb-4">Usage Statistics</h3>
            <div className="space-y-3">
              {[
                { label: 'Total Users', value: users.length },
                { label: 'Active Users', value: users.filter((u) => u.status === 'active').length },
                { label: 'Total Deals', value: 156 },
                { label: 'API Requests (24h)', value: '45,230' },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between">
                  <span className="text-gray-700">{item.label}</span>
                  <span className="text-gray-900 font-semibold">{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── Invite Modal ── */}
      {showInviteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-sm shadow-2xl">
            <h3 className="text-lg font-bold mb-4">Invite New User</h3>
            {inviteSuccess ? (
              <div className="text-center py-4">
                <div className="text-4xl mb-2">✅</div>
                <p className="text-green-700 font-medium">{inviteSuccess}</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                  <input
                    type="text"
                    value={inviteFullName}
                    onChange={(e) => setInviteFullName(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="Jane Smith"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                  <input
                    type="email"
                    value={inviteEmail}
                    onChange={(e) => setInviteEmail(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="user@example.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Role</label>
                  <select
                    value={inviteRole}
                    onChange={(e) => setInviteRole(e.target.value as User['role'])}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  >
                    <option value="sales_rep">Sales Rep</option>
                    <option value="manager">Manager</option>
                    <option value="admin">Admin</option>
                  </select>
                </div>
                <div className="flex gap-2 pt-2">
                  <button
                    onClick={handleInvite}
                    disabled={inviteLoading || !inviteEmail || !inviteFullName}
                    className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 font-medium"
                  >
                    {inviteLoading ? 'Sending...' : 'Send Invite'}
                  </button>
                  <button
                    onClick={() => { setShowInviteModal(false); setInviteEmail(''); setInviteFullName('') }}
                    className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── Edit Modal ── */}
      {editUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-sm shadow-2xl">
            <h3 className="text-lg font-bold mb-4">Edit User</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                <input
                  type="text"
                  value={editUser.fullName}
                  onChange={(e) => setEditUser({ ...editUser, fullName: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  value={editUser.email}
                  disabled
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg bg-gray-50 text-gray-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Role</label>
                <select
                  value={editUser.role}
                  onChange={(e) => setEditUser({ ...editUser, role: e.target.value as User['role'] })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  <option value="sales_rep">Sales Rep</option>
                  <option value="manager">Manager</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              <div className="flex gap-2 pt-2">
                <button
                  onClick={handleEditSave}
                  disabled={editLoading}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 font-medium"
                >
                  {editLoading ? 'Saving...' : 'Save Changes'}
                </button>
                <button
                  onClick={() => setEditUser(null)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Remove Confirm ── */}
      {removeUserId && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-sm shadow-2xl">
            <h3 className="text-lg font-bold mb-2">Remove User</h3>
            <p className="text-gray-600 mb-6">
              Are you sure you want to remove <strong>{users.find((u) => u.id === removeUserId)?.fullName}</strong>? This action cannot be undone.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => handleRemove(removeUserId)}
                className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium"
              >
                Remove
              </button>
              <button
                onClick={() => setRemoveUserId(null)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
