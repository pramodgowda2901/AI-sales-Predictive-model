import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from 'react-query'
import { apiClient } from '../services/api'
import PaymentModal from '../components/PaymentModal'
import BackButton from '../components/BackButton'

export default function BillingPage() {
  const queryClient = useQueryClient()
  const [selectedTier, setSelectedTier] = useState('')
  const [showPayment, setShowPayment] = useState(false)
  const [userEmail, setUserEmail] = useState('')

  const { data: billing, isLoading } = useQuery('billing', () => apiClient.getBillingInfo())

  const upgradeMutation = useMutation((newTier: string) => apiClient.updateBillingTier(newTier), {
    onSuccess: () => {
      queryClient.invalidateQueries('billing')
      setSelectedTier('')
      setShowPayment(false)
    },
  })

  const handleUpgrade = (tier: string) => {
    setSelectedTier(tier)
    // Get user email from localStorage or use demo
    const user = localStorage.getItem('user')
    if (user) {
      const userData = JSON.parse(user)
      setUserEmail(userData.email)
    } else {
      setUserEmail('demo@example.com')
    }
    setShowPayment(true)
  }

  const handlePaymentSuccess = (tier: string) => {
    upgradeMutation.mutate(tier)
  }

  if (isLoading) {
    return <div className="text-center py-8">Loading billing information...</div>
  }

  const tiers = [
    {
      name: 'starter',
      displayName: 'Starter',
      price: 99,
      features: ['5 Users', '100 Deals', '10K API Requests/month', 'Basic Support'],
      limits: billing?.tierLimits,
    },
    {
      name: 'growth',
      displayName: 'Growth',
      price: 299,
      features: ['25 Users', '1K Deals', '100K API Requests/month', 'Priority Support', 'Advanced Analytics'],
      limits: billing?.tierLimits,
    },
    {
      name: 'enterprise',
      displayName: 'Enterprise',
      price: 999,
      features: ['Unlimited Users', 'Unlimited Deals', '1M API Requests/month', '24/7 Support', 'Custom Integrations'],
      limits: billing?.tierLimits,
    },
  ]

  const getTierPrice = (tierName: string) => {
    const tier = tiers.find((t) => t.name === tierName)
    return tier?.price || 0
  }

  const getUsagePercentage = (used: number, limit: number) => {
    return Math.min(100, (used / limit) * 100)
  }

  const getUsageColor = (percentage: number) => {
    if (percentage >= 90) return 'bg-red-500'
    if (percentage >= 70) return 'bg-yellow-500'
    return 'bg-green-500'
  }

  return (
    <div>
      <BackButton />
      <h1 className="text-3xl font-bold mb-8">Billing & Subscription</h1>

      <div className="bg-white p-6 rounded-lg shadow mb-8">
        <h2 className="text-xl font-bold mb-6">Current Plan</h2>
        <div className="grid grid-cols-4 gap-4">
          <div>
            <p className="text-gray-600 text-sm font-medium">Current Tier</p>
            <p className="text-2xl font-bold capitalize mt-2">{billing?.currentTier}</p>
          </div>
          <div>
            <p className="text-gray-600 text-sm font-medium">Monthly Cost</p>
            <p className="text-2xl font-bold mt-2">${billing?.monthlyPrice}</p>
          </div>
          <div>
            <p className="text-gray-600 text-sm font-medium">Next Billing Date</p>
            <p className="text-lg mt-2">{new Date(billing?.nextBillingDate || '').toLocaleDateString()}</p>
          </div>
          <div>
            <p className="text-gray-600 text-sm font-medium">Status</p>
            <p className="text-lg capitalize mt-2">
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                {billing?.status}
              </span>
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow mb-8">
        <h2 className="text-xl font-bold mb-6">Usage This Month</h2>
        <div className="space-y-6">
          <div>
            <div className="flex justify-between items-center mb-2">
              <p className="text-sm font-medium text-gray-700">API Requests</p>
              <p className="text-sm font-semibold">
                {billing?.usageMetrics.apiRequests.toLocaleString()} / {billing?.tierLimits.maxApiRequests.toLocaleString()}
              </p>
            </div>
            <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all ${getUsageColor(getUsagePercentage(billing?.usageMetrics.apiRequests || 0, billing?.tierLimits.maxApiRequests || 1))}`}
                style={{ width: `${getUsagePercentage(billing?.usageMetrics.apiRequests || 0, billing?.tierLimits.maxApiRequests || 1)}%` }}
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <p className="text-sm font-medium text-gray-700">Users</p>
              <p className="text-sm font-semibold">
                {billing?.usageMetrics.users} / {billing?.tierLimits.maxUsers}
              </p>
            </div>
            <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all ${getUsageColor(getUsagePercentage(billing?.usageMetrics.users || 0, billing?.tierLimits.maxUsers || 1))}`}
                style={{ width: `${getUsagePercentage(billing?.usageMetrics.users || 0, billing?.tierLimits.maxUsers || 1)}%` }}
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <p className="text-sm font-medium text-gray-700">Deals</p>
              <p className="text-sm font-semibold">
                {billing?.usageMetrics.deals} / {billing?.tierLimits.maxDeals}
              </p>
            </div>
            <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all ${getUsageColor(getUsagePercentage(billing?.usageMetrics.deals || 0, billing?.tierLimits.maxDeals || 1))}`}
                style={{ width: `${getUsagePercentage(billing?.usageMetrics.deals || 0, billing?.tierLimits.maxDeals || 1)}%` }}
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <p className="text-sm font-medium text-gray-700">Predictions</p>
              <p className="text-sm font-semibold">{billing?.usageMetrics.predictions.toLocaleString()}</p>
            </div>
            <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
              <div className="h-full bg-blue-500" style={{ width: '45%' }} />
            </div>
          </div>
        </div>
      </div>

      <div>
        <h2 className="text-xl font-bold mb-6">Available Plans</h2>
        <div className="grid grid-cols-3 gap-6">
          {tiers.map((tier) => (
            <div
              key={tier.name}
              className={`rounded-lg shadow-lg overflow-hidden transition-transform hover:scale-105 ${
                tier.name === billing?.currentTier ? 'ring-2 ring-blue-600' : ''
              }`}
            >
              <div className="bg-white p-6">
                <h3 className="text-lg font-bold mb-2">{tier.displayName}</h3>
                <p className="text-3xl font-bold mb-6">${tier.price}</p>
                <p className="text-sm text-gray-600 mb-6">/month</p>

                <ul className="space-y-3 mb-6">
                  {tier.features.map((feature) => (
                    <li key={feature} className="text-sm text-gray-700 flex items-center">
                      <span className="text-green-600 mr-2">✓</span>
                      {feature}
                    </li>
                  ))}
                </ul>

                {tier.name === billing?.currentTier ? (
                  <button disabled className="w-full px-4 py-2 bg-gray-400 text-white rounded font-medium">
                    Current Plan
                  </button>
                ) : (
                  <button
                    onClick={() => handleUpgrade(tier.name)}
                    className="w-full px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 font-medium transition-colors"
                  >
                    {getTierPrice(tier.name) > getTierPrice(billing?.currentTier || 'starter') ? 'Upgrade' : 'Downgrade'}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {showPayment && (
        <PaymentModal
          isOpen={showPayment}
          tier={selectedTier}
          amount={getTierPrice(selectedTier)}
          email={userEmail}
          onClose={() => setShowPayment(false)}
          onSuccess={handlePaymentSuccess}
        />
      )}
    </div>
  )
}
