import { useState } from 'react'
import BackButton from '../components/BackButton'

// Data keyed by date range so switching actually changes the numbers
const DATA_BY_RANGE = {
  week: {
    totalPipelineValue: 420000,
    weightedPipelineValue: 185000,
    averageDealCycle: 12,
    winRate: 28,
    forecastAccuracy: 81,
    activeDeals: 18,
    closedDeals: 4,
    stageDistribution: [
      { stage: 'Prospecting', count: 6, value: 60000 },
      { stage: 'Qualification', count: 5, value: 80000 },
      { stage: 'Proposal', count: 4, value: 120000 },
      { stage: 'Negotiation', count: 3, value: 160000 },
    ],
    trend: [
      { label: 'Mon', value: 45000, forecast: 42000 },
      { label: 'Tue', value: 62000, forecast: 58000 },
      { label: 'Wed', value: 38000, forecast: 50000 },
      { label: 'Thu', value: 71000, forecast: 65000 },
      { label: 'Fri', value: 55000, forecast: 60000 },
    ],
    topPerformers: [
      { name: 'John Doe', deals: 5, value: 95000, winRate: 40 },
      { name: 'Jane Smith', deals: 4, value: 78000, winRate: 35 },
      { name: 'Bob Johnson', deals: 3, value: 52000, winRate: 25 },
    ],
  },
  month: {
    totalPipelineValue: 2500000,
    weightedPipelineValue: 1250000,
    averageDealCycle: 45,
    winRate: 32,
    forecastAccuracy: 87,
    activeDeals: 156,
    closedDeals: 24,
    stageDistribution: [
      { stage: 'Prospecting', count: 45, value: 450000 },
      { stage: 'Qualification', count: 38, value: 520000 },
      { stage: 'Proposal', count: 42, value: 680000 },
      { stage: 'Negotiation', count: 31, value: 850000 },
    ],
    trend: [
      { label: 'Week 1', value: 480000, forecast: 460000 },
      { label: 'Week 2', value: 620000, forecast: 590000 },
      { label: 'Week 3', value: 710000, forecast: 680000 },
      { label: 'Week 4', value: 690000, forecast: 720000 },
    ],
    topPerformers: [
      { name: 'John Doe', deals: 24, value: 450000, winRate: 42 },
      { name: 'Jane Smith', deals: 18, value: 380000, winRate: 39 },
      { name: 'Bob Johnson', deals: 15, value: 320000, winRate: 27 },
    ],
  },
  quarter: {
    totalPipelineValue: 7800000,
    weightedPipelineValue: 3900000,
    averageDealCycle: 60,
    winRate: 35,
    forecastAccuracy: 89,
    activeDeals: 312,
    closedDeals: 89,
    stageDistribution: [
      { stage: 'Prospecting', count: 120, value: 1200000 },
      { stage: 'Qualification', count: 95, value: 1800000 },
      { stage: 'Proposal', count: 62, value: 2100000 },
      { stage: 'Negotiation', count: 35, value: 2700000 },
    ],
    trend: [
      { label: 'Jan', value: 2100000, forecast: 2050000 },
      { label: 'Feb', value: 2400000, forecast: 2350000 },
      { label: 'Mar', value: 3300000, forecast: 3100000 },
    ],
    topPerformers: [
      { name: 'John Doe', deals: 68, value: 1350000, winRate: 44 },
      { name: 'Jane Smith', deals: 54, value: 1100000, winRate: 41 },
      { name: 'Bob Johnson', deals: 42, value: 890000, winRate: 31 },
    ],
  },
  year: {
    totalPipelineValue: 28500000,
    weightedPipelineValue: 14200000,
    averageDealCycle: 72,
    winRate: 38,
    forecastAccuracy: 91,
    activeDeals: 890,
    closedDeals: 312,
    stageDistribution: [
      { stage: 'Prospecting', count: 380, value: 3800000 },
      { stage: 'Qualification', count: 290, value: 6200000 },
      { stage: 'Proposal', count: 145, value: 8500000 },
      { stage: 'Negotiation', count: 75, value: 10000000 },
    ],
    trend: [
      { label: 'Q1', value: 5800000, forecast: 5500000 },
      { label: 'Q2', value: 7200000, forecast: 6900000 },
      { label: 'Q3', value: 8100000, forecast: 7800000 },
      { label: 'Q4', value: 7400000, forecast: 7600000 },
    ],
    topPerformers: [
      { name: 'John Doe', deals: 210, value: 4800000, winRate: 46 },
      { name: 'Jane Smith', deals: 178, value: 3900000, winRate: 43 },
      { name: 'Bob Johnson', deals: 145, value: 3100000, winRate: 34 },
    ],
  },
}

export default function AnalyticsPage() {
  const [dateRange, setDateRange] = useState<'week' | 'month' | 'quarter' | 'year'>('month')
  const [exportMsg, setExportMsg] = useState('')

  const data = DATA_BY_RANGE[dateRange]

  const fmt = (n: number) =>
    n >= 1_000_000 ? `$${(n / 1_000_000).toFixed(1)}M` : `$${(n / 1_000).toFixed(0)}K`

  const handleExport = (format: string) => {
    const rows = [
      ['Metric', 'Value'],
      ['Total Pipeline', fmt(data.totalPipelineValue)],
      ['Weighted Pipeline', fmt(data.weightedPipelineValue)],
      ['Win Rate', `${data.winRate}%`],
      ['Forecast Accuracy', `${data.forecastAccuracy}%`],
      ['Active Deals', String(data.activeDeals)],
      ['Closed Deals', String(data.closedDeals)],
    ]

    if (format === 'csv') {
      const csv = rows.map((r) => r.join(',')).join('\n')
      const blob = new Blob([csv], { type: 'text/csv' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `analytics-${dateRange}-${new Date().toISOString().split('T')[0]}.csv`
      a.click()
      URL.revokeObjectURL(url)
    } else {
      const json = JSON.stringify({ range: dateRange, metrics: Object.fromEntries(rows.slice(1)) }, null, 2)
      const blob = new Blob([json], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `analytics-${dateRange}-${new Date().toISOString().split('T')[0]}.json`
      a.click()
      URL.revokeObjectURL(url)
    }

    setExportMsg(`${format.toUpperCase()} exported!`)
    setTimeout(() => setExportMsg(''), 2000)
  }

  const maxStageValue = Math.max(...data.stageDistribution.map((s) => s.value))
  const maxTrendValue = Math.max(...data.trend.map((t) => t.value))

  return (
    <div>
      <BackButton />
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">Analytics & Reporting</h1>
        <div className="flex gap-2">
          {(['week', 'month', 'quarter', 'year'] as const).map((range) => (
            <button
              key={range}
              onClick={() => setDateRange(range)}
              className={`px-4 py-2 rounded font-medium transition-colors ${
                dateRange === range ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {range.charAt(0).toUpperCase() + range.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Total Pipeline', value: fmt(data.totalPipelineValue), icon: '📊', sub: `${data.activeDeals} active deals` },
          { label: 'Weighted Pipeline', value: fmt(data.weightedPipelineValue), icon: '⚖️', sub: `${data.closedDeals} closed` },
          { label: 'Win Rate', value: `${data.winRate}%`, icon: '🎯', sub: `Avg cycle: ${data.averageDealCycle}d` },
          { label: 'Forecast Accuracy', value: `${data.forecastAccuracy}%`, icon: '📈', sub: 'vs actual revenue' },
        ].map((metric) => (
          <div key={metric.label} className="bg-white p-6 rounded-lg shadow">
            <div className="text-3xl mb-2">{metric.icon}</div>
            <p className="text-sm text-gray-500 mb-1">{metric.label}</p>
            <p className="text-2xl font-bold text-gray-900">{metric.value}</p>
            <p className="text-xs text-gray-400 mt-1">{metric.sub}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-6 mb-8">
        {/* Pipeline by Stage */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-bold mb-4">Pipeline by Stage</h3>
          <div className="space-y-4">
            {data.stageDistribution.map((s) => (
              <div key={s.stage}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">{s.stage}</span>
                  <span className="text-sm text-gray-500">{s.count} deals · {fmt(s.value)}</span>
                </div>
                <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-500 rounded-full transition-all duration-500"
                    style={{ width: `${(s.value / maxStageValue) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Revenue Trend */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-bold mb-4">Revenue vs Forecast</h3>
          <div className="space-y-4">
            {data.trend.map((t) => (
              <div key={t.label}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700 w-16">{t.label}</span>
                  <span className="text-xs text-gray-500">
                    Actual {fmt(t.value)} · Forecast {fmt(t.forecast)}
                  </span>
                </div>
                <div className="space-y-1">
                  <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-500 rounded-full transition-all duration-500"
                      style={{ width: `${(t.value / maxTrendValue) * 100}%` }}
                    />
                  </div>
                  <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-purple-300 rounded-full transition-all duration-500"
                      style={{ width: `${(t.forecast / maxTrendValue) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
            <div className="flex gap-4 pt-2 text-xs text-gray-500">
              <span className="flex items-center gap-1"><span className="w-3 h-2 bg-blue-500 rounded inline-block" /> Actual</span>
              <span className="flex items-center gap-1"><span className="w-3 h-2 bg-purple-300 rounded inline-block" /> Forecast</span>
            </div>
          </div>
        </div>
      </div>

      {/* Top Performers */}
      <div className="bg-white p-6 rounded-lg shadow mb-8">
        <h3 className="text-lg font-bold mb-4">Top Performers — {dateRange.charAt(0).toUpperCase() + dateRange.slice(1)}</h3>
        <table className="w-full">
          <thead className="border-b border-gray-200">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Name</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Deals</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Pipeline Value</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Win Rate</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {data.topPerformers.map((p, i) => (
              <tr key={p.name} className="hover:bg-gray-50">
                <td className="px-4 py-3 text-sm font-medium text-gray-900">
                  <span className="mr-2 text-gray-400">#{i + 1}</span>{p.name}
                </td>
                <td className="px-4 py-3 text-sm text-gray-600">{p.deals}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{fmt(p.value)}</td>
                <td className="px-4 py-3 text-sm">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    p.winRate >= 40 ? 'bg-green-100 text-green-800' : p.winRate >= 30 ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-700'
                  }`}>
                    {p.winRate}%
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Export */}
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold">Export Report</h3>
          {exportMsg && <span className="text-green-600 text-sm font-medium">✓ {exportMsg}</span>}
        </div>
        <div className="flex gap-3">
          <button onClick={() => handleExport('csv')} className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
            📈 Export as CSV
          </button>
          <button onClick={() => handleExport('json')} className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700">
            📋 Export as JSON
          </button>
        </div>
      </div>
    </div>
  )
}
