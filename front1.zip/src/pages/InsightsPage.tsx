import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from 'react-query'
import { Link } from 'react-router-dom'
import { apiClient } from '../services/api'
import { Insight } from '../services/mockData'
import BackButton from '../components/BackButton'

export default function InsightsPage() {
  const queryClient = useQueryClient()
  const [filterType, setFilterType] = useState('')
  const [filterMinImpact, setFilterMinImpact] = useState('')
  const [search, setSearch] = useState('')
  const [actedIds, setActedIds] = useState<Set<string>>(new Set())
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(new Set())
  const [toastMsg, setToastMsg] = useState('')

  const { data: insights = [], isLoading } = useQuery('insights', () => apiClient.getInsights())

  const showToast = (msg: string) => {
    setToastMsg(msg)
    setTimeout(() => setToastMsg(''), 3000)
  }

  const actMutation = useMutation((id: string) => apiClient.actOnInsight(id), {
    onSuccess: (_data, id) => {
      setActedIds((prev) => new Set([...prev, id]))
      queryClient.invalidateQueries('insights')
      showToast('✅ Insight marked as acted upon — feedback sent to AI model')
    },
  })

  const dismissMutation = useMutation((id: string) => apiClient.dismissInsight(id), {
    onSuccess: (_data, id) => {
      setDismissedIds((prev) => new Set([...prev, id]))
      queryClient.invalidateQueries('insights')
      showToast('🔕 Insight dismissed — will not resurface for 7 days')
    },
  })

  const types = [...new Set((insights as Insight[]).map((i) => i.type))]

  const filtered = (insights as Insight[]).filter((i) => {
    if (dismissedIds.has(i.id)) return false
    if (filterType && i.type !== filterType) return false
    if (filterMinImpact && i.revenueImpact < parseFloat(filterMinImpact)) return false
    if (search && !i.text.toLowerCase().includes(search.toLowerCase()) && !i.type.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const typeColor: Record<string, string> = {
    'Stalled Deal': 'bg-red-100 text-red-800 border-red-300',
    'High Win Probability': 'bg-green-100 text-green-800 border-green-300',
    'Engagement Spike': 'bg-blue-100 text-blue-800 border-blue-300',
    'Competitor Mention': 'bg-orange-100 text-orange-800 border-orange-300',
    'Budget Concern': 'bg-yellow-100 text-yellow-800 border-yellow-300',
    'Timeline Risk': 'bg-purple-100 text-purple-800 border-purple-300',
    'Next Best Action': 'bg-indigo-100 text-indigo-800 border-indigo-300',
    'Upsell Opportunity': 'bg-pink-100 text-pink-800 border-pink-300',
  }

  const impactColor = (n: number) =>
    n >= 150000 ? 'bg-green-100 text-green-800' :
    n >= 100000 ? 'bg-blue-100 text-blue-800' :
    n >= 50000  ? 'bg-yellow-100 text-yellow-800' :
                  'bg-orange-100 text-orange-800'

  if (isLoading) return <div className="text-center py-8 text-gray-600 dark:text-slate-400">Loading insights...</div>

  return (
    <div>
      <BackButton />

      {/* Toast notification */}
      {toastMsg && (
        <div className="fixed top-6 right-6 z-50 px-5 py-3 bg-gray-900 text-white rounded-xl shadow-2xl text-sm font-medium animate-fade-in">
          {toastMsg}
        </div>
      )}

      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold dark:text-slate-100">Insights</h1>
        <div className="flex gap-3 text-sm">
          <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full font-medium">{filtered.length} active</span>
          <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full font-medium">{actedIds.size} acted</span>
          <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full font-medium">{dismissedIds.size} dismissed</span>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-4 mb-6 flex flex-wrap gap-3 items-end">
        <div className="flex-1 min-w-48">
          <label className="block text-xs font-medium text-gray-600 dark:text-slate-400 mb-1">Search</label>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search insights..."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-600 dark:text-slate-400 mb-1">Type</label>
          <select value={filterType} onChange={(e) => setFilterType(e.target.value)} className="px-3 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100">
            <option value="">All types</option>
            {types.map((t) => <option key={t}>{t}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-600 dark:text-slate-400 mb-1">Min Impact ($)</label>
          <input type="number" value={filterMinImpact} onChange={(e) => setFilterMinImpact(e.target.value)} placeholder="0" className="w-32 px-3 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
        </div>
        {(filterType || filterMinImpact || search) && (
          <button onClick={() => { setFilterType(''); setFilterMinImpact(''); setSearch('') }} className="px-3 py-2 text-sm text-red-600 hover:text-red-700 font-medium">
            Clear
          </button>
        )}
        <span className="text-sm text-gray-500 dark:text-slate-400 ml-auto">{filtered.length} insight{filtered.length !== 1 ? 's' : ''}</span>
      </div>

      {/* Insight cards */}
      <div className="space-y-4">
        {filtered.map((insight: Insight) => {
          const isActed = actedIds.has(insight.id)

          return (
            <div
              key={insight.id}
              className={`bg-white dark:bg-slate-800 p-6 rounded-xl shadow transition-all ${
                isActed
                  ? 'border-2 border-green-400 dark:border-green-600 opacity-80'
                  : 'border border-gray-200 dark:border-slate-700 hover:shadow-lg'
              }`}
            >
              {/* Acted banner */}
              {isActed && (
                <div className="flex items-center gap-2 mb-3 px-3 py-2 bg-green-50 dark:bg-green-900/30 border border-green-200 dark:border-green-700 rounded-lg">
                  <span className="text-green-600 dark:text-green-400 text-lg">✅</span>
                  <div>
                    <p className="text-sm font-semibold text-green-800 dark:text-green-300">Action recorded</p>
                    <p className="text-xs text-green-700 dark:text-green-400">Your action has been logged and sent as feedback to improve the AI model.</p>
                  </div>
                </div>
              )}

              {/* Type + impact badges */}
              <div className="flex flex-wrap items-center gap-2 mb-3">
                <span className={`px-3 py-1 rounded-full text-sm font-medium border ${typeColor[insight.type] || 'bg-gray-100 text-gray-800 border-gray-300'}`}>
                  {insight.type}
                </span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${impactColor(insight.revenueImpact)}`}>
                  💰 ${insight.revenueImpact.toLocaleString()} potential impact
                </span>
              </div>

              {/* Insight text */}
              <p className="text-gray-800 dark:text-slate-200 mb-4 leading-relaxed">{insight.text}</p>

              {/* What "Act Upon" means */}
              {!isActed && (
                <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-lg text-xs text-blue-700 dark:text-blue-300">
                  <strong>Act Upon</strong> — marks this insight as addressed, logs the action with a timestamp, and sends feedback to the AI model to improve future predictions.
                </div>
              )}

              {/* Actions */}
              <div className="flex items-center justify-between">
                <Link to={`/deals/${insight.dealId}`} className="text-sm text-blue-600 hover:text-blue-800 dark:text-blue-400 font-medium">
                  View deal →
                </Link>

                {!isActed ? (
                  <div className="flex gap-2">
                    <button
                      onClick={() => actMutation.mutate(insight.id)}
                      disabled={actMutation.isLoading}
                      className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 active:scale-95 disabled:bg-gray-400 text-sm font-semibold transition-all shadow-sm"
                    >
                      {actMutation.isLoading ? '⏳ Recording…' : '✅ Act Upon'}
                    </button>
                    <button
                      onClick={() => dismissMutation.mutate(insight.id)}
                      disabled={dismissMutation.isLoading}
                      className="px-4 py-2 bg-gray-200 text-gray-700 dark:bg-slate-700 dark:text-slate-300 rounded-lg hover:bg-gray-300 dark:hover:bg-slate-600 active:scale-95 text-sm font-medium transition-all"
                    >
                      {dismissMutation.isLoading ? '⏳' : '🔕 Dismiss'}
                    </button>
                  </div>
                ) : (
                  <span className="text-sm text-green-600 dark:text-green-400 font-semibold flex items-center gap-1">
                    ✅ Acted upon
                  </span>
                )}
              </div>
            </div>
          )
        })}

        {filtered.length === 0 && (
          <div className="text-center py-16 bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700">
            <div className="text-4xl mb-3">💡</div>
            <p className="text-gray-600 dark:text-slate-400 font-medium">No insights match your filters</p>
            <p className="text-sm text-gray-400 dark:text-slate-500 mt-1">Try clearing the filters or check back later</p>
          </div>
        )}
      </div>

      {/* Dismissed section */}
      {dismissedIds.size > 0 && (
        <div className="mt-8 p-4 bg-gray-50 dark:bg-slate-900 rounded-xl border border-gray-200 dark:border-slate-700">
          <p className="text-sm text-gray-500 dark:text-slate-400 text-center">
            🔕 {dismissedIds.size} insight{dismissedIds.size !== 1 ? 's' : ''} dismissed — will resurface after 7 days
          </p>
        </div>
      )}
    </div>
  )
}
