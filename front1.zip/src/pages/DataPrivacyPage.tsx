import { useState } from 'react'
import { apiClient } from '../services/api'
import BackButton from '../components/BackButton'

export default function DataPrivacyPage() {
  const [exportLoading, setExportLoading] = useState(false)
  const [exportDone, setExportDone] = useState(false)
  const [deleteLoading, setDeleteLoading] = useState(false)
  const [deleteConfirm, setDeleteConfirm] = useState('')
  const [deleteMsg, setDeleteMsg] = useState('')
  const [showDeleteModal, setShowDeleteModal] = useState(false)

  const handleExportData = async () => {
    setExportLoading(true)
    try {
      await apiClient.requestDataExport()
    } catch {}
    setExportDone(true)
    setExportLoading(false)
    setTimeout(() => setExportDone(false), 4000)
  }

  const handleDeleteData = async () => {
    if (deleteConfirm !== 'DELETE') return
    setDeleteLoading(true)
    try {
      await apiClient.requestDataDeletion()
    } catch {}
    setDeleteMsg('Data deletion scheduled. You will receive a confirmation email within 30 days.')
    setDeleteLoading(false)
    setShowDeleteModal(false)
    setDeleteConfirm('')
  }

  return (
    <div className="max-w-2xl">
      <BackButton />
      <h1 className="text-3xl font-bold mb-2">Data Privacy</h1>
      <p className="text-gray-600 mb-8">Manage your personal data in compliance with GDPR and CCPA</p>

      {deleteMsg && (
        <div className="mb-6 p-4 bg-yellow-50 border border-yellow-300 text-yellow-800 rounded-lg">
          ⚠️ {deleteMsg}
        </div>
      )}

      <div className="space-y-4">
        {/* Export Data */}
        <div className="bg-white p-6 rounded-xl shadow">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="font-bold text-gray-900 mb-1">Export Your Data</h3>
              <p className="text-sm text-gray-600">
                Download a complete archive of all your personal data including deals, signals, predictions, insights, and activity history. Delivered as a JSON archive within 72 hours.
              </p>
            </div>
            <span className="text-2xl ml-4">📦</span>
          </div>
          <button
            onClick={handleExportData}
            disabled={exportLoading || exportDone}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 font-medium text-sm"
          >
            {exportLoading ? 'Requesting...' : exportDone ? '✓ Request submitted — check your email' : 'Request Data Export'}
          </button>
        </div>

        {/* Data Retention */}
        <div className="bg-white p-6 rounded-xl shadow">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="font-bold text-gray-900 mb-1">Data Retention Policy</h3>
              <p className="text-sm text-gray-600 mb-3">How long we keep your data:</p>
              <div className="space-y-2 text-sm">
                {[
                  { label: 'Active deals', retention: 'Until deleted + 90 days' },
                  { label: 'Audit logs', retention: '12 months (WORM)' },
                  { label: 'Email delivery events', retention: '24 months' },
                  { label: 'Prediction history', retention: '24 months' },
                  { label: 'Billing records', retention: '7 years (legal)' },
                ].map((item) => (
                  <div key={item.label} className="flex items-center justify-between py-1 border-b border-gray-100">
                    <span className="text-gray-700">{item.label}</span>
                    <span className="text-gray-500 text-xs">{item.retention}</span>
                  </div>
                ))}
              </div>
            </div>
            <span className="text-2xl ml-4">📋</span>
          </div>
        </div>

        {/* Compliance */}
        <div className="bg-white p-6 rounded-xl shadow">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="font-bold text-gray-900 mb-1">Compliance</h3>
              <div className="flex flex-wrap gap-2 mt-3">
                {['GDPR', 'CCPA', 'SOC 2 Type II', 'ISO 27001', 'HIPAA Ready'].map((badge) => (
                  <span key={badge} className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
                    ✓ {badge}
                  </span>
                ))}
              </div>
              <p className="text-sm text-gray-600 mt-3">
                All data is encrypted at rest (AES-256 via AWS KMS) and in transit (TLS 1.2+). Audit logs are stored with WORM protection.
              </p>
            </div>
            <span className="text-2xl ml-4">🔒</span>
          </div>
        </div>

        {/* Delete Data */}
        <div className="bg-white p-6 rounded-xl shadow border border-red-200">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="font-bold text-red-700 mb-1">Delete All Data</h3>
              <p className="text-sm text-gray-600">
                Permanently delete all your personal data from our systems. This action cannot be undone. All data will be removed within 30 days and you will receive written confirmation.
              </p>
            </div>
            <span className="text-2xl ml-4">🗑️</span>
          </div>
          <button
            onClick={() => setShowDeleteModal(true)}
            className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium text-sm"
          >
            Request Data Deletion
          </button>
        </div>
      </div>

      {/* Delete Confirm Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-sm w-full shadow-2xl">
            <h3 className="text-lg font-bold text-red-700 mb-2">⚠️ Delete All Data</h3>
            <p className="text-sm text-gray-600 mb-4">
              This will permanently delete all your data. Type <strong>DELETE</strong> to confirm.
            </p>
            <input
              type="text"
              value={deleteConfirm}
              onChange={(e) => setDeleteConfirm(e.target.value)}
              placeholder="Type DELETE to confirm"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 outline-none mb-4"
            />
            <div className="flex gap-2">
              <button
                onClick={handleDeleteData}
                disabled={deleteConfirm !== 'DELETE' || deleteLoading}
                className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:bg-gray-400 font-medium"
              >
                {deleteLoading ? 'Processing...' : 'Delete My Data'}
              </button>
              <button
                onClick={() => { setShowDeleteModal(false); setDeleteConfirm('') }}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
