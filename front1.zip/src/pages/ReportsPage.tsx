import { useState } from 'react'
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts'
import BackButton from '../components/BackButton'

const METRICS = ['Total Pipeline Value', 'Weighted Pipeline', 'Win Rate', 'Avg Deal Cycle', 'Forecast Accuracy', 'Deals Created', 'Deals Closed', 'Revenue Closed', 'Prediction Count']
const DIMENSIONS = ['Stage', 'Owner', 'Team', 'Product Line', 'Region', 'Month', 'Quarter']
const CHART_TYPES = [
  { id: 'bar', label: 'Bar Chart', icon: '📊' },
  { id: 'line', label: 'Line Chart', icon: '📈' },
  { id: 'pie', label: 'Pie Chart', icon: '🥧' },
  { id: 'table', label: 'Table', icon: '📋' },
]

interface SavedReport {
  id: string
  name: string
  metrics: string[]
  dimension: string
  chartType: string
  dateRange: string
  createdAt: string
}

const SAVED_REPORTS: SavedReport[] = [
  { id: '1', name: 'Monthly Pipeline Summary', metrics: ['Total Pipeline Value', 'Win Rate'], dimension: 'Month', chartType: 'line', dateRange: 'last_12_months', createdAt: '2024-04-15' },
  { id: '2', name: 'Team Performance', metrics: ['Deals Closed', 'Revenue Closed'], dimension: 'Owner', chartType: 'bar', dateRange: 'this_quarter', createdAt: '2024-04-10' },
  { id: '3', name: 'Stage Conversion', metrics: ['Deals Created', 'Deals Closed'], dimension: 'Stage', chartType: 'bar', dateRange: 'this_month', createdAt: '2024-04-01' },
]

export default function ReportsPage() {
  const [tab, setTab] = useState<'builder' | 'saved'>('builder')
  const [reportName, setReportName] = useState('')
  const [selectedMetrics, setSelectedMetrics] = useState<string[]>(['Total Pipeline Value'])
  const [dimension, setDimension] = useState('Month')
  const [chartType, setChartType] = useState('bar')
  const [dateRange, setDateRange] = useState('this_month')
  const [savedReports, setSavedReports] = useState(SAVED_REPORTS)
  const [saveMsg, setSaveMsg] = useState('')
  const [exportMsg, setExportMsg] = useState('')
  const [scheduleEmail, setScheduleEmail] = useState(false)
  const [scheduleFreq, setScheduleFreq] = useState('weekly')

  const toggleMetric = (m: string) => {
    setSelectedMetrics((prev) => prev.includes(m) ? prev.filter((x) => x !== m) : [...prev, m])
  }

  const handleSave = () => {
    if (!reportName.trim()) { setSaveMsg('Please enter a report name'); return }
    const newReport: SavedReport = {
      id: `r-${Date.now()}`,
      name: reportName,
      metrics: selectedMetrics,
      dimension,
      chartType,
      dateRange,
      createdAt: new Date().toISOString().split('T')[0],
    }
    setSavedReports((prev) => [newReport, ...prev])
    setSaveMsg(`Report "${reportName}" saved!`)
    setReportName('')
    setTimeout(() => setSaveMsg(''), 3000)
  }

  const handleExport = (format: 'csv' | 'json') => {
    const data = { reportName: reportName || 'Custom Report', metrics: selectedMetrics, dimension, dateRange, generatedAt: new Date().toISOString(), data: [] }
    const content = format === 'csv'
      ? `Report,${reportName || 'Custom Report'}\nMetrics,${selectedMetrics.join(';')}\nDimension,${dimension}\nDate Range,${dateRange}`
      : JSON.stringify(data, null, 2)
    const blob = new Blob([content], { type: format === 'csv' ? 'text/csv' : 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `report-${new Date().toISOString().split('T')[0]}.${format}`
    a.click()
    URL.revokeObjectURL(url)
    setExportMsg(`Exported as ${format.toUpperCase()}`)
    setTimeout(() => setExportMsg(''), 2000)
  }

  const handleDeleteReport = (id: string) => {
    setSavedReports((prev) => prev.filter((r) => r.id !== id))
  }

  // Mock chart preview data
  const previewData = [
    { label: 'Jan', value: 420000 },
    { label: 'Feb', value: 580000 },
    { label: 'Mar', value: 510000 },
    { label: 'Apr', value: 690000 },
    { label: 'May', value: 620000 },
    { label: 'Jun', value: 750000 },
  ]
  const maxVal = Math.max(...previewData.map((d) => d.value))

  const PIE_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4']

  const pieData = previewData.map((d, i) => ({
    name: d.label,
    value: d.value,
    color: PIE_COLORS[i],
  }))

  const renderChart = () => {
    const tooltipStyle = {
      backgroundColor: '#1e293b',
      border: 'none',
      borderRadius: 8,
      color: '#f1f5f9',
    }
    const fmt = (v: any) => `$${(v / 1000).toFixed(0)}K`

    if (chartType === 'table') {
      return (
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-200 dark:border-slate-700">
              {['Period', ...selectedMetrics.slice(0, 3)].map((h) => (
                <th key={h} className="py-2 text-left font-semibold text-gray-700 dark:text-slate-300">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {previewData.map((d) => (
              <tr key={d.label} className="border-b border-gray-100 dark:border-slate-700">
                <td className="py-2 text-gray-700 dark:text-slate-300">{d.label}</td>
                <td className="py-2 font-medium text-gray-900 dark:text-slate-100">${(d.value / 1000).toFixed(0)}K</td>
              </tr>
            ))}
          </tbody>
        </table>
      )
    }

    if (chartType === 'bar') {
      return (
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={previewData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#9ca3af' }} />
            <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} tickFormatter={fmt} />
            <Tooltip formatter={fmt} contentStyle={tooltipStyle} />
            <Bar dataKey="value" fill="#3b82f6" name={selectedMetrics[0] || 'Value'} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      )
    }

    if (chartType === 'line') {
      return (
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={previewData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#9ca3af' }} />
            <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} tickFormatter={fmt} />
            <Tooltip formatter={fmt} contentStyle={tooltipStyle} />
            <Legend />
            <Line
              type="monotone"
              dataKey="value"
              stroke="#3b82f6"
              strokeWidth={2}
              dot={{ fill: '#3b82f6', r: 4 }}
              activeDot={{ r: 6 }}
              name={selectedMetrics[0] || 'Value'}
            />
          </LineChart>
        </ResponsiveContainer>
      )
    }

    if (chartType === 'pie') {
      return (
        <ResponsiveContainer width="100%" height={220}>
          <PieChart>
            <Pie
              data={pieData}
              cx="50%"
              cy="50%"
              outerRadius={85}
              dataKey="value"
              nameKey="name"
              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              labelLine={true}
            >
              {pieData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip formatter={fmt} contentStyle={tooltipStyle} />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      )
    }

    return null
  }

  return (
    <div>
      <BackButton />
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold dark:text-slate-100">Reports</h1>
        {(saveMsg || exportMsg) && (
          <span className="text-green-600 font-medium text-sm">✓ {saveMsg || exportMsg}</span>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 border-b border-gray-200 dark:border-slate-700">
        {(['builder', 'saved'] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 font-medium border-b-2 transition-colors capitalize ${tab === t ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-600 hover:text-gray-900 dark:text-slate-400'}`}>
            {t === 'builder' ? '🔧 Report Builder' : `📁 Saved Reports (${savedReports.length})`}
          </button>
        ))}
      </div>

      {tab === 'builder' && (
        <div className="grid grid-cols-3 gap-6">
          {/* Config Panel */}
          <div className="col-span-1 space-y-4">
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-4">
              <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-3">Report Name</h3>
              <input type="text" value={reportName} onChange={(e) => setReportName(e.target.value)} placeholder="e.g. Monthly Pipeline" className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-4">
              <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-3">Metrics</h3>
              <div className="space-y-2">
                {METRICS.map((m) => (
                  <label key={m} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 dark:hover:bg-slate-700 p-1 rounded">
                    <input type="checkbox" checked={selectedMetrics.includes(m)} onChange={() => toggleMetric(m)} className="w-4 h-4 rounded text-blue-600" />
                    <span className="text-sm text-gray-700 dark:text-slate-300">{m}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-4">
              <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-3">Group By</h3>
              <select value={dimension} onChange={(e) => setDimension(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100">
                {DIMENSIONS.map((d) => <option key={d}>{d}</option>)}
              </select>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-4">
              <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-3">Date Range</h3>
              <select value={dateRange} onChange={(e) => setDateRange(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100">
                <option value="this_week">This Week</option>
                <option value="this_month">This Month</option>
                <option value="this_quarter">This Quarter</option>
                <option value="this_year">This Year</option>
                <option value="last_12_months">Last 12 Months</option>
              </select>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-4">
              <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-3">Schedule Email</h3>
              <label className="flex items-center gap-2 mb-3 cursor-pointer">
                <div onClick={() => setScheduleEmail(!scheduleEmail)} className={`relative w-10 h-5 rounded-full transition-colors ${scheduleEmail ? 'bg-blue-600' : 'bg-gray-300'}`}>
                  <span className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${scheduleEmail ? 'translate-x-5' : ''}`} />
                </div>
                <span className="text-sm text-gray-700 dark:text-slate-300">Send by email</span>
              </label>
              {scheduleEmail && (
                <select value={scheduleFreq} onChange={(e) => setScheduleFreq(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100">
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                </select>
              )}
            </div>
          </div>

          {/* Preview Panel */}
          <div className="col-span-2 space-y-4">
            {/* Chart Type */}
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-4">
              <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-3">Chart Type</h3>
              <div className="grid grid-cols-4 gap-2">
                {CHART_TYPES.map((ct) => (
                  <button key={ct.id} onClick={() => setChartType(ct.id)} className={`p-3 rounded-lg border-2 text-center transition-colors ${chartType === ct.id ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30' : 'border-gray-200 dark:border-slate-600 hover:border-gray-300'}`}>
                    <div className="text-2xl mb-1">{ct.icon}</div>
                    <div className="text-xs font-medium text-gray-700 dark:text-slate-300">{ct.label}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Chart Preview */}
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-gray-900 dark:text-slate-100">{reportName || 'Preview'}</h3>
                <span className="text-xs text-gray-500 dark:text-slate-400">{selectedMetrics[0]} by {dimension}</span>
              </div>
              {renderChart()}
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <button onClick={handleSave} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium text-sm">
                💾 Save Report
              </button>
              <button onClick={() => handleExport('csv')} className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium text-sm">
                📥 Export CSV
              </button>
              <button onClick={() => handleExport('json')} className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-medium text-sm">
                📋 Export JSON
              </button>
            </div>
          </div>
        </div>
      )}

      {tab === 'saved' && (
        <div className="space-y-3">
          {savedReports.map((r) => (
            <div key={r.id} className="bg-white dark:bg-slate-800 rounded-xl shadow p-5 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-gray-900 dark:text-slate-100">{r.name}</h3>
                <p className="text-sm text-gray-500 dark:text-slate-400 mt-1">
                  {r.metrics.join(', ')} · by {r.dimension} · {r.dateRange.replace(/_/g, ' ')}
                </p>
                <p className="text-xs text-gray-400 dark:text-slate-500 mt-1">Created {r.createdAt}</p>
              </div>
              <div className="flex gap-2">
                <button onClick={() => { setSelectedMetrics(r.metrics); setDimension(r.dimension); setChartType(r.chartType); setDateRange(r.dateRange); setReportName(r.name); setTab('builder') }} className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">
                  Edit
                </button>
                <button onClick={() => handleExport('csv')} className="px-3 py-1.5 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700">
                  Export
                </button>
                <button onClick={() => handleDeleteReport(r.id)} className="px-3 py-1.5 border border-gray-300 text-red-600 rounded-lg text-sm font-medium hover:bg-red-50">
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
