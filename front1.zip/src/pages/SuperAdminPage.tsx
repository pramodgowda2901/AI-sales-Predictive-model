import { useState } from 'react'
import BackButton from '../components/BackButton'

const MOCK_TENANTS = [
  { id: 't1', name: 'Acme Corp', tier: 'enterprise', users: 48, deals: 312, mau: 42, predictions: 8420, status: 'active' },
  { id: 't2', name: 'TechVision Inc', tier: 'growth', users: 18, deals: 145, mau: 16, predictions: 2310, status: 'active' },
  { id: 't3', name: 'Global Solutions', tier: 'starter', users: 4, deals: 38, mau: 4, predictions: 420, status: 'active' },
  { id: 't4', name: 'Digital Dynamics', tier: 'growth', users: 22, deals: 198, mau: 19, predictions: 3100, status: 'suspended' },
  { id: 't5', name: 'CloudFirst Systems', tier: 'enterprise', users: 65, deals: 480, mau: 58, predictions: 12400, status: 'active' },
]

const HEALTH_METRICS = {
  apiP95: 342,
  errorRate5xx: 0.3,
  sagemakerErrorRate: 0.1,
  uptime: 99.97,
}

const MONTHLY_PREDICTIONS = [
  { month: 'May', count: 42000 },
  { month: 'Jun', count: 48000 },
  { month: 'Jul', count: 51000 },
  { month: 'Aug', count: 55000 },
  { month: 'Sep', count: 62000 },
  { month: 'Oct', count: 58000 },
  { month: 'Nov', count: 71000 },
  { month: 'Dec', count: 68000 },
  { month: 'Jan', count: 74000 },
  { month: 'Feb', count: 79000 },
  { month: 'Mar', count: 85000 },
  { month: 'Apr', count: 91000 },
]

const MRR_DATA = [
  { month: 'May', mrr: 28000 },
  { month: 'Jun', mrr: 31000 },
  { month: 'Jul', mrr: 34000 },
  { month: 'Aug', mrr: 38000 },
  { month: 'Sep', mrr: 42000 },
  { month: 'Oct', mrr: 45000 },
  { month: 'Nov', mrr: 49000 },
  { month: 'Dec', mrr: 52000 },
  { month: 'Jan', mrr: 56000 },
  { month: 'Feb', mrr: 61000 },
  { month: 'Mar', mrr: 67000 },
  { month: 'Apr', mrr: 72000 },
]

export default function SuperAdminPage() {
  const [activeTab, setActiveTab] = useState<'overview' | 'tenants' | 'health' | 'revenue' | 'audit'>('overview')
  const [tenants, setTenants] = useState(MOCK_TENANTS)
  const [selectedTenant, setSelectedTenant] = useState<any>(null)
  const [actionMsg, setActionMsg] = useState('')
  const [auditSearch, setAuditSearch] = useState('')

  const totalTenants = tenants.length
  const activeTenants = tenants.filter((t) => t.status === 'active').length
  const totalUsers = tenants.reduce((s, t) => s + t.users, 0)
  const totalPredictions = tenants.reduce((s, t) => s + t.predictions, 0)
  const totalMAU = tenants.reduce((s, t) => s + t.mau, 0)
  const currentMRR = MRR_DATA[MRR_DATA.length - 1].mrr
  const ARR = currentMRR * 12

  const handleSuspend = (id: string) => {
    setTenants((prev) => prev.map((t) => t.id === id ? { ...t, status: 'suspended' } : t))
    setActionMsg('Tenant suspended')
    setSelectedTenant(null)
    setTimeout(() => setActionMsg(''), 2000)
  }

  const handleReactivate = (id: string) => {
    setTenants((prev) => prev.map((t) => t.id === id ? { ...t, status: 'active' } : t))
    setActionMsg('Tenant reactivated')
    setSelectedTenant(null)
    setTimeout(() => setActionMsg(''), 2000)
  }

  const handleTierChange = (id: string, tier: string) => {
    setTenants((prev) => prev.map((t) => t.id === id ? { ...t, tier } : t))
    setActionMsg(`Tier updated to ${tier}`)
    setTimeout(() => setActionMsg(''), 2000)
  }

  const maxPredictions = Math.max(...MONTHLY_PREDICTIONS.map((m) => m.count))
  const maxMRR = Math.max(...MRR_DATA.map((m) => m.mrr))

  const auditLogs = [
    { ts: '2024-04-20 14:30', admin: 'superadmin@platform.com', action: 'Suspended tenant', tenant: 'Digital Dynamics', status: 'Success' },
    { ts: '2024-04-20 13:15', admin: 'superadmin@platform.com', action: 'Changed tier', tenant: 'TechVision Inc', status: 'Success' },
    { ts: '2024-04-20 12:00', admin: 'superadmin@platform.com', action: 'Viewed audit logs', tenant: 'Acme Corp', status: 'Success' },
    { ts: '2024-04-19 16:45', admin: 'superadmin@platform.com', action: 'Reactivated tenant', tenant: 'CloudFirst Systems', status: 'Success' },
    { ts: '2024-04-19 11:30', admin: 'superadmin@platform.com', action: 'Exported data', tenant: 'Global Solutions', status: 'Success' },
  ].filter((l) => !auditSearch || l.tenant.toLowerCase().includes(auditSearch.toLowerCase()) || l.action.toLowerCase().includes(auditSearch.toLowerCase()))

  const isHealthAlert = HEALTH_METRICS.apiP95 > 1000 || HEALTH_METRICS.errorRate5xx > 1 || HEALTH_METRICS.sagemakerErrorRate > 0.5

  return (
    <div>
      <BackButton />
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold">Super Admin Dashboard</h1>
          <p className="text-gray-500 text-sm mt-1">Platform-wide visibility and management</p>
        </div>
        {actionMsg && (
          <span className="px-4 py-2 bg-green-100 text-green-700 rounded-lg font-medium text-sm">✓ {actionMsg}</span>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-8 border-b border-gray-200">
        {(['overview', 'tenants', 'health', 'revenue', 'audit'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 font-medium border-b-2 transition-colors capitalize ${
              activeTab === tab ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Overview */}
      {activeTab === 'overview' && (
        <div>
          <div className="grid grid-cols-4 gap-4 mb-8">
            {[
              { label: 'Active Tenants', value: activeTenants, sub: `${totalTenants} total`, icon: '🏢' },
              { label: 'Total Users', value: totalUsers.toLocaleString(), sub: `${totalMAU} MAU`, icon: '👥' },
              { label: 'Total Predictions', value: totalPredictions.toLocaleString(), sub: 'all time', icon: '🤖' },
              { label: 'MRR', value: `$${(currentMRR / 1000).toFixed(0)}K`, sub: `ARR $${(ARR / 1000).toFixed(0)}K`, icon: '💰' },
            ].map((m) => (
              <div key={m.label} className="bg-white p-6 rounded-lg shadow">
                <div className="text-3xl mb-2">{m.icon}</div>
                <p className="text-sm text-gray-500">{m.label}</p>
                <p className="text-2xl font-bold text-gray-900">{m.value}</p>
                <p className="text-xs text-gray-400 mt-1">{m.sub}</p>
              </div>
            ))}
          </div>

          {/* Tier breakdown */}
          <div className="bg-white p-6 rounded-lg shadow mb-6">
            <h3 className="font-bold mb-4">Tenants by Tier</h3>
            <div className="grid grid-cols-3 gap-4">
              {['starter', 'growth', 'enterprise'].map((tier) => {
                const count = tenants.filter((t) => t.tier === tier).length
                const colors: Record<string, string> = { starter: 'bg-gray-100 text-gray-700', growth: 'bg-blue-100 text-blue-700', enterprise: 'bg-purple-100 text-purple-700' }
                return (
                  <div key={tier} className={`p-4 rounded-lg ${colors[tier]}`}>
                    <p className="text-sm font-medium capitalize">{tier}</p>
                    <p className="text-3xl font-bold">{count}</p>
                    <p className="text-xs opacity-70">tenants</p>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )}

      {/* Tenants */}
      {activeTab === 'tenants' && (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Tenant</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Tier</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Users</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Deals</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">MAU</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Status</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {tenants.map((t) => (
                <tr key={t.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 font-medium text-gray-900">{t.name}</td>
                  <td className="px-6 py-4">
                    <select
                      value={t.tier}
                      onChange={(e) => handleTierChange(t.id, e.target.value)}
                      className="text-xs border border-gray-300 rounded px-2 py-1 focus:ring-1 focus:ring-blue-500 outline-none"
                    >
                      <option value="starter">Starter</option>
                      <option value="growth">Growth</option>
                      <option value="enterprise">Enterprise</option>
                    </select>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">{t.users}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{t.deals}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{t.mau}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      t.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {t.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm">
                    {t.status === 'active' ? (
                      <button onClick={() => setSelectedTenant(t)} className="text-red-600 hover:text-red-800 font-medium">Suspend</button>
                    ) : (
                      <button onClick={() => handleReactivate(t.id)} className="text-green-600 hover:text-green-800 font-medium">Reactivate</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Health */}
      {activeTab === 'health' && (
        <div className="space-y-4">
          {isHealthAlert && (
            <div className="p-4 bg-red-50 border border-red-300 rounded-lg text-red-700 font-medium">
              ⚠️ One or more metrics exceed thresholds — immediate attention required
            </div>
          )}
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: 'API p95 Latency', value: `${HEALTH_METRICS.apiP95}ms`, threshold: '< 1000ms', ok: HEALTH_METRICS.apiP95 < 1000 },
              { label: '5xx Error Rate', value: `${HEALTH_METRICS.errorRate5xx}%`, threshold: '< 1%', ok: HEALTH_METRICS.errorRate5xx < 1 },
              { label: 'SageMaker Error Rate', value: `${HEALTH_METRICS.sagemakerErrorRate}%`, threshold: '< 0.5%', ok: HEALTH_METRICS.sagemakerErrorRate < 0.5 },
              { label: 'Platform Uptime', value: `${HEALTH_METRICS.uptime}%`, threshold: '≥ 99.9%', ok: HEALTH_METRICS.uptime >= 99.9 },
            ].map((m) => (
              <div key={m.label} className={`bg-white p-6 rounded-lg shadow border-l-4 ${m.ok ? 'border-green-400' : 'border-red-400'}`}>
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-gray-500">{m.label}</p>
                  <span className={`text-xs px-2 py-1 rounded-full font-medium ${m.ok ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                    {m.ok ? '✓ OK' : '⚠ Alert'}
                  </span>
                </div>
                <p className="text-3xl font-bold text-gray-900">{m.value}</p>
                <p className="text-xs text-gray-400 mt-1">Threshold: {m.threshold}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Revenue */}
      {activeTab === 'revenue' && (
        <div className="space-y-6">
          <div className="grid grid-cols-3 gap-4">
            {[
              { label: 'MRR', value: `$${(currentMRR / 1000).toFixed(0)}K` },
              { label: 'ARR', value: `$${(ARR / 1000).toFixed(0)}K` },
              { label: 'Churn Rate', value: '2.1%' },
            ].map((m) => (
              <div key={m.label} className="bg-white p-6 rounded-lg shadow text-center">
                <p className="text-sm text-gray-500 mb-1">{m.label}</p>
                <p className="text-3xl font-bold text-gray-900">{m.value}</p>
              </div>
            ))}
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="font-bold mb-4">MRR — Trailing 12 Months</h3>
            <div className="flex items-end gap-2 h-40">
              {MRR_DATA.map((m) => (
                <div key={m.month} className="flex-1 flex flex-col items-center gap-1">
                  <div
                    className="w-full bg-blue-500 rounded-t hover:bg-blue-600 transition-colors"
                    style={{ height: `${(m.mrr / maxMRR) * 120}px` }}
                    title={`$${(m.mrr / 1000).toFixed(0)}K`}
                  />
                  <span className="text-xs text-gray-500">{m.month}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="font-bold mb-4">Monthly Predictions — Trailing 12 Months</h3>
            <div className="flex items-end gap-2 h-40">
              {MONTHLY_PREDICTIONS.map((m) => (
                <div key={m.month} className="flex-1 flex flex-col items-center gap-1">
                  <div
                    className="w-full bg-purple-400 rounded-t hover:bg-purple-500 transition-colors"
                    style={{ height: `${(m.count / maxPredictions) * 120}px` }}
                    title={m.count.toLocaleString()}
                  />
                  <span className="text-xs text-gray-500">{m.month}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Audit */}
      {activeTab === 'audit' && (
        <div>
          <div className="mb-4">
            <input
              type="text"
              value={auditSearch}
              onChange={(e) => setAuditSearch(e.target.value)}
              placeholder="Search by tenant or action..."
              className="w-full max-w-md px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Timestamp</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Admin</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Action</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Tenant</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {auditLogs.map((log, i) => (
                  <tr key={i} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm text-gray-500">{log.ts}</td>
                    <td className="px-6 py-4 text-sm text-gray-700">{log.admin}</td>
                    <td className="px-6 py-4 text-sm text-gray-700">{log.action}</td>
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">{log.tenant}</td>
                    <td className="px-6 py-4 text-sm">
                      <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">{log.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Suspend Confirm Modal */}
      {selectedTenant && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-sm w-full shadow-2xl">
            <h3 className="text-lg font-bold mb-2">Suspend Tenant</h3>
            <p className="text-gray-600 mb-6">
              Are you sure you want to suspend <strong>{selectedTenant.name}</strong>? They will lose write access immediately.
            </p>
            <div className="flex gap-2">
              <button onClick={() => handleSuspend(selectedTenant.id)} className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium">
                Suspend
              </button>
              <button onClick={() => setSelectedTenant(null)} className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
