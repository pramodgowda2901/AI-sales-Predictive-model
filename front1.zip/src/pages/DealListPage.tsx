import React, { useState, useMemo } from 'react'
import { useQuery, useMutation, useQueryClient } from 'react-query'
import { Link } from 'react-router-dom'
import { apiClient } from '../services/api'
import { Deal } from '../services/mockData'
import BackButton from '../components/BackButton'

const STAGES = ['Prospecting', 'Qualification', 'Proposal', 'Negotiation', 'Closed Won']

export default function DealListPage() {
  const queryClient = useQueryClient()

  // Create form
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [formData, setFormData] = useState({ name: '', value: '', stage: '', closeDate: '', accountName: '', contact: '' })
  const [formError, setFormError] = useState('')

  // Filters
  const [search, setSearch] = useState('')
  const [filterStage, setFilterStage] = useState('')
  const [filterMinValue, setFilterMinValue] = useState('')
  const [filterMaxValue, setFilterMaxValue] = useState('')
  const [filterMinProb, setFilterMinProb] = useState('')
  const [sortBy, setSortBy] = useState<'name' | 'value' | 'winProbability' | 'closeDate'>('winProbability')
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc')
  const [showFilters, setShowFilters] = useState(false)

  // Bulk operations
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [bulkStage, setBulkStage] = useState('')
  const [bulkMsg, setBulkMsg] = useState('')

  const { data: deals = [], isLoading } = useQuery('deals', () => apiClient.getDeals())

  const createMutation = useMutation((newDeal: any) => apiClient.createDeal(newDeal), {
    onSuccess: () => {
      queryClient.invalidateQueries('deals')
      setFormData({ name: '', value: '', stage: '', closeDate: '', accountName: '', contact: '' })
      setShowCreateForm(false)
      setFormError('')
    },
    onError: (err: any) => setFormError(err.message || 'Failed to create deal'),
  })

  const deleteMutation = useMutation((id: string) => apiClient.deleteDeal(id), {
    onSuccess: () => queryClient.invalidateQueries('deals'),
  })

  const updateMutation = useMutation(({ id, data }: { id: string; data: any }) => apiClient.updateDeal(id, data), {
    onSuccess: () => queryClient.invalidateQueries('deals'),
  })

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.name || !formData.value || !formData.stage || !formData.closeDate) {
      setFormError('Name, value, stage and close date are required')
      return
    }
    createMutation.mutate({ ...formData, value: parseFloat(formData.value) })
  }

  // Filtered + sorted deals
  const filtered = useMemo(() => {
    let list = [...(deals as Deal[])]
    if (search) list = list.filter((d) => d.name.toLowerCase().includes(search.toLowerCase()) || d.accountName?.toLowerCase().includes(search.toLowerCase()))
    if (filterStage) list = list.filter((d) => d.stage === filterStage)
    if (filterMinValue) list = list.filter((d) => d.value >= parseFloat(filterMinValue))
    if (filterMaxValue) list = list.filter((d) => d.value <= parseFloat(filterMaxValue))
    if (filterMinProb) list = list.filter((d) => d.winProbability >= parseFloat(filterMinProb))
    list.sort((a, b) => {
      const av = a[sortBy] as any
      const bv = b[sortBy] as any
      if (typeof av === 'string') return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av)
      return sortDir === 'asc' ? av - bv : bv - av
    })
    return list
  }, [deals, search, filterStage, filterMinValue, filterMaxValue, filterMinProb, sortBy, sortDir])

  const toggleSort = (col: typeof sortBy) => {
    if (sortBy === col) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'))
    else { setSortBy(col); setSortDir('desc') }
  }

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  const toggleSelectAll = () => {
    if (selected.size === filtered.length) setSelected(new Set())
    else setSelected(new Set(filtered.map((d) => d.id)))
  }

  const handleBulkStageChange = async () => {
    if (!bulkStage || selected.size === 0) return
    await Promise.all([...selected].map((id) => updateMutation.mutateAsync({ id, data: { stage: bulkStage } })))
    setBulkMsg(`Updated ${selected.size} deals to "${bulkStage}"`)
    setSelected(new Set())
    setBulkStage('')
    setTimeout(() => setBulkMsg(''), 3000)
  }

  const handleBulkDelete = async () => {
    if (selected.size === 0) return
    if (!confirm(`Delete ${selected.size} selected deals?`)) return
    await Promise.all([...selected].map((id) => deleteMutation.mutateAsync(id)))
    setBulkMsg(`Deleted ${selected.size} deals`)
    setSelected(new Set())
    setTimeout(() => setBulkMsg(''), 3000)
  }

  const handleBulkExport = () => {
    const rows = filtered.filter((d) => selected.has(d.id))
    const headers = ['Name', 'Account', 'Value', 'Stage', 'Win %', 'Close Date']
    const csv = [headers.join(','), ...rows.map((d) => [d.name, d.accountName, d.value, d.stage, d.winProbability, new Date(d.closeDate).toLocaleDateString()].join(','))].join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `deals-export-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)
    setBulkMsg(`Exported ${rows.length} deals`)
    setTimeout(() => setBulkMsg(''), 3000)
  }

  const probColor = (p: number) =>
    p >= 75 ? 'bg-green-100 text-green-800' : p >= 50 ? 'bg-blue-100 text-blue-800' : p >= 25 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'

  const SortIcon = ({ col }: { col: typeof sortBy }) =>
    sortBy === col ? <span className="ml-1 text-blue-600">{sortDir === 'asc' ? '↑' : '↓'}</span> : <span className="ml-1 text-gray-300">↕</span>

  if (isLoading) return <div className="text-center py-8">Loading deals...</div>

  return (
    <div>
      <BackButton />

      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <h1 className="text-3xl font-bold dark:text-slate-100">Deals</h1>
        <div className="flex gap-2">
          <button onClick={() => setShowFilters(!showFilters)} className={`px-3 py-2 text-sm border rounded-lg font-medium transition-colors ${showFilters ? 'bg-blue-600 text-white border-blue-600' : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'}`}>
            🔽 Filters {(filterStage || filterMinValue || filterMaxValue || filterMinProb) ? '●' : ''}
          </button>
          <button onClick={() => setShowCreateForm(!showCreateForm)} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium text-sm">
            + New Deal
          </button>
        </div>
      </div>

      {/* Search + Filters */}
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-4 mb-4">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by deal name or account..."
          className="w-full px-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100"
        />
        {showFilters && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3 pt-3 border-t border-gray-100 dark:border-slate-700">
            <div>
              <label className="block text-xs font-medium text-gray-600 dark:text-slate-400 mb-1">Stage</label>
              <select value={filterStage} onChange={(e) => setFilterStage(e.target.value)} className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100">
                <option value="">All stages</option>
                {STAGES.map((s) => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 dark:text-slate-400 mb-1">Min Value ($)</label>
              <input type="number" value={filterMinValue} onChange={(e) => setFilterMinValue(e.target.value)} placeholder="0" className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 dark:text-slate-400 mb-1">Max Value ($)</label>
              <input type="number" value={filterMaxValue} onChange={(e) => setFilterMaxValue(e.target.value)} placeholder="∞" className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 dark:text-slate-400 mb-1">Min Win % </label>
              <input type="number" value={filterMinProb} onChange={(e) => setFilterMinProb(e.target.value)} placeholder="0" min="0" max="100" className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            </div>
            <button onClick={() => { setFilterStage(''); setFilterMinValue(''); setFilterMaxValue(''); setFilterMinProb('') }} className="text-xs text-red-600 hover:text-red-700 font-medium text-left">
              Clear filters
            </button>
          </div>
        )}
      </div>

      {/* Bulk Actions Bar */}
      {selected.size > 0 && (
        <div className="flex flex-wrap items-center gap-3 mb-4 p-3 bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-700 rounded-xl">
          <span className="text-sm font-semibold text-blue-800 dark:text-blue-300">{selected.size} selected</span>
          <select value={bulkStage} onChange={(e) => setBulkStage(e.target.value)} className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100">
            <option value="">Move to stage…</option>
            {STAGES.map((s) => <option key={s}>{s}</option>)}
          </select>
          <button onClick={handleBulkStageChange} disabled={!bulkStage} className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 disabled:bg-gray-400">
            Apply
          </button>
          <button onClick={handleBulkExport} className="px-3 py-1.5 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700">
            📥 Export CSV
          </button>
          <button onClick={handleBulkDelete} className="px-3 py-1.5 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700">
            🗑 Delete
          </button>
          <button onClick={() => setSelected(new Set())} className="text-sm text-gray-500 hover:text-gray-700 ml-auto">
            Clear selection
          </button>
        </div>
      )}

      {bulkMsg && (
        <div className="mb-4 p-3 bg-green-50 border border-green-200 text-green-700 rounded-lg text-sm font-medium">✓ {bulkMsg}</div>
      )}

      {/* Create Form */}
      {showCreateForm && (
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow mb-6">
          <h2 className="text-lg font-bold mb-4 dark:text-slate-100">Create New Deal</h2>
          {formError && <div className="mb-4 p-3 bg-red-100 text-red-800 rounded-lg text-sm">{formError}</div>}
          <form onSubmit={handleCreate} className="grid grid-cols-2 gap-4">
            <input type="text" placeholder="Deal Name *" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="px-4 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            <input type="text" placeholder="Account Name" value={formData.accountName} onChange={(e) => setFormData({ ...formData, accountName: e.target.value })} className="px-4 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            <input type="number" placeholder="Deal Value *" value={formData.value} onChange={(e) => setFormData({ ...formData, value: e.target.value })} className="px-4 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            <input type="text" placeholder="Contact Name" value={formData.contact} onChange={(e) => setFormData({ ...formData, contact: e.target.value })} className="px-4 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            <select value={formData.stage} onChange={(e) => setFormData({ ...formData, stage: e.target.value })} className="px-4 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100">
              <option value="">Select Stage *</option>
              {STAGES.map((s) => <option key={s}>{s}</option>)}
            </select>
            <input type="date" value={formData.closeDate} onChange={(e) => setFormData({ ...formData, closeDate: e.target.value })} className="px-4 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            <div className="col-span-2 flex gap-2">
              <button type="submit" disabled={createMutation.isLoading} className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-400 font-medium text-sm">
                {createMutation.isLoading ? 'Creating…' : 'Create Deal'}
              </button>
              <button type="button" onClick={() => setShowCreateForm(false)} className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium text-sm">
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Results count */}
      <div className="flex items-center justify-between mb-2 text-sm text-gray-500 dark:text-slate-400">
        <span>{filtered.length} deal{filtered.length !== 1 ? 's' : ''} {search || filterStage ? '(filtered)' : ''}</span>
        <span>Total value: <strong className="text-gray-900 dark:text-slate-100">${(filtered.reduce((s, d) => s + d.value, 0) / 1000000).toFixed(1)}M</strong></span>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 dark:bg-slate-900 border-b border-gray-200 dark:border-slate-700">
            <tr>
              <th className="px-4 py-3 text-left">
                <input type="checkbox" checked={selected.size === filtered.length && filtered.length > 0} onChange={toggleSelectAll} className="w-4 h-4 rounded" />
              </th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 dark:text-slate-100 cursor-pointer" onClick={() => toggleSort('name')}>
                Name <SortIcon col="name" />
              </th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 dark:text-slate-100">Account</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 dark:text-slate-100 cursor-pointer" onClick={() => toggleSort('value')}>
                Value <SortIcon col="value" />
              </th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 dark:text-slate-100">Stage</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 dark:text-slate-100 cursor-pointer" onClick={() => toggleSort('winProbability')}>
                Win % <SortIcon col="winProbability" />
              </th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 dark:text-slate-100 cursor-pointer" onClick={() => toggleSort('closeDate')}>
                Close Date <SortIcon col="closeDate" />
              </th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 dark:text-slate-100">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-slate-700">
            {filtered.map((deal: Deal) => (
              <tr key={deal.id} className={`hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors ${selected.has(deal.id) ? 'bg-blue-50 dark:bg-blue-900/20' : ''}`}>
                <td className="px-4 py-3">
                  <input type="checkbox" checked={selected.has(deal.id)} onChange={() => toggleSelect(deal.id)} className="w-4 h-4 rounded" />
                </td>
                <td className="px-4 py-3">
                  <Link to={`/deals/${deal.id}`} className="text-blue-600 hover:text-blue-800 font-medium text-sm">{deal.name}</Link>
                </td>
                <td className="px-4 py-3 text-sm text-gray-600 dark:text-slate-400">{deal.accountName}</td>
                <td className="px-4 py-3 text-sm font-semibold text-gray-900 dark:text-slate-100">${deal.value.toLocaleString()}</td>
                <td className="px-4 py-3 text-sm text-gray-600 dark:text-slate-400">{deal.stage}</td>
                <td className="px-4 py-3">
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${probColor(deal.winProbability)}`}>{deal.winProbability}%</span>
                </td>
                <td className="px-4 py-3 text-sm text-gray-600 dark:text-slate-400">{new Date(deal.closeDate).toLocaleDateString()}</td>
                <td className="px-4 py-3 text-sm">
                  <Link to={`/deals/${deal.id}`} className="text-blue-600 hover:text-blue-800 mr-3 font-medium">View</Link>
                  <button onClick={() => deleteMutation.mutate(deal.id)} className="text-red-600 hover:text-red-800 font-medium">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div className="text-center py-12 text-gray-500 dark:text-slate-400">
            {search || filterStage ? 'No deals match your filters.' : 'No deals yet. Create one to get started.'}
          </div>
        )}
      </div>
    </div>
  )
}
