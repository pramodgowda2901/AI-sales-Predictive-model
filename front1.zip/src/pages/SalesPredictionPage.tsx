
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend, RadarChart, Radar, PolarGrid, PolarAngleAxis } from 'recharts'
import BackButton from '../components/BackButton'

// ── Digital Solution AI's own client deals (their pipeline) ──
const DS_CLIENTS = [
  { id: 'c1', name: 'SKZ Travels & Tours',         service: 'Website + SEO',          value: 1200, stage: 'Closed Won',   prob: 100, signals: 12, days: 45, contact: 'Co-founder',          email: 'info@skztravel.com' },
  { id: 'c2', name: 'GoldTech Technical Services', service: 'SEO + Social Media',      value: 2400, stage: 'Closed Won',   prob: 100, signals: 9,  days: 60, contact: 'Mr. Tahir Bashir',    email: 'ceo@goldtechservice.com' },
  { id: 'c3', name: 'Quickon.pk E-Commerce',       service: 'Full Digital Marketing',  value: 3600, stage: 'Closed Won',   prob: 100, signals: 15, days: 30, contact: 'Mr. Irfan Kharal',   email: 'ceo@quickon.pk' },
  { id: 'c4', name: 'Green Leaf E-commerce',       service: 'Website + SEO + Social',  value: 1800, stage: 'Closed Won',   prob: 100, signals: 8,  days: 55, contact: 'James R.',            email: 'founder@greenleaf.com' },
  { id: 'c5', name: 'Dubai Retail Group',          service: 'Social Media Marketing',  value: 4800, stage: 'Negotiation', prob: 78,  signals: 7,  days: 22, contact: 'Ahmed Al-Rashid',     email: 'ahmed@dubairetail.ae' },
  { id: 'c6', name: 'Bangalore Tech Startup',      service: 'Website Design',          value: 900,  stage: 'Proposal',    prob: 62,  signals: 5,  days: 14, contact: 'Priya Sharma',        email: 'priya@blrtech.in' },
  { id: 'c7', name: 'Pakistan Fashion Brand',      service: 'E-Commerce + SEO',        value: 2100, stage: 'Proposal',    prob: 55,  signals: 6,  days: 18, contact: 'Fatima Khan',         email: 'fatima@pkfashion.pk' },
  { id: 'c8', name: 'Mumbai Restaurant Chain',     service: 'Social Media + Ads',      value: 1500, stage: 'Qualification',prob: 40, signals: 3,  days: 8,  contact: 'Rahul Mehta',         email: 'rahul@mumbaifoods.in' },
  { id: 'c9', name: 'Hyderabad IT Services',       service: 'Website + Digital Mktg',  value: 3000, stage: 'Qualification',prob: 35, signals: 2,  days: 5,  contact: 'Suresh Reddy',        email: 'suresh@hydits.in' },
  { id: 'c10',name: 'Chennai Logistics Co',        service: 'SEO + Content Marketing', value: 1200, stage: 'Prospecting', prob: 22,  signals: 1,  days: 3,  contact: 'Kavitha Nair',        email: 'kavitha@chenlogistics.in' },
]

const STAGES = ['Prospecting', 'Qualification', 'Proposal', 'Negotiation', 'Closed Won']

// Monthly revenue trend for DS AI
const REVENUE_TREND = [
  { month: 'Nov', actual: 4200, predicted: 4000 },
  { month: 'Dec', actual: 5100, predicted: 4800 },
  { month: 'Jan', actual: 4800, predicted: 5200 },
  { month: 'Feb', actual: 6300, predicted: 5900 },
  { month: 'Mar', actual: 7200, predicted: 6800 },
  { month: 'Apr', actual: 8100, predicted: 7600 },
  { month: 'May', actual: null, predicted: 9200 },
  { month: 'Jun', actual: null, predicted: 10500 },
]

// Signal factors for AI scoring
const SIGNAL_FACTORS = [
  { factor: 'Engagement Score',    value: 82 },
  { factor: 'Service Fit',         value: 91 },
  { factor: 'Budget Alignment',    value: 74 },
  { factor: 'Decision Speed',      value: 68 },
  { factor: 'Referral Source',     value: 85 },
]

const probColor = (p: number) =>
  p >= 75 ? 'text-green-700 bg-green-100 dark:text-green-300 dark:bg-green-900/30' :
  p >= 50 ? 'text-blue-700 bg-blue-100 dark:text-blue-300 dark:bg-blue-900/30' :
  p >= 25 ? 'text-yellow-700 bg-yellow-100 dark:text-yellow-300 dark:bg-yellow-900/30' :
            'text-red-700 bg-red-100 dark:text-red-300 dark:bg-red-900/30'

const barColor = (p: number) =>
  p >= 75 ? '#22c55e' : p >= 50 ? '#3b82f6' : p >= 25 ? '#f59e0b' : '#ef4444'

export default function SalesPredictionPage() {
  const navigate = useNavigate()
  const [selected, setSelected] = useState(DS_CLIENTS[4]) // Dubai Retail Group (active deal)
  const [tab, setTab] = useState<'pipeline' | 'prediction' | 'forecast' | 'howto'>('howto')
  const [simProb, setSimProb] = useState(selected.prob)
  const [simSignals, setSimSignals] = useState(selected.signals)
  const [simDays, setSimDays] = useState(selected.days)
  const [ingesting, setIngesting] = useState(false)
  const [ingestLog, setIngestLog] = useState<string[]>([])

  // Recalculate probability when sliders change
  useEffect(() => {
    const base = 20
    const signalBoost = Math.min(simSignals * 5, 40)
    const dayPenalty = simDays > 30 ? -10 : simDays > 60 ? -20 : 0
    const calc = Math.min(95, Math.max(5, base + signalBoost + dayPenalty + (selected.prob - 50) * 0.3))
    setSimProb(Math.round(calc))
  }, [simSignals, simDays, selected])

  // Simulate data ingestion
  const runIngestion = () => {
    setIngesting(true)
    setIngestLog([])
    const steps = [
      '🔗 Connecting to CRM (Salesforce)…',
      '✅ CRM connected — pulling deals',
      '📧 Scanning email signals for ' + selected.name,
      '✅ Found 3 new email opens in last 24h',
      '📅 Checking calendar for scheduled meetings…',
      '✅ 1 demo call scheduled for next week',
      '🌐 Analysing web engagement signals…',
      '✅ Pricing page visited 2 times today',
      '🤖 Running AI prediction model…',
      '✅ Win probability updated: ' + simProb + '%',
      '💡 Generating insights and recommendations…',
      '✅ 2 new insights created',
      '📊 Pipeline and forecast updated',
      '✅ Data ingestion complete — all signals processed',
    ]
    let i = 0
    const interval = setInterval(() => {
      if (i < steps.length) {
        setIngestLog((prev) => [...prev, steps[i]])
        i++
      } else {
        clearInterval(interval)
        setIngesting(false)
      }
    }, 400)
  }

  const totalPipeline = DS_CLIENTS.reduce((s, c) => s + c.value, 0)
  const weightedPipeline = DS_CLIENTS.reduce((s, c) => s + c.value * (c.prob / 100), 0)
  const activeDeals = DS_CLIENTS.filter((c) => c.stage !== 'Closed Won').length
  const closedValue = DS_CLIENTS.filter((c) => c.stage === 'Closed Won').reduce((s, c) => s + c.value, 0)

  const tooltipStyle = { backgroundColor: '#1e293b', border: 'none', borderRadius: 8, color: '#f1f5f9' }

  return (
    <div>
      <BackButton />

      {/* Header */}
      <div className="bg-gradient-to-r from-blue-700 to-purple-700 rounded-2xl p-6 mb-6 text-white">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-blue-700 font-bold text-lg shadow">DS</div>
              <div>
                <h1 className="text-xl font-extrabold">Digital Solution AI Pvt. Ltd.</h1>
                <p className="text-blue-200 text-sm">Bengaluru, India · Digital Marketing Agency</p>
              </div>
            </div>
            <p className="text-blue-100 text-sm max-w-2xl">
              This is how <strong>Digital Solution AI</strong> uses SalesPred AI to manage their own client pipeline — predicting which clients will convert, forecasting monthly revenue, and knowing exactly what to do next.
            </p>
          </div>
          <button onClick={runIngestion} disabled={ingesting}
            className="px-4 py-2 bg-white text-blue-700 rounded-xl font-bold text-sm hover:bg-blue-50 disabled:opacity-60 shadow flex-shrink-0">
            {ingesting ? '⏳ Ingesting…' : '📡 Run Data Ingestion'}
          </button>
        </div>

        {/* Ingestion log */}
        {ingestLog.length > 0 && (
          <div className="mt-4 bg-black/30 rounded-xl p-3 max-h-32 overflow-y-auto">
            {ingestLog.map((line, i) => (
              <p key={i} className="text-xs text-green-300 font-mono">{line}</p>
            ))}
          </div>
        )}
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total Pipeline', value: `₹${(totalPipeline / 1000).toFixed(0)}K`, sub: `${DS_CLIENTS.length} clients`, icon: '📊' },
          { label: 'Weighted Pipeline', value: `₹${(weightedPipeline / 1000).toFixed(0)}K`, sub: 'AI-adjusted', icon: '⚖️' },
          { label: 'Active Deals', value: activeDeals, sub: 'in progress', icon: '💼' },
          { label: 'Closed Revenue', value: `₹${(closedValue / 1000).toFixed(0)}K`, sub: 'this period', icon: '✅' },
        ].map((m) => (
          <div key={m.label} className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow border border-gray-100 dark:border-slate-700">
            <div className="text-2xl mb-1">{m.icon}</div>
            <p className="text-xs text-gray-500 dark:text-slate-400">{m.label}</p>
            <p className="text-2xl font-extrabold text-gray-900 dark:text-slate-100">{m.value}</p>
            <p className="text-xs text-gray-400 dark:text-slate-500 mt-0.5">{m.sub}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 border-b border-gray-200 dark:border-slate-700">
        {([
          { id: 'howto', label: '📖 How It Works' },
          { id: 'pipeline', label: '📊 Client Pipeline' },
          { id: 'prediction', label: '🤖 AI Prediction Simulator' },
          { id: 'forecast', label: '📈 Revenue Forecast' },
        ] as const).map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`px-4 py-2 font-medium border-b-2 transition-colors text-sm ${
              tab === t.id ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-600 hover:text-gray-900 dark:text-slate-400'
            }`}>
            {t.label}
          </button>
        ))}
      </div>

      {/* HOW IT WORKS TAB */}
      {tab === 'howto' && (
        <div className="space-y-6">
          <div className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-2xl p-8 border border-blue-100 dark:border-blue-800">
            <h2 className="text-2xl font-extrabold text-gray-900 dark:text-slate-100 mb-2">
              How Digital Solution AI Uses SalesPred AI
            </h2>
            <p className="text-gray-600 dark:text-slate-400 text-base leading-relaxed">
              Digital Solution AI is a digital marketing agency in Bengaluru. They have clients across India, Dubai, and Pakistan.
              Before SalesPred AI, they had no way to know which leads would convert, when to follow up, or how much revenue to expect next month.
              Now they do — automatically.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-6">
            {[
              {
                step: '01', icon: '🔗', title: 'Connect Their CRM',
                problem: 'DS AI was tracking clients in spreadsheets and WhatsApp. No visibility into deal stages.',
                solution: 'They connected their Salesforce CRM to SalesPred AI in 5 minutes. All 10 client deals synced automatically.',
                result: 'Every client deal now has a stage, value, and contact — all in one place.',
              },
              {
                step: '02', icon: '📡', title: 'Automatic Signal Ingestion',
                problem: 'They had no idea when a client was "hot" — ready to sign — vs just browsing.',
                solution: 'SalesPred AI automatically ingests signals: email opens, website visits, WhatsApp replies, meeting bookings.',
                result: 'When Dubai Retail Group opened their proposal 3 times in one day, DS AI got an instant alert.',
              },
              {
                step: '03', icon: '🤖', title: 'AI Win Probability Score',
                problem: 'Sales team was spending equal time on all leads — wasting effort on low-probability clients.',
                solution: 'The AI scores every client deal 0–100% based on engagement, service fit, budget, and historical close rates.',
                result: 'DS AI now focuses on the top 3 deals (>60% probability) first. Win rate improved 40%.',
              },
              {
                step: '04', icon: '💡', title: 'Smart Insights & Next Actions',
                problem: 'Team didn\'t know what to do next with each client. Follow up? Send proposal? Wait?',
                solution: 'AI generates specific next-best-action recommendations for each deal, ranked by revenue impact.',
                result: '"Send case study to Dubai Retail Group" → they did → deal moved to Negotiation.',
              },
              {
                step: '05', icon: '📈', title: 'Revenue Forecasting',
                problem: 'DS AI couldn\'t predict monthly revenue. Couldn\'t plan hiring or marketing spend.',
                solution: 'SalesPred AI forecasts monthly revenue using weighted pipeline × historical close rates.',
                result: 'May forecast: ₹9,200. June forecast: ₹10,500. DS AI hired one more designer in advance.',
              },
              {
                step: '06', icon: '📊', title: 'Pipeline Kanban View',
                problem: 'No visual overview of where all clients were in the sales process.',
                solution: 'Drag-and-drop kanban board showing all 10 clients by stage with AI probability on each card.',
                result: 'Weekly team meeting now takes 10 minutes instead of 1 hour. Everyone sees the same picture.',
              },
            ].map((item) => (
              <div key={item.step} className="bg-white dark:bg-slate-800 rounded-xl shadow p-6 border border-gray-100 dark:border-slate-700">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">
                    {item.step}
                  </div>
                  <div>
                    <span className="text-xl mr-2">{item.icon}</span>
                    <span className="font-bold text-gray-900 dark:text-slate-100">{item.title}</span>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                    <p className="text-xs font-semibold text-red-700 dark:text-red-400 mb-1">❌ Before</p>
                    <p className="text-sm text-gray-700 dark:text-slate-300">{item.problem}</p>
                  </div>
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <p className="text-xs font-semibold text-blue-700 dark:text-blue-400 mb-1">⚙️ How SalesPred AI Helps</p>
                    <p className="text-sm text-gray-700 dark:text-slate-300">{item.solution}</p>
                  </div>
                  <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <p className="text-xs font-semibold text-green-700 dark:text-green-400 mb-1">✅ Result</p>
                    <p className="text-sm text-gray-700 dark:text-slate-300">{item.result}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white text-center">
            <h3 className="text-2xl font-extrabold mb-2">Ready to see it in action?</h3>
            <p className="text-blue-100 mb-6">Explore DS AI's live pipeline, run the AI prediction simulator, and see their revenue forecast.</p>
            <div className="flex gap-4 justify-center">
              <button onClick={() => setTab('pipeline')} className="px-6 py-3 bg-white text-blue-600 rounded-xl font-bold hover:bg-blue-50">
                View Client Pipeline →
              </button>
              <button onClick={() => setTab('prediction')} className="px-6 py-3 bg-white/20 border border-white/30 text-white rounded-xl font-semibold hover:bg-white/30">
                Try AI Simulator →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PIPELINE TAB */}
      {tab === 'pipeline' && (
        <div>
          {/* Kanban */}
          <div className="grid grid-cols-5 gap-3 mb-8">
            {STAGES.map((stage) => {
              const stageDeals = DS_CLIENTS.filter((c) => c.stage === stage)
              return (
                <div key={stage} className="bg-gray-100 dark:bg-slate-800 rounded-xl p-3 border border-gray-200 dark:border-slate-700">
                  <div className="mb-3">
                    <p className="font-bold text-sm text-gray-900 dark:text-slate-100">{stage}</p>
                    <p className="text-xs text-gray-500 dark:text-slate-400">{stageDeals.length} clients · ₹{(stageDeals.reduce((s, c) => s + c.value, 0) / 1000).toFixed(0)}K</p>
                  </div>
                  <div className="space-y-2">
                    {stageDeals.map((c) => (
                      <button key={c.id} onClick={() => { setSelected(c); setSimProb(c.prob); setSimSignals(c.signals); setSimDays(c.days) }}
                        className={`w-full text-left p-2.5 rounded-lg border-2 transition-all hover:shadow-md ${
                          selected.id === c.id ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30' :
                          c.prob >= 75 ? 'bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-700' :
                          c.prob >= 50 ? 'bg-blue-50 border-blue-200 dark:bg-blue-900/20 dark:border-blue-700' :
                          c.prob >= 25 ? 'bg-yellow-50 border-yellow-200 dark:bg-yellow-900/20 dark:border-yellow-700' :
                          'bg-red-50 border-red-200 dark:bg-red-900/20 dark:border-red-700'
                        }`}>
                        <p className="text-xs font-semibold text-gray-900 dark:text-slate-100 truncate">{c.name}</p>
                        <p className="text-xs text-gray-500 dark:text-slate-400 truncate">{c.service}</p>
                        <div className="flex items-center justify-between mt-1.5">
                          <span className="text-xs font-bold text-gray-700 dark:text-slate-300">₹{(c.value / 1000).toFixed(1)}K</span>
                          <span className={`text-xs font-bold px-1.5 py-0.5 rounded-full ${probColor(c.prob)}`}>{c.prob}%</span>
                        </div>
                        <div className="mt-1.5 h-1 bg-gray-200 dark:bg-slate-600 rounded-full overflow-hidden">
                          <div className="h-full rounded-full" style={{ width: `${c.prob}%`, backgroundColor: barColor(c.prob) }} />
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>

          {/* Selected deal detail */}
          <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6 border border-gray-100 dark:border-slate-700">
            <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-4">Selected: {selected.name}</h3>
            <div className="grid grid-cols-3 gap-6">
              <div className="space-y-3">
                {[
                  { label: 'Service', value: selected.service },
                  { label: 'Deal Value', value: `₹${selected.value.toLocaleString()}/yr` },
                  { label: 'Stage', value: selected.stage },
                  { label: 'Contact', value: selected.contact },
                  { label: 'Email', value: selected.email },
                ].map((f) => (
                  <div key={f.label} className="flex flex-col py-1.5 border-b border-gray-100 dark:border-slate-700 last:border-0">
                    <span className="text-xs text-gray-500 dark:text-slate-400">{f.label}</span>
                    <span className="text-sm font-medium text-gray-900 dark:text-slate-100">{f.value}</span>
                  </div>
                ))}
              </div>
              <div className="col-span-2">
                <p className="text-sm font-semibold text-gray-700 dark:text-slate-300 mb-3">AI Signal Factors</p>
                <div className="space-y-2">
                  {SIGNAL_FACTORS.map((f) => (
                    <div key={f.factor}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-gray-600 dark:text-slate-400">{f.factor}</span>
                        <span className="font-semibold text-gray-900 dark:text-slate-100">{f.value}%</span>
                      </div>
                      <div className="h-2 bg-gray-200 dark:bg-slate-600 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-500 rounded-full" style={{ width: `${f.value}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PREDICTION SIMULATOR TAB */}
      {tab === 'prediction' && (
        <div className="grid grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6 border border-gray-100 dark:border-slate-700">
              <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-4">Select Client Deal</h3>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {DS_CLIENTS.filter((c) => c.stage !== 'Closed Won').map((c) => (
                  <button key={c.id} onClick={() => { setSelected(c); setSimProb(c.prob); setSimSignals(c.signals); setSimDays(c.days) }}
                    className={`w-full flex items-center justify-between p-3 rounded-lg border transition-all text-left ${
                      selected.id === c.id ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30' : 'border-gray-200 dark:border-slate-700 hover:border-gray-300'
                    }`}>
                    <div>
                      <p className="text-sm font-semibold text-gray-900 dark:text-slate-100">{c.name}</p>
                      <p className="text-xs text-gray-500 dark:text-slate-400">{c.service} · ₹{c.value.toLocaleString()}</p>
                    </div>
                    <span className={`text-sm font-bold px-2 py-1 rounded-full ${probColor(c.prob)}`}>{c.prob}%</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6 border border-gray-100 dark:border-slate-700">
              <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-4">Adjust Signals (Simulate)</h3>
              <div className="space-y-5">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-600 dark:text-slate-400">📧 Engagement Signals</span>
                    <span className="font-bold text-gray-900 dark:text-slate-100">{simSignals} signals</span>
                  </div>
                  <input type="range" min={0} max={20} value={simSignals} onChange={(e) => setSimSignals(+e.target.value)}
                    className="w-full accent-blue-600" />
                  <div className="flex justify-between text-xs text-gray-400 mt-1"><span>0</span><span>20</span></div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-600 dark:text-slate-400">📅 Days in Current Stage</span>
                    <span className="font-bold text-gray-900 dark:text-slate-100">{simDays} days</span>
                  </div>
                  <input type="range" min={1} max={90} value={simDays} onChange={(e) => setSimDays(+e.target.value)}
                    className="w-full accent-blue-600" />
                  <div className="flex justify-between text-xs text-gray-400 mt-1"><span>1 day</span><span>90 days</span></div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className={`rounded-xl p-8 border-2 text-center ${probColor(simProb)} border-current`}>
              <p className="text-sm font-semibold mb-2 opacity-80">AI Win Probability</p>
              <p className="text-7xl font-extrabold">{simProb}%</p>
              <p className="text-sm mt-2 font-medium">
                {simProb >= 75 ? '🟢 High — Close this week' :
                 simProb >= 50 ? '🔵 Medium — Follow up now' :
                 simProb >= 25 ? '🟡 Low — Needs nurturing' :
                 '🔴 Very Low — Re-qualify'}
              </p>
              <div className="mt-4 h-3 bg-white/40 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-500" style={{ width: `${simProb}%`, backgroundColor: barColor(simProb) }} />
              </div>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6 border border-gray-100 dark:border-slate-700">
              <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-4">AI Recommended Actions</h3>
              <div className="space-y-3">
                {(() => {
                  const actions = simProb >= 70 ? [
                    { icon: '📞', action: `Call ${selected.contact} today — they are ready to decide` },
                    { icon: '📄', action: 'Send final contract with 10% early-sign discount' },
                    { icon: '✅', action: 'Schedule onboarding call for next week' },
                  ] : simProb >= 45 ? [
                    { icon: '📧', action: `Send case study relevant to ${selected.service}` },
                    { icon: '📞', action: 'Schedule a 15-min check-in call this week' },
                    { icon: '💡', action: 'Share ROI calculator showing expected results' },
                  ] : [
                    { icon: '🔄', action: 'Re-qualify: confirm budget and timeline' },
                    { icon: '📧', action: 'Send re-engagement email with new offer' },
                    { icon: '⏰', action: 'Set reminder to follow up in 7 days' },
                  ]
                  return actions.map((a, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 bg-gray-50 dark:bg-slate-700 rounded-lg">
                      <span className="text-lg flex-shrink-0">{a.icon}</span>
                      <p className="text-sm text-gray-700 dark:text-slate-300">{a.action}</p>
                    </div>
                  ))
                })()}
              </div>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6 border border-gray-100 dark:border-slate-700">
              <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-3">Expected Revenue</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <p className="text-xs text-gray-500 dark:text-slate-400">If Won</p>
                  <p className="text-xl font-bold text-blue-600 dark:text-blue-400">₹{selected.value.toLocaleString()}</p>
                </div>
                <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <p className="text-xs text-gray-500 dark:text-slate-400">Weighted Value</p>
                  <p className="text-xl font-bold text-green-600 dark:text-green-400">₹{Math.round(selected.value * simProb / 100).toLocaleString()}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* FORECAST TAB */}
      {tab === 'forecast' && (
        <div className="space-y-6">
          <div className="grid grid-cols-3 gap-4">
            {[
              { label: 'May Forecast', value: '₹9,200', sub: 'AI predicted', color: 'text-blue-600 dark:text-blue-400' },
              { label: 'June Forecast', value: '₹10,500', sub: '+14% growth', color: 'text-green-600 dark:text-green-400' },
              { label: 'Q3 Forecast', value: '₹32,000', sub: 'Jul–Sep total', color: 'text-purple-600 dark:text-purple-400' },
            ].map((m) => (
              <div key={m.label} className="bg-white dark:bg-slate-800 rounded-xl shadow p-6 border border-gray-100 dark:border-slate-700 text-center">
                <p className="text-sm text-gray-500 dark:text-slate-400">{m.label}</p>
                <p className={`text-3xl font-extrabold mt-1 ${m.color}`}>{m.value}</p>
                <p className="text-xs text-gray-400 dark:text-slate-500 mt-1">{m.sub}</p>
              </div>
            ))}
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6 border border-gray-100 dark:border-slate-700">
            <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-4">Revenue Trend — Actual vs AI Predicted</h3>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={REVENUE_TREND}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#9ca3af' }} />
                <YAxis tick={{ fontSize: 12, fill: '#9ca3af' }} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}K`} />
                <Tooltip formatter={(v: any) => `₹${v.toLocaleString()}`} contentStyle={tooltipStyle} />
                <Legend />
                <Line type="monotone" dataKey="actual" stroke="#3b82f6" strokeWidth={2} dot={{ r: 4 }} name="Actual Revenue" connectNulls={false} />
                <Line type="monotone" dataKey="predicted" stroke="#a855f7" strokeWidth={2} strokeDasharray="6 3" dot={{ r: 3 }} name="AI Forecast" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6 border border-gray-100 dark:border-slate-700">
            <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-4">Pipeline Value by Stage</h3>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={STAGES.map((s) => ({
                stage: s.split(' ')[0],
                value: DS_CLIENTS.filter((c) => c.stage === s).reduce((sum, c) => sum + c.value, 0),
                weighted: Math.round(DS_CLIENTS.filter((c) => c.stage === s).reduce((sum, c) => sum + c.value * c.prob / 100, 0)),
              }))}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="stage" tick={{ fontSize: 11, fill: '#9ca3af' }} />
                <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}K`} />
                <Tooltip formatter={(v: any) => `₹${v.toLocaleString()}`} contentStyle={tooltipStyle} />
                <Legend />
                <Bar dataKey="value" fill="#3b82f6" name="Total Value" radius={[4, 4, 0, 0]} />
                <Bar dataKey="weighted" fill="#a855f7" name="AI Weighted" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  )
}
