import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from 'react-query'
import { apiClient } from '../services/api'
import BackButton from '../components/BackButton'

interface APIKey {
  id: string
  name: string
  key: string
  maskedKey: string
  createdAt: string
  lastUsed?: string
  status: 'active' | 'revoked'
}

export default function APIKeysPage() {
  const queryClient = useQueryClient()
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [keyName, setKeyName] = useState('')
  const [showKey, setShowKey] = useState<string | null>(null)
  const [copiedKey, setCopiedKey] = useState<string | null>(null)

  const { data: apiKeys = [], isLoading } = useQuery('apiKeys', () => [
    {
      id: '1',
      name: 'Production API Key',
      key: 'sk_live_51234567890abcdefghijklmnop',
      maskedKey: 'sk_live_...mnop',
      createdAt: '2024-01-15',
      lastUsed: '2024-04-20',
      status: 'active',
    },
    {
      id: '2',
      name: 'Development API Key',
      key: 'sk_test_51234567890abcdefghijklmnop',
      maskedKey: 'sk_test_...mnop',
      createdAt: '2024-02-01',
      lastUsed: '2024-04-19',
      status: 'active',
    },
    {
      id: '3',
      name: 'Old Integration Key',
      key: 'sk_live_old1234567890abcdefghijk',
      maskedKey: 'sk_live_...hijk',
      createdAt: '2023-12-01',
      lastUsed: undefined,
      status: 'revoked',
    },
  ])

  const createKeyMutation = useMutation(
    (data: any) => apiClient.createAPIKey(data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('apiKeys')
        setShowCreateModal(false)
        setKeyName('')
      },
    }
  )

  const handleCreateKey = () => {
    if (!keyName) return
    createKeyMutation.mutate({ name: keyName })
  }

  const handleCopyKey = (key: string) => {
    navigator.clipboard.writeText(key)
    setCopiedKey(key)
    setTimeout(() => setCopiedKey(null), 2000)
  }

  return (
    <div>
      <BackButton />
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold">API Keys</h1>
          <p className="text-gray-600 mt-2">Manage API keys for programmatic access to the platform</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          + Create New Key
        </button>
      </div>

      {/* Documentation */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8">
        <h3 className="font-bold text-blue-900 mb-2">📚 API Documentation</h3>
        <p className="text-sm text-blue-800 mb-3">
          Use your API keys to authenticate requests to our REST API. Include your key in the Authorization header:
        </p>
        <code className="block bg-white p-3 rounded border border-blue-200 text-sm text-gray-800 overflow-x-auto">
          Authorization: Bearer YOUR_API_KEY
        </code>
        <a href="#" className="text-blue-600 hover:text-blue-700 text-sm mt-3 inline-block">
          View full API documentation →
        </a>
      </div>

      {/* API Keys Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Name</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Key</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Created</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Last Used</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Status</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {apiKeys.map((apiKey: any) => (
              <tr key={apiKey.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 text-sm font-medium text-gray-900">{apiKey.name}</td>
                <td className="px-6 py-4 text-sm">
                  <div className="flex items-center gap-2">
                    <code className="bg-gray-100 px-3 py-1 rounded text-xs font-mono text-gray-700">
                      {showKey === apiKey.id ? apiKey.key : apiKey.maskedKey}
                    </code>
                    {showKey === apiKey.id && (
                      <button
                        onClick={() => handleCopyKey(apiKey.key)}
                        className="text-blue-600 hover:text-blue-700 text-xs font-medium"
                      >
                        {copiedKey === apiKey.key ? '✓ Copied' : 'Copy'}
                      </button>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-gray-600">{apiKey.createdAt}</td>
                <td className="px-6 py-4 text-sm text-gray-600">{apiKey.lastUsed || 'Never'}</td>
                <td className="px-6 py-4 text-sm">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    apiKey.status === 'active'
                      ? 'bg-green-100 text-green-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {apiKey.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm">
                  {showKey === apiKey.id ? (
                    <button
                      onClick={() => setShowKey(null)}
                      className="text-gray-600 hover:text-gray-700 mr-3"
                    >
                      Hide
                    </button>
                  ) : (
                    <button
                      onClick={() => setShowKey(apiKey.id)}
                      className="text-blue-600 hover:text-blue-700 mr-3"
                    >
                      Show
                    </button>
                  )}
                  {apiKey.status === 'active' && (
                    <button className="text-red-600 hover:text-red-700">Revoke</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Create Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-sm w-full">
            <h3 className="text-lg font-bold mb-4">Create New API Key</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Key Name</label>
                <input
                  type="text"
                  value={keyName}
                  onChange={(e) => setKeyName(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., Production API Key"
                />
              </div>
              <div className="bg-yellow-50 border border-yellow-200 rounded p-3">
                <p className="text-xs text-yellow-800">
                  ⚠️ Save your API key in a secure location. You won't be able to see it again.
                </p>
              </div>
              <div className="flex gap-2 pt-4">
                <button
                  onClick={handleCreateKey}
                  disabled={createKeyMutation.isLoading || !keyName}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-gray-400"
                >
                  {createKeyMutation.isLoading ? 'Creating...' : 'Create Key'}
                </button>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded hover:bg-gray-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
