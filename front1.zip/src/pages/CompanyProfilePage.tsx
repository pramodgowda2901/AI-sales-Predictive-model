import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import BackButton from '../components/BackButton'
import { useCompanyStore } from '../store/companyStore'

export default function CompanyProfilePage() {
  const navigate = useNavigate()
  const { companyData: C, currentCompany, loading } = useCompanyStore()
  const [activeTab, setActiveTab] = useState<'overview' | 'deal' | 'insights' | 'contacts'>('overview')
  const [dealCreated, setDealCreated] = useState(false)

  const handleCreateDeal = () => {
    setDealCreated(true)
    setTimeout(() => navigate('/deals'), 2000)
  }

  const probColor = (p: number) =>
    p >= 75 ? 'text-green-600 bg-green-50 border-green-200 dark:bg-green-900/30 dark:border-green-700 dark:text-green-400' :
    p >= 50 ? 'text-blue-600 bg-blue-50 border-blue-200 dark:bg-blue-900/30 dark:border-blue-700 dark:text-blue-400' :
    p >= 25 ? 'text-yellow-600 bg-yellow-50 border-yellow-200 dark:bg-yellow-900/30 dark:border-yellow-700 dark:text-yellow-400' :
              'text-red-600 bg-red-50 border-red-200 dark:bg-red-900/30 dark:border-red-700 dark:text-red-400'

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-24">
        <div className="text-5xl mb-4 animate-spin">⏳</div>
        <p className="text-xl font-semibold text-gray-700 dark:text-slate-300">Fetching company data…</p>
        <p className="text-gray-500 dark:text-slate-400 mt-2">Loading profile for <strong>{currentCompany}</strong></p>
      </div>
    )
  }

  if (!C) {
    return (
      <div className="text-center py-24">
        <div className="text-5xl mb-4">🏢</div>
        <p className="text-xl font-semibold text-gray-700 dark:text-slate-300">No company selected</p>
        <p className="text-gray-500 dark:text-slate-400 mt-2">Use the 🏢 Company button in the header to search for a company</p>
      </div>
    )
  }

  const initials = C.name.split(' ').slice(0, 2).map((w: string) => w[0]).join('').toUpperCase()

  return (
    <div>
      <BackButton />

      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 mb-6 text-white">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-5 flex-1 min-w-0">
            <div className="w-16 h-16 bg-white rounded-xl flex items-center justify-center text-xl font-bold text-blue-600 shadow-lg flex-shrink-0">
              {initials}
            </div>
            <div className="min-w-0">
              <h1 className="text-2xl font-extrabold truncate">{C.name}</h1>
              <p className="text-blue-100 mt-0.5 italic text-sm">"{C.tagline}"</p>
              <p className="text-blue-200 mt-1 text-sm">{C.industry}</p>
              <div className="flex flex-wrap gap-2 mt-3 text-xs">
                <span className="bg-white/20 px-3 py-1 rounded-full">📍 {C.location}</span>
                <span className="bg-white/20 px-3 py-1 rounded-full">🏢 {C.type}</span>
                <span className="bg-white/20 px-3 py-1 rounded-full">👥 {C.employees}</span>
                <span className="bg-white/20 px-3 py-1 rounded-full">📅 Est. {C.founded}</span>
                {C.phone && <span className="bg-white/20 px-3 py-1 rounded-full">📞 {C.phone}</span>}
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-2 flex-shrink-0">
            <div className="flex gap-2">
              <a href={C.website} target="_blank" rel="noopener noreferrer"
                className="px-3 py-2 bg-white/20 border border-white/30 text-white rounded-lg hover:bg-white/30 text-sm font-medium">
                🌐 Website
              </a>
              {C.phone && (
                <a href={`tel:${C.phone}`}
                  className="px-3 py-2 bg-green-500/80 text-white rounded-lg hover:bg-green-500 text-sm font-medium">
                  📞 Call
                </a>
              )}
            </div>
            {!dealCreated ? (
              <button onClick={handleCreateDeal}
                className="px-4 py-2 bg-white text-blue-600 rounded-lg hover:bg-blue-50 text-sm font-bold shadow">
                + Add to Pipeline
              </button>
            ) : (
              <span className="px-4 py-2 bg-green-500 text-white rounded-lg text-sm font-bold text-center">
                ✓ Added to Pipeline!
              </span>
            )}
          </div>
        </div>
      </div>

      {/* AI Score Banner */}
      <div className={`flex items-center justify-between p-4 rounded-xl border mb-6 ${probColor(C.winProbability)}`}>
        <div className="flex items-center gap-3">
          <span className="text-2xl">🤖</span>
          <div>
            <p className="font-bold">AI Win Probability Score</p>
            <p className="text-sm opacity-80">Based on engagement signals, company profile, and industry benchmarks</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-4xl font-extrabold">{C.winProbability}%</p>
          <p className="text-sm font-medium">
            {C.winProbability >= 70 ? 'Likely to convert' : C.winProbability >= 50 ? 'Moderate chance' : 'Needs nurturing'}
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 border-b border-gray-200 dark:border-slate-700">
        {(['overview', 'deal', 'insights', 'contacts'] as const).map((tab) => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 font-medium border-b-2 transition-colors ${
              activeTab === tab ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-600 hover:text-gray-900 dark:text-slate-400'
            }`}>
            {tab === 'overview' ? '🏢 Overview' : tab === 'deal' ? '💼 Deal Info' : tab === 'insights' ? '💡 AI Insights' : '👤 Contacts'}
          </button>
        ))}
      </div>

      {/* Overview */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-3 gap-6">
          <div className="col-span-2 space-y-6">
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6">
              <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-3">About</h3>
              <p className="text-gray-600 dark:text-slate-400 leading-relaxed">{C.description}</p>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6">
              <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-4">Products & Services</h3>
              <div className="grid grid-cols-2 gap-3">
                {C.services.map((s: string) => (
                  <div key={s} className="flex items-center gap-2 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <span className="text-blue-500 flex-shrink-0">✓</span>
                    <span className="text-sm text-gray-700 dark:text-slate-300">{s}</span>
                  </div>
                ))}
              </div>
            </div>

            {C.clients.length > 0 && (
              <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6">
                <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-4">Client Testimonials</h3>
                <div className="space-y-4">
                  {C.clients.map((c: any) => (
                    <div key={c.name} className="p-4 bg-gray-50 dark:bg-slate-700 rounded-lg">
                      <p className="text-sm text-gray-700 dark:text-slate-300 italic mb-2">"{c.feedback}"</p>
                      <p className="text-xs font-semibold text-gray-900 dark:text-slate-100">{c.role}</p>
                      <p className="text-xs text-gray-500 dark:text-slate-400">{c.name}{c.website ? ` — ${c.website}` : ''}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6">
              <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-4">Company Details</h3>
              <div className="space-y-3">
                {[
                  { label: 'Industry', value: C.industry },
                  { label: 'Location', value: C.location },
                  { label: 'Type', value: C.type },
                  { label: 'Founded', value: C.founded },
                  { label: 'Team Size', value: C.employees },
                  { label: 'Website', value: C.website.replace('https://', '') },
                  { label: 'Phone', value: C.phone },
                  { label: 'Email', value: C.email },
                ].filter((i) => i.value).map((item) => (
                  <div key={item.label} className="flex flex-col py-2 border-b border-gray-100 dark:border-slate-700 last:border-0">
                    <span className="text-xs text-gray-500 dark:text-slate-400">{item.label}</span>
                    <span className="text-sm font-medium text-gray-900 dark:text-slate-100 mt-0.5 break-all">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6">
              <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-3">Revenue Potential</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500 dark:text-slate-400">Monthly</span>
                  <span className="font-bold text-gray-900 dark:text-slate-100">${C.dealValue}/mo</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500 dark:text-slate-400">Annual</span>
                  <span className="font-bold text-green-600">${(C.dealValue * 12).toLocaleString()}/yr</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500 dark:text-slate-400">Current Stage</span>
                  <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs font-bold">{C.dealStage}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Deal Info */}
      {activeTab === 'deal' && (
        <div className="grid grid-cols-2 gap-6">
          <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6">
            <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-4">Deal Details</h3>
            <div className="space-y-3">
              {[
                { label: 'Company', value: C.name },
                { label: 'Deal Value', value: `$${C.dealValue}/month` },
                { label: 'Stage', value: C.dealStage },
                { label: 'Win Probability', value: `${C.winProbability}%` },
                { label: 'Expected Close', value: C.closeDate },
                { label: 'Contact Email', value: C.email },
                { label: 'Contact Phone', value: C.phone },
              ].filter((i) => i.value).map((item) => (
                <div key={item.label} className="flex flex-col py-2 border-b border-gray-100 dark:border-slate-700 last:border-0">
                  <span className="text-xs text-gray-500 dark:text-slate-400">{item.label}</span>
                  <span className="text-sm font-medium text-gray-900 dark:text-slate-100 mt-0.5">{item.value}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6">
            <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-4">Recent Signals</h3>
            <div className="space-y-3">
              {C.signals.map((s: any, i: number) => (
                <div key={i} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-slate-700 rounded-lg">
                  <div>
                    <p className="text-sm font-semibold text-gray-900 dark:text-slate-100">{s.type}</p>
                    <p className="text-xs text-gray-500 dark:text-slate-400">{s.source}</p>
                  </div>
                  <span className="text-xs text-gray-400 dark:text-slate-500">{s.date}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="col-span-2 bg-white dark:bg-slate-800 rounded-xl shadow p-6">
            <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-4">Win Probability Factors</h3>
            <div className="grid grid-cols-4 gap-4">
              {[
                { factor: 'Engagement Score', score: Math.min(95, C.winProbability + 13) },
                { factor: 'Company Fit', score: Math.min(95, C.winProbability + 6) },
                { factor: 'Stage Velocity', score: Math.max(20, C.winProbability - 2) },
                { factor: 'Historical Close Rate', score: Math.max(20, C.winProbability - 7) },
              ].map((f) => (
                <div key={f.factor} className="p-4 bg-gray-50 dark:bg-slate-700 rounded-lg text-center">
                  <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">{f.score}%</p>
                  <p className="text-xs font-semibold text-gray-900 dark:text-slate-100 mt-1">{f.factor}</p>
                  <div className="mt-2 h-1.5 bg-gray-200 dark:bg-slate-600 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 rounded-full" style={{ width: `${f.score}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Insights */}
      {activeTab === 'insights' && (
        <div className="space-y-4">
          {C.insights.map((insight: any, i: number) => (
            <div key={i} className="bg-white dark:bg-slate-800 rounded-xl shadow p-6 border border-gray-100 dark:border-slate-700">
              <div className="flex flex-wrap items-center gap-2 mb-3">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  insight.type === 'High Win Probability' ? 'bg-green-100 text-green-800' :
                  insight.type === 'Next Best Action' ? 'bg-blue-100 text-blue-800' :
                  insight.type === 'Stalled Deal' ? 'bg-red-100 text-red-800' :
                  insight.type === 'Timeline Risk' ? 'bg-purple-100 text-purple-800' :
                  'bg-yellow-100 text-yellow-800'
                }`}>{insight.type}</span>
                <span className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm font-medium">
                  💰 ${insight.impact.toLocaleString()} impact
                </span>
              </div>
              <p className="text-gray-700 dark:text-slate-300 leading-relaxed">{insight.text}</p>
              <div className="mt-4 flex gap-2">
                <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm font-medium">✅ Act Upon</button>
                <button className="px-4 py-2 bg-gray-200 dark:bg-slate-700 text-gray-700 dark:text-slate-300 rounded-lg hover:bg-gray-300 text-sm font-medium">🔕 Dismiss</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Contacts */}
      {activeTab === 'contacts' && (
        <div className="grid grid-cols-2 gap-6">
          <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6">
            <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-4">Contact Information</h3>
            <div className="space-y-3">
              {[
                { icon: '🌐', label: 'Website', value: C.website.replace('https://', ''), href: C.website },
                { icon: '📧', label: 'Email', value: C.email, href: `mailto:${C.email}` },
                { icon: '📞', label: 'Phone', value: C.phone, href: `tel:${C.phone}` },
                { icon: '📍', label: 'Location', value: C.location },
                { icon: '🏢', label: 'Company Type', value: C.type },
                { icon: '📅', label: 'Founded', value: C.founded },
              ].filter((c) => c.value).map((c) => (
                <div key={c.label} className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-slate-700 rounded-lg">
                  <span className="text-xl">{c.icon}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-gray-500 dark:text-slate-400">{c.label}</p>
                    {c.href ? (
                      <a href={c.href} target="_blank" rel="noopener noreferrer"
                        className="text-sm font-medium text-blue-600 dark:text-blue-400 hover:underline truncate block">
                        {c.value}
                      </a>
                    ) : (
                      <p className="text-sm font-medium text-gray-900 dark:text-slate-100 truncate">{c.value}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6">
            <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-4">Quick Actions</h3>
            <div className="space-y-3">
              {[
                { icon: '📧', label: 'Send Email', desc: `Email ${C.email}`, href: `mailto:${C.email}` },
                { icon: '📞', label: 'Call Now', desc: C.phone, href: `tel:${C.phone}` },
                { icon: '🌐', label: 'Visit Website', desc: C.website.replace('https://', ''), href: C.website },
                { icon: '💼', label: 'Add to Pipeline', desc: 'Create a deal for this company', action: handleCreateDeal },
              ].filter((a) => a.href || a.action).map((action) => (
                action.href ? (
                  <a key={action.label} href={action.href} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-slate-700 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors">
                    <span className="text-xl">{action.icon}</span>
                    <div>
                      <p className="text-sm font-semibold text-gray-900 dark:text-slate-100">{action.label}</p>
                      <p className="text-xs text-gray-500 dark:text-slate-400 truncate">{action.desc}</p>
                    </div>
                  </a>
                ) : (
                  <button key={action.label} onClick={action.action}
                    className="w-full flex items-center gap-3 p-3 bg-gray-50 dark:bg-slate-700 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors text-left">
                    <span className="text-xl">{action.icon}</span>
                    <div>
                      <p className="text-sm font-semibold text-gray-900 dark:text-slate-100">{action.label}</p>
                      <p className="text-xs text-gray-500 dark:text-slate-400">{action.desc}</p>
                    </div>
                  </button>
                )
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
