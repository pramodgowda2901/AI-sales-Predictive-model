import React, { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from 'react-query'
import { Link } from 'react-router-dom'
import { apiClient } from '../services/api'
import { Deal } from '../services/mockData'
import BackButton from '../components/BackButton'
import LiveFeed from '../components/LiveFeed'

export default function PipelinePage() {
  const queryClient = useQueryClient()
  const [draggedDeal, setDraggedDeal] = useState<Deal | null>(null)

  const { data: pipelineData = [], isLoading } = useQuery('pipeline', () => apiClient.getPipeline())

  const updateMutation = useMutation((data: { dealId: string; newStage: string }) =>
    apiClient.updateDeal(data.dealId, { stage: data.newStage })
  )

  const handleDragStart = (deal: Deal) => setDraggedDeal(deal)
  const handleDragOver = (e: React.DragEvent) => e.preventDefault()

  const handleDrop = (stage: string) => {
    if (draggedDeal && draggedDeal.stage !== stage) {
      updateMutation.mutate(
        { dealId: draggedDeal.id, newStage: stage },
        {
          onSuccess: () => {
            queryClient.invalidateQueries('pipeline')
            setDraggedDeal(null)
          },
        }
      )
    }
    setDraggedDeal(null)
  }

  // Card background + border — light pastel in light mode, dark tinted in dark mode
  const getCardColor = (probability: number) => {
    if (probability >= 75)
      return 'bg-green-50 border-green-300 dark:bg-green-900/30 dark:border-green-600'
    if (probability >= 50)
      return 'bg-blue-50 border-blue-300 dark:bg-blue-900/30 dark:border-blue-600'
    if (probability >= 25)
      return 'bg-yellow-50 border-yellow-300 dark:bg-yellow-900/30 dark:border-yellow-600'
    return 'bg-red-50 border-red-300 dark:bg-red-900/30 dark:border-red-600'
  }

  // Badge — always readable in both modes
  const getBadgeColor = (probability: number) => {
    if (probability >= 75)
      return 'bg-green-200 text-green-900 dark:bg-green-700 dark:text-green-100'
    if (probability >= 50)
      return 'bg-blue-200 text-blue-900 dark:bg-blue-700 dark:text-blue-100'
    if (probability >= 25)
      return 'bg-yellow-200 text-yellow-900 dark:bg-yellow-700 dark:text-yellow-100'
    return 'bg-red-200 text-red-900 dark:bg-red-700 dark:text-red-100'
  }

  // Progress bar fill colour
  const getBarColor = (probability: number) => {
    if (probability >= 75) return 'bg-green-500'
    if (probability >= 50) return 'bg-blue-500'
    if (probability >= 25) return 'bg-yellow-500'
    return 'bg-red-500'
  }

  if (isLoading) {
    return (
      <div className="text-center py-8 text-gray-600 dark:text-slate-400">
        Loading pipeline...
      </div>
    )
  }

  return (
    <div>
      <BackButton />
      <h1 className="text-3xl font-bold mb-4 text-gray-900 dark:text-slate-100">
        Sales Pipeline
      </h1>
      <LiveFeed />

      <div className="grid grid-cols-5 gap-4">
        {pipelineData.map((column: any) => (
          <div
            key={column.stage}
            className="bg-gray-100 dark:bg-slate-800 rounded-xl p-4 min-h-96 border border-gray-200 dark:border-slate-700"
            onDragOver={handleDragOver}
            onDrop={() => handleDrop(column.stage)}
          >
            {/* Column header */}
            <div className="mb-4">
              <h2 className="font-bold text-base text-gray-900 dark:text-slate-100">
                {column.stage}
              </h2>
              <p className="text-xs text-gray-500 dark:text-slate-400 mt-0.5">
                {column.dealCount} deals &nbsp;·&nbsp; ${(column.totalValue / 1000).toFixed(0)}k
              </p>
            </div>

            {/* Deal cards */}
            <div className="space-y-2">
              {column.deals.map((deal: Deal) => (
                <Link
                  key={deal.id}
                  to={`/deals/${deal.id}`}
                  draggable
                  onDragStart={() => handleDragStart(deal)}
                  className={`block p-3 rounded-lg border-2 cursor-move hover:shadow-md transition-all ${getCardColor(deal.winProbability)}`}
                >
                  {/* Deal name */}
                  <p className="font-semibold text-sm text-gray-900 dark:text-slate-100 truncate leading-snug">
                    {deal.name}
                  </p>

                  {/* Account */}
                  {deal.accountName && (
                    <p className="text-xs text-gray-500 dark:text-slate-400 truncate mt-0.5">
                      {deal.accountName}
                    </p>
                  )}

                  {/* Value */}
                  <p className="text-xs font-medium text-gray-700 dark:text-slate-300 mt-1">
                    ${deal.value.toLocaleString()}
                  </p>

                  {/* Win probability row */}
                  <div className="mt-2 flex items-center justify-between gap-2">
                    <span
                      className={`text-xs font-bold px-2 py-0.5 rounded-full ${getBadgeColor(deal.winProbability)}`}
                    >
                      {deal.winProbability}%
                    </span>
                    <div className="flex-1 h-1.5 bg-gray-300 dark:bg-slate-600 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${getBarColor(deal.winProbability)}`}
                        style={{ width: `${deal.winProbability}%` }}
                      />
                    </div>
                  </div>
                </Link>
              ))}

              {column.deals.length === 0 && (
                <p className="text-xs text-gray-400 dark:text-slate-500 text-center py-6 italic">
                  No deals
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
