
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '../store/authStore'

const FEATURES = [
  { icon: '🤖', title: 'AI Win Probability', desc: 'Real-time ML scoring on every deal using Amazon SageMaker. Know which deals to prioritize before your competitors do. Confidence intervals included on every score.' },
  { icon: '📈', title: 'Revenue Forecasting', desc: 'Weekly, monthly, and quarterly forecasts with upper/lower confidence bands. Export to CSV or JSON. Never miss a board target again.' },
  { icon: '💡', title: 'Smart Insights', desc: 'AI-generated recommendations ranked by revenue impact. Stalled deal alerts, next best actions, engagement spikes — all surfaced automatically.' },
  { icon: '🔗', title: 'CRM Integration', desc: 'Bidirectional sync with Salesforce, HubSpot, and Microsoft Dynamics. Your data stays in sync every 15 minutes, automatically.' },
  { icon: '📊', title: 'Pipeline Kanban', desc: 'Drag-and-drop pipeline management with real-time win probability on every card. Sort by probability, value, or close date.' },
  { icon: '🔔', title: 'Smart Alerts', desc: 'Get notified the moment a deal probability swings 15+ points, goes stale for 14 days, or a close date passes without a stage change.' },
  { icon: '📉', title: 'Analytics Dashboard', desc: 'Total pipeline, weighted pipeline, win rate, forecast vs actual — all filterable by date range, team, stage, and rep.' },
  { icon: '👥', title: 'Team Management', desc: 'Role-based access control (Admin, Manager, Sales Rep). Invite users, assign roles, view audit logs, manage permissions.' },
  { icon: '🔐', title: 'Enterprise Security', desc: 'AES-256 encryption at rest, TLS 1.2+ in transit, GDPR/CCPA compliant, SOC 2 Type II, SSO via SAML 2.0 and OAuth 2.0.' },
]

const STEPS = [
  { n: '01', title: 'Create Your Account', desc: 'Sign up with your email in under 60 seconds. No credit card required for the 14-day free trial.' },
  { n: '02', title: 'Connect Your CRM', desc: 'One-click OAuth connection to Salesforce, HubSpot, or Dynamics. Your deals and contacts sync automatically.' },
  { n: '03', title: 'AI Trains on Your Data', desc: 'Our ML models train on your historical deals and signals within minutes of connecting your CRM.' },
  { n: '04', title: 'Get Predictions & Close More', desc: 'Real-time win probability scores and actionable insights appear on every deal. Your team knows exactly what to do next.' },
]

const TESTIMONIALS = [
  { name: 'Sarah Johnson', role: 'VP of Sales, TechVision Inc', text: 'SalesPred AI transformed how our team prioritizes deals. Win rates up 40% in just 3 months. The AI insights are incredibly accurate.', avatar: 'SJ', color: 'from-blue-500 to-blue-700' },
  { name: 'Michael Chen', role: 'Sales Director, CloudFirst Systems', text: 'We closed $2M in deals we would have missed without the stalled deal alerts. The CRM integration was seamless — took 5 minutes to set up.', avatar: 'MC', color: 'from-purple-500 to-purple-700' },
  { name: 'Emily Davis', role: 'Chief Revenue Officer, Digital Dynamics', text: 'Finally a forecasting tool that actually works. Our board presentations are so much easier now. 87% forecast accuracy is real, not marketing.', avatar: 'ED', color: 'from-green-500 to-green-700' },
  { name: 'Robert Wilson', role: 'Head of Sales, Innovation Labs', text: 'The pipeline kanban with AI probability scores changed everything. My team spends time on the right deals now. Revenue up 28% this quarter.', avatar: 'RW', color: 'from-orange-500 to-orange-700' },
]

const TIERS = [
  {
    name: 'Starter', price: '$99', period: '/month',
    desc: 'Perfect for small sales teams getting started with AI.',
    features: ['5 Users', '100 Deals', '10K API Requests/mo', 'AI Win Probability Scoring', 'Revenue Forecasting', 'Pipeline Kanban', 'CSV/JSON Export', 'Email Support'],
    cta: 'Start Free Trial', highlight: false,
  },
  {
    name: 'Growth', price: '$299', period: '/month',
    desc: 'For growing teams that need more power and analytics.',
    features: ['25 Users', '1,000 Deals', '100K API Requests/mo', 'Everything in Starter', 'CRM Integrations (3)', 'Advanced Analytics', 'Smart Insights', 'Priority Support', 'SSO / OAuth'],
    cta: 'Start Free Trial', highlight: true,
  },
  {
    name: 'Enterprise', price: '$999', period: '/month',
    desc: 'Unlimited scale with dedicated support and custom models.',
    features: ['Unlimited Users', 'Unlimited Deals', '1M API Requests/mo', 'Everything in Growth', 'Custom ML Models per Tenant', 'Dedicated Customer Success Manager', '24/7 Phone Support', 'SLA 99.95%', 'SAML 2.0 SSO', 'GDPR/CCPA Compliance'],
    cta: 'Contact Sales', highlight: false,
  },
]

const FAQS = [
  { q: 'How does the AI win probability work?', a: 'Our ML models are trained on your own historical CRM data — deal age, stage velocity, engagement signals, and historical close rates. Every time a new signal comes in (email opened, call logged, etc.), the model re-scores the deal within 5 minutes.' },
  { q: 'Which CRMs do you integrate with?', a: 'We support Salesforce, HubSpot, and Microsoft Dynamics 365 with full bidirectional sync. We also support Gmail, Outlook, and Google/Outlook Calendar for engagement signals.' },
  { q: 'Is my data secure?', a: 'Yes. All data is encrypted at rest (AES-256 via AWS KMS) and in transit (TLS 1.2+). We are SOC 2 Type II certified, GDPR and CCPA compliant, and deploy in isolated tenant environments on AWS.' },
  { q: 'How long does setup take?', a: 'Most teams are up and running in under 10 minutes. Connect your CRM, invite your team, and the AI starts training immediately. You will see your first predictions within minutes.' },
  { q: 'Can I cancel anytime?', a: 'Yes. No long-term contracts. Cancel anytime from your billing settings. Your data is available for export for 30 days after cancellation.' },
  { q: 'Do you offer a free trial?', a: 'Yes — 14 days free, no credit card required. Full access to all features on the Growth plan during your trial.' },
]

export default function LandingPage() {
  const navigate = useNavigate()
  const { isAuthenticated } = useAuthStore()
  const [openFaq, setOpenFaq] = useState<number | null>(null)
  const [liveCount, setLiveCount] = useState(10247)

  // Simulate live user count ticking up
  useEffect(() => {
    const t = setInterval(() => setLiveCount((n) => n + Math.floor(Math.random() * 3)), 4000)
    return () => clearInterval(t)
  }, [])

  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans overflow-x-hidden">

      {/* ── NAVBAR ── */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-sm shadow">SP</div>
            <span className="text-lg font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">SalesPred AI</span>
          </div>
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-gray-600">
            <a href="#features" className="hover:text-blue-600 transition-colors">Features</a>
            <a href="#how-it-works" className="hover:text-blue-600 transition-colors">How It Works</a>
            <a href="#pricing" className="hover:text-blue-600 transition-colors">Pricing</a>
            <a href="#testimonials" className="hover:text-blue-600 transition-colors">Customers</a>
            <a href="#faq" className="hover:text-blue-600 transition-colors">FAQ</a>
          </nav>
          <div className="flex items-center gap-3">
            <button onClick={() => navigate('/login')} className="px-4 py-2 text-sm font-semibold text-gray-700 hover:text-blue-600 transition-colors">
              Sign In
            </button>
            <button
              onClick={() => navigate(isAuthenticated ? '/pipeline' : '/signup')}
              className="px-5 py-2 text-sm font-semibold text-white bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all shadow-md"
            >
              {isAuthenticated ? 'Go to Dashboard →' : 'Get Started Free'}
            </button>
          </div>
        </div>
      </header>

      {/* ── HERO ── */}
      <section className="pt-32 pb-24 px-6 bg-gradient-to-br from-slate-900 via-blue-950 to-purple-950 relative overflow-hidden">
        <div className="absolute top-20 left-1/4 w-96 h-96 bg-blue-500 opacity-10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-10 right-1/4 w-80 h-80 bg-purple-500 opacity-10 rounded-full blur-3xl pointer-events-none" />
        <div className="max-w-5xl mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500/20 border border-blue-400/30 text-blue-300 rounded-full text-sm font-medium mb-8">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            {liveCount.toLocaleString()} sales reps using SalesPred AI right now
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold text-white leading-tight mb-6 tracking-tight">
            Predict Which Deals
            <br />
            <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Will Close — Before They Do
            </span>
          </h1>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto mb-10 leading-relaxed">
            SalesPred AI uses machine learning trained on your own CRM data to score every deal in real time, forecast revenue with confidence, and tell your team exactly what to do next.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-6">
            <button onClick={() => navigate('/signup')} className="px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-bold rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all shadow-xl text-lg">
              Start Free Trial — No Card Needed
            </button>
            <button
              onClick={() => navigate(isAuthenticated ? '/pipeline' : '/login')}
              className="px-8 py-4 bg-white/10 border border-white/20 text-white font-semibold rounded-xl hover:bg-white/20 transition-all text-lg backdrop-blur-sm"
            >
              {isAuthenticated ? 'Go to Dashboard →' : 'Sign In to Dashboard →'}
            </button>
          </div>
          <p className="text-slate-400 text-sm">14-day free trial · Cancel anytime · No credit card required</p>
        </div>

        {/* Mock dashboard */}
        <div className="max-w-6xl mx-auto mt-16 px-4 relative z-10">
          <div className="bg-slate-800/80 backdrop-blur rounded-2xl border border-slate-700 shadow-2xl overflow-hidden">
            <div className="flex items-center gap-2 px-4 py-3 bg-slate-900 border-b border-slate-700">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <div className="w-3 h-3 rounded-full bg-yellow-500" />
              <div className="w-3 h-3 rounded-full bg-green-500" />
              <div className="flex-1 mx-4 bg-slate-700 rounded px-3 py-1 text-xs text-slate-400">app.salespred.ai/pipeline</div>
              <span className="text-xs text-green-400 flex items-center gap-1"><span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />Live</span>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-4 gap-4 mb-6">
                {[
                  { label: 'Pipeline Value', value: '$2.5M', change: '+12%', color: 'text-green-400' },
                  { label: 'Win Rate', value: '34%', change: '+8%', color: 'text-blue-400' },
                  { label: 'Active Deals', value: '156', change: '+23', color: 'text-purple-400' },
                  { label: 'Forecast Accuracy', value: '87%', change: '+5%', color: 'text-yellow-400' },
                ].map((s) => (
                  <div key={s.label} className="bg-slate-700/60 rounded-xl p-4">
                    <p className="text-xs text-slate-400 mb-1">{s.label}</p>
                    <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
                    <p className="text-xs text-green-400 mt-1">↑ {s.change}</p>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-5 gap-3">
                {['Prospecting', 'Qualification', 'Proposal', 'Negotiation', 'Closed Won'].map((stage, i) => (
                  <div key={stage} className="bg-slate-700/40 rounded-lg p-3">
                    <p className="text-xs text-slate-400 font-medium mb-2 truncate">{stage}</p>
                    {[...Array(Math.max(1, 3 - i))].map((_, j) => (
                      <div key={j} className="bg-slate-600/60 rounded p-2 mb-2">
                        <div className="h-2 bg-slate-500 rounded w-3/4 mb-1" />
                        <div className="flex items-center justify-between">
                          <div className="h-1.5 bg-slate-500 rounded w-1/2" />
                          <span className={`text-xs font-bold ${j === 0 ? 'text-green-400' : j === 1 ? 'text-blue-400' : 'text-yellow-400'}`}>{[78, 54, 31][j]}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── SOCIAL PROOF ── */}
      <section className="py-12 bg-gray-50 border-y border-gray-100">
        <div className="max-w-5xl mx-auto px-6">
          <p className="text-center text-xs text-gray-400 font-semibold mb-6 uppercase tracking-widest">Trusted by sales teams at</p>
          <div className="flex flex-wrap justify-center items-center gap-10 opacity-40">
            {['Acme Corp', 'TechVision', 'CloudFirst', 'DataFlow Analytics', 'NextGen Software', 'Enterprise Plus'].map((co) => (
              <span key={co} className="text-base font-bold text-gray-700">{co}</span>
            ))}
          </div>
        </div>
      </section>

      {/* ── STATS ── */}
      <section className="py-20 px-6">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {[
            { value: '10,000+', label: 'Active Sales Reps' },
            { value: '$2.4B', label: 'Pipeline Managed' },
            { value: '87%', label: 'Forecast Accuracy' },
            { value: '3.2×', label: 'Win Rate Improvement' },
          ].map((s) => (
            <div key={s.label}>
              <p className="text-4xl font-extrabold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">{s.value}</p>
              <p className="text-gray-500 mt-2 text-sm font-medium">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── FEATURES ── */}
      <section id="features" className="py-24 px-6 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-blue-600 font-semibold text-sm uppercase tracking-widest">Features</span>
            <h2 className="text-4xl font-extrabold text-gray-900 mt-2 mb-4">Everything your sales team needs</h2>
            <p className="text-xl text-gray-500 max-w-2xl mx-auto">One platform to predict, manage, and close more deals — powered by AI trained on your own data.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {FEATURES.map((f) => (
              <div key={f.title} className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm hover:shadow-md hover:-translate-y-1 transition-all">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-50 to-purple-50 border border-blue-100 rounded-xl flex items-center justify-center text-2xl mb-4">{f.icon}</div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">{f.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── HOW IT WORKS ── */}
      <section id="how-it-works" className="py-24 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-blue-600 font-semibold text-sm uppercase tracking-widest">How It Works</span>
            <h2 className="text-4xl font-extrabold text-gray-900 mt-2 mb-4">Up and running in under 5 minutes</h2>
            <p className="text-xl text-gray-500">No complex setup. No data science team required.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {STEPS.map((s, i) => (
              <div key={s.n} className="text-center relative">
                {i < STEPS.length - 1 && (
                  <div className="hidden md:block absolute top-6 left-1/2 w-full h-0.5 bg-gradient-to-r from-blue-200 to-purple-200" style={{ left: '60%', width: '80%' }} />
                )}
                <div className="relative z-10 w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold mx-auto mb-4 shadow-lg">{s.n}</div>
                <h3 className="font-bold text-gray-900 mb-2">{s.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
          <div className="mt-12 text-center">
            <button onClick={() => navigate('/signup')} className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all shadow-lg text-lg">
              Get Started Free →
            </button>
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section id="testimonials" className="py-24 px-6 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-blue-600 font-semibold text-sm uppercase tracking-widest">Customers</span>
            <h2 className="text-4xl font-extrabold text-gray-900 mt-2 mb-4">Sales teams love SalesPred AI</h2>
            <p className="text-xl text-gray-500">Real results from real customers.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {TESTIMONIALS.map((t) => (
              <div key={t.name} className="bg-white rounded-2xl p-8 border border-gray-100 shadow-sm">
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(5)].map((_, i) => <span key={i} className="text-yellow-400 text-lg">★</span>)}
                </div>
                <p className="text-gray-700 leading-relaxed mb-6 italic text-base">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 bg-gradient-to-br ${t.color} rounded-full flex items-center justify-center text-white font-bold flex-shrink-0`}>{t.avatar}</div>
                  <div>
                    <p className="font-bold text-gray-900">{t.name}</p>
                    <p className="text-gray-400 text-sm">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PRICING ── */}
      <section id="pricing" className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-blue-600 font-semibold text-sm uppercase tracking-widest">Pricing</span>
            <h2 className="text-4xl font-extrabold text-gray-900 mt-2 mb-4">Simple, transparent pricing</h2>
            <p className="text-xl text-gray-500">Start free. Scale as you grow. No hidden fees.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-start">
            {TIERS.map((tier) => (
              <div key={tier.name} className={`rounded-2xl p-8 relative ${tier.highlight ? 'bg-gradient-to-br from-blue-600 to-purple-600 text-white shadow-2xl scale-105' : 'bg-white border border-gray-200 shadow-sm'}`}>
                {tier.highlight && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                    <span className="px-4 py-1.5 bg-yellow-400 text-yellow-900 text-xs font-bold rounded-full uppercase tracking-wide shadow">Most Popular</span>
                  </div>
                )}
                <h3 className={`text-xl font-bold mb-1 ${tier.highlight ? 'text-white' : 'text-gray-900'}`}>{tier.name}</h3>
                <p className={`text-sm mb-5 ${tier.highlight ? 'text-blue-100' : 'text-gray-500'}`}>{tier.desc}</p>
                <div className="flex items-baseline gap-1 mb-6">
                  <span className={`text-4xl font-extrabold ${tier.highlight ? 'text-white' : 'text-gray-900'}`}>{tier.price}</span>
                  <span className={`text-sm ${tier.highlight ? 'text-blue-200' : 'text-gray-400'}`}>{tier.period}</span>
                </div>
                <ul className="space-y-3 mb-8">
                  {tier.features.map((f) => (
                    <li key={f} className={`flex items-start gap-2 text-sm ${tier.highlight ? 'text-blue-100' : 'text-gray-600'}`}>
                      <span className={`mt-0.5 flex-shrink-0 ${tier.highlight ? 'text-green-300' : 'text-green-500'}`}>✓</span>{f}
                    </li>
                  ))}
                </ul>
                <button onClick={() => navigate('/signup')} className={`w-full py-3 rounded-xl font-semibold transition-all ${tier.highlight ? 'bg-white text-blue-600 hover:bg-blue-50 shadow-md' : 'bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700'}`}>
                  {tier.cta}
                </button>
              </div>
            ))}
          </div>
          <p className="text-center text-gray-400 text-sm mt-8">All plans include a 14-day free trial. No credit card required to start.</p>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section id="faq" className="py-24 px-6 bg-gray-50">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-blue-600 font-semibold text-sm uppercase tracking-widest">FAQ</span>
            <h2 className="text-4xl font-extrabold text-gray-900 mt-2 mb-4">Frequently Asked Questions</h2>
          </div>
          <div className="space-y-3">
            {FAQS.map((faq, i) => (
              <div key={i} className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                <button onClick={() => setOpenFaq(openFaq === i ? null : i)} className="w-full flex items-center justify-between px-6 py-4 text-left">
                  <span className="font-semibold text-gray-900">{faq.q}</span>
                  <span className={`text-blue-600 text-xl transition-transform ${openFaq === i ? 'rotate-45' : ''}`}>+</span>
                </button>
                {openFaq === i && (
                  <div className="px-6 pb-5 text-gray-600 text-sm leading-relaxed border-t border-gray-100 pt-3">{faq.a}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FINAL CTA ── */}
      <section className="py-24 px-6 bg-gradient-to-br from-slate-900 via-blue-950 to-purple-950 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-10 left-1/3 w-72 h-72 bg-blue-500 opacity-10 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-1/3 w-72 h-72 bg-purple-500 opacity-10 rounded-full blur-3xl" />
        </div>
        <div className="max-w-3xl mx-auto text-center relative z-10">
          <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-4">Ready to close more deals?</h2>
          <p className="text-xl text-slate-300 mb-10">Join {liveCount.toLocaleString()} sales reps using AI to hit their targets every quarter.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button onClick={() => navigate('/signup')} className="px-8 py-4 bg-white text-blue-600 font-bold rounded-xl hover:bg-blue-50 transition-all shadow-xl text-lg">
              Create Free Account →
            </button>
            <button onClick={() => navigate('/login')} className="px-8 py-4 bg-white/10 border border-white/20 text-white font-semibold rounded-xl hover:bg-white/20 transition-all text-lg">
              Sign In
            </button>
          </div>
          <p className="text-slate-400 text-sm mt-6">No credit card · 14-day trial · Cancel anytime</p>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="bg-gray-900 text-gray-400 py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8 mb-12">
            <div className="col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-sm">SP</div>
                <span className="text-white font-bold text-lg">SalesPred AI</span>
              </div>
              <p className="text-sm leading-relaxed mb-4">AI-powered sales predictions for modern B2B teams. Close more deals with confidence.</p>
              <div className="flex items-center gap-2 text-sm">
                <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                <span className="text-green-400">All systems operational</span>
              </div>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4 text-sm">Product</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#features" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#pricing" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="#how-it-works" className="hover:text-white transition-colors">How It Works</a></li>
                <li><a href="#testimonials" className="hover:text-white transition-colors">Customers</a></li>
                <li><a href="#faq" className="hover:text-white transition-colors">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4 text-sm">Account</h4>
              <ul className="space-y-2 text-sm">
                <li><button onClick={() => navigate('/signup')} className="hover:text-white transition-colors text-left">Sign Up Free</button></li>
                <li><button onClick={() => navigate('/login')} className="hover:text-white transition-colors text-left">Sign In</button></li>
                <li><button onClick={() => navigate('/forgot-password')} className="hover:text-white transition-colors text-left">Forgot Password</button></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4 text-sm">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white transition-colors">GDPR</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Security</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-sm">
            <p>© 2024 SalesPred AI. All rights reserved.</p>
            <p>Built with ❤️ for sales teams worldwide</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
