import { useState } from 'react'
import { useParams } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from 'react-query'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine, Area, AreaChart } from 'recharts'
import { apiClient } from '../services/api'
import BackButton from '../components/BackButton'

const STAGES = ['Prospecting', 'Qualification', 'Proposal', 'Negotiation', 'Closed Won']

export default function DealDetailPage() {
  const { id } = useParams<{ id: string }>()
  const queryClient = useQueryClient()
  const [editMode, setEditMode] = useState(false)
  const [editData, setEditData] = useState<any>(null)
  const [saveMsg, setSaveMsg] = useState('')

  const { data: deal, isLoading: dealLoading } = useQuery(['deal', id], () => apiClient.getDealById(id!))
  const { data: predictions = [], isLoading: predictionsLoading } = useQuery(['predictions', id], () => apiClient.getPredictionsForDeal(id!))

  const updateMutation = useMutation((data: any) => apiClient.updateDeal(id!, data), {
    onSuccess: () => {
      queryClient.invalidateQueries(['deal', id])
      setEditMode(false)
      setSaveMsg('Deal updated successfully!')
      setTimeout(() => setSaveMsg(''), 3000)
    },
  })

  if (dealLoading || predictionsLoading) {
    return <div className="text-center py-8 text-gray-600 dark:text-slate-400">Loading deal details...</div>
  }
  if (!deal) {
    return <div className="text-center py-8 text-red-600">Deal not found</div>
  }

  const chartData = (predictions as any[]).map((p) => ({
    date: new Date(p.computedAt).toLocaleDateString(),
    probability: p.winProbability,
    low: p.confidenceLow,
    high: p.confidenceHigh,
  }))

  const latestPrediction = (predictions as any[])[predictions.length - 1]
  const topFactors = latestPrediction?.topFactors || []

  const probColor = (p: number) =>
    p >= 75 ? 'text-green-600 bg-green-50 dark:text-green-400 dark:bg-green-900/30' :
    p >= 50 ? 'text-blue-600 bg-blue-50 dark:text-blue-400 dark:bg-blue-900/30' :
    p >= 25 ? 'text-yellow-600 bg-yellow-50 dark:text-yellow-400 dark:bg-yellow-900/30' :
              'text-red-600 bg-red-50 dark:text-red-400 dark:bg-red-900/30'

  const barColor = (p: number) =>
    p >= 75 ? 'bg-green-500' : p >= 50 ? 'bg-blue-500' : p >= 25 ? 'bg-yellow-500' : 'bg-red-500'

  const handleSave = () => {
    if (editData) updateMutation.mutate(editData)
  }

  return (
    <div>
      <BackButton />

      {saveMsg && (
        <div className="fixed top-6 right-6 z-50 px-5 py-3 bg-green-600 text-white rounded-xl shadow-2xl text-sm font-medium">
          ✓ {saveMsg}
        </div>
      )}

      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-slate-100">{deal.name}</h1>
          <p className="text-gray-500 dark:text-slate-400 mt-1">{deal.accountName}</p>
        </div>
        <button
          onClick={() => { setEditData({ name: deal.name, value: deal.value, stage: deal.stage, closeDate: deal.closeDate?.split('T')[0] }); setEditMode(true) }}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium text-sm"
        >
          ✏️ Edit Deal
        </button>
      </div>

      {/* Edit form */}
      {editMode && editData && (
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-6 mb-8 border border-blue-200 dark:border-blue-700">
          <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-4">Edit Deal</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-600 dark:text-slate-400 mb-1">Deal Name</label>
              <input type="text" value={editData.name} onChange={(e) => setEditData({ ...editData, name: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 dark:text-slate-400 mb-1">Value ($)</label>
              <input type="number" value={editData.value} onChange={(e) => setEditData({ ...editData, value: parseFloat(e.target.value) })} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 dark:text-slate-400 mb-1">Stage</label>
              <select value={editData.stage} onChange={(e) => setEditData({ ...editData, stage: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100">
                {STAGES.map((s) => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 dark:text-slate-400 mb-1">Close Date</label>
              <input type="date" value={editData.closeDate} onChange={(e) => setEditData({ ...editData, closeDate: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <button onClick={handleSave} disabled={updateMutation.isLoading} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 font-medium text-sm">
              {updateMutation.isLoading ? 'Saving…' : 'Save Changes'}
            </button>
            <button onClick={() => setEditMode(false)} className="px-4 py-2 border border-gray-300 text-gray-700 dark:text-slate-300 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-700 font-medium text-sm">
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Key metrics */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Deal Value', value: `$${deal.value.toLocaleString()}`, extra: '' },
          { label: 'Current Stage', value: deal.stage, extra: '' },
          { label: 'Close Date', value: new Date(deal.closeDate).toLocaleDateString(), extra: '' },
        ].map((m) => (
          <div key={m.label} className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow border border-gray-100 dark:border-slate-700">
            <p className="text-gray-500 dark:text-slate-400 text-sm font-medium">{m.label}</p>
            <p className="text-2xl font-bold text-gray-900 dark:text-slate-100 mt-2">{m.value}</p>
          </div>
        ))}
        <div className={`p-6 rounded-xl shadow border ${probColor(deal.winProbability)}`}>
          <p className="text-sm font-medium">Win Probability</p>
          <p className="text-3xl font-bold mt-2">{deal.winProbability}%</p>
          <div className="mt-2 h-1.5 bg-white/40 rounded-full overflow-hidden">
            <div className={`h-full rounded-full ${barColor(deal.winProbability)}`} style={{ width: `${deal.winProbability}%` }} />
          </div>
        </div>
      </div>

      {/* Contact + Top Factors */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow border border-gray-100 dark:border-slate-700">
          <p className="text-gray-500 dark:text-slate-400 text-sm font-medium mb-3">Contact</p>
          <p className="text-lg font-semibold text-gray-900 dark:text-slate-100">{deal.contact || '—'}</p>
          <p className="text-sm text-gray-600 dark:text-slate-400 mt-1">{deal.email || '—'}</p>
          <p className="text-sm text-gray-600 dark:text-slate-400">{deal.phone || '—'}</p>
        </div>
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow border border-gray-100 dark:border-slate-700 col-span-2">
          <p className="text-gray-500 dark:text-slate-400 text-sm font-medium mb-4">Top Signal Factors</p>
          <div className="space-y-3">
            {topFactors.map((factor: string, idx: number) => (
              <div key={idx} className="flex items-center gap-3">
                <span className="text-sm text-gray-700 dark:text-slate-300 w-40 truncate">{factor}</span>
                <div className="flex-1 h-2 bg-gray-200 dark:bg-slate-600 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 rounded-full" style={{ width: `${100 - idx * 15}%` }} />
                </div>
                <span className="text-xs text-gray-500 dark:text-slate-400 w-8 text-right">{100 - idx * 15}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Win Probability Chart */}
      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow border border-gray-100 dark:border-slate-700 mb-8">
        <h2 className="text-xl font-bold text-gray-900 dark:text-slate-100 mb-4">Win Probability Trend</h2>
        {chartData.length > 0 ? (
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="probGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#6b7280' }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#6b7280' }} tickFormatter={(v) => `${v}%`} />
              <Tooltip formatter={(v: any) => `${v}%`} contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: 8, color: '#f1f5f9' }} />
              <Legend />
              <ReferenceLine y={50} stroke="#9ca3af" strokeDasharray="5 5" label={{ value: '50%', fill: '#9ca3af', fontSize: 11 }} />
              <Area type="monotone" dataKey="probability" stroke="#3b82f6" fill="url(#probGrad)" name="Win Probability" strokeWidth={2} dot={{ fill: '#3b82f6', r: 3 }} />
              <Line type="monotone" dataKey="low" stroke="#93c5fd" name="Confidence Low" strokeWidth={1} strokeDasharray="4 4" dot={false} />
              <Line type="monotone" dataKey="high" stroke="#1e40af" name="Confidence High" strokeWidth={1} strokeDasharray="4 4" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        ) : (
          <p className="text-gray-500 dark:text-slate-400">No prediction history available</p>
        )}
      </div>

      {/* Recent Signals */}
      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow border border-gray-100 dark:border-slate-700">
        <h2 className="text-xl font-bold text-gray-900 dark:text-slate-100 mb-4">Recent Signals</h2>
        {deal.signals && deal.signals.length > 0 ? (
          <div className="space-y-2">
            {deal.signals.slice(0, 6).map((signal: any) => (
              <div key={signal.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-slate-700 rounded-lg">
                <div>
                  <p className="font-semibold text-sm text-gray-900 dark:text-slate-100">{signal.type}</p>
                  <p className="text-xs text-gray-500 dark:text-slate-400">{signal.source}</p>
                </div>
                <p className="text-xs text-gray-400 dark:text-slate-500">{new Date(signal.timestamp).toLocaleDateString()}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500 dark:text-slate-400">No signals recorded yet</p>
        )}
      </div>
    </div>
  )
}
