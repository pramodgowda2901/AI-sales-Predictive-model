import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import BackButton from '../components/BackButton'

const STEPS = [
  { id: 'crm', title: 'Connect CRM', icon: '🔗', description: 'Connect your CRM to sync deals and contacts automatically' },
  { id: 'users', title: 'Invite Team', icon: '👥', description: 'Invite your first 5 team members to collaborate' },
  { id: 'pipeline', title: 'Configure Pipeline', icon: '📊', description: 'Set up your custom pipeline stages' },
  { id: 'sample', title: 'Load Sample Data', icon: '📦', description: 'Explore the platform with pre-built sample data' },
]

export default function OnboardingPage() {
  const navigate = useNavigate()
  const [currentStep, setCurrentStep] = useState(0)
  const [completedSteps, setCompletedSteps] = useState<Set<string>>(new Set())
  const [loading, setLoading] = useState(false)
  const [done, setDone] = useState(false)

  // Step-specific state
  const [selectedCRM, setSelectedCRM] = useState('')
  const [inviteEmails, setInviteEmails] = useState(['', '', '', '', ''])
  const [stages, setStages] = useState(['Prospecting', 'Qualification', 'Proposal', 'Negotiation', 'Closed Won'])
  const [newStage, setNewStage] = useState('')

  const completeStep = async (stepId: string) => {
    setLoading(true)
    await new Promise((r) => setTimeout(r, 800))
    setCompletedSteps((prev) => new Set([...prev, stepId]))
    setLoading(false)
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handleFinish = async () => {
    setLoading(true)
    await new Promise((r) => setTimeout(r, 1000))
    setDone(true)
    setLoading(false)
  }

  const allDone = completedSteps.size === STEPS.length

  if (done) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl p-10 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🎉</div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">You're all set!</h1>
          <p className="text-gray-600 mb-6">Your workspace is ready. Start managing your deals with AI-powered insights.</p>
          <div className="bg-gray-50 rounded-lg p-4 mb-6 text-left">
            <p className="text-xs text-gray-500 mb-1">Your Tenant ID</p>
            <code className="text-sm font-mono text-gray-800">tenant-{Math.random().toString(36).substr(2, 8)}</code>
          </div>
          <button
            onClick={() => navigate('/pipeline')}
            className="w-full px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700"
          >
            Go to Pipeline →
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Welcome! Let's get you set up</h1>
        <p className="text-gray-600 mt-2">Complete these steps to start using the platform</p>
      </div>

      {/* Progress */}
      <div className="flex items-center mb-8">
        {STEPS.map((step, i) => (
          <div key={step.id} className="flex items-center flex-1">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-colors ${
              completedSteps.has(step.id)
                ? 'bg-green-500 text-white'
                : i === currentStep
                ? 'bg-blue-600 text-white'
                : 'bg-gray-200 text-gray-500'
            }`}>
              {completedSteps.has(step.id) ? '✓' : i + 1}
            </div>
            {i < STEPS.length - 1 && (
              <div className={`flex-1 h-1 mx-2 rounded ${completedSteps.has(step.id) ? 'bg-green-400' : 'bg-gray-200'}`} />
            )}
          </div>
        ))}
      </div>

      {/* Step Cards */}
      <div className="space-y-4">
        {STEPS.map((step, i) => {
          const isActive = i === currentStep
          const isDone = completedSteps.has(step.id)
          const isLocked = i > currentStep && !isDone

          return (
            <div
              key={step.id}
              className={`bg-white rounded-xl shadow p-6 border-2 transition-all ${
                isActive ? 'border-blue-500' : isDone ? 'border-green-400' : 'border-gray-200 opacity-60'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{step.icon}</span>
                  <div>
                    <h3 className="font-bold text-gray-900">{step.title}</h3>
                    <p className="text-sm text-gray-500">{step.description}</p>
                  </div>
                </div>
                {isDone && <span className="text-green-500 text-xl">✓</span>}
              </div>

              {isActive && (
                <div className="mt-4 pt-4 border-t border-gray-100">
                  {/* CRM Step */}
                  {step.id === 'crm' && (
                    <div className="space-y-3">
                      <p className="text-sm font-medium text-gray-700">Select your CRM:</p>
                      <div className="grid grid-cols-3 gap-3">
                        {['Salesforce', 'HubSpot', 'Microsoft Dynamics'].map((crm) => (
                          <button
                            key={crm}
                            onClick={() => setSelectedCRM(crm)}
                            className={`p-3 border-2 rounded-lg text-sm font-medium transition-colors ${
                              selectedCRM === crm ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-200 hover:border-gray-300'
                            }`}
                          >
                            {crm}
                          </button>
                        ))}
                      </div>
                      <button
                        onClick={() => completeStep(step.id)}
                        disabled={loading || !selectedCRM}
                        className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 font-medium text-sm"
                      >
                        {loading ? 'Connecting...' : `Connect ${selectedCRM || 'CRM'}`}
                      </button>
                    </div>
                  )}

                  {/* Users Step */}
                  {step.id === 'users' && (
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-gray-700">Enter email addresses (at least 1):</p>
                      {inviteEmails.map((email, idx) => (
                        <input
                          key={idx}
                          type="email"
                          value={email}
                          onChange={(e) => {
                            const updated = [...inviteEmails]
                            updated[idx] = e.target.value
                            setInviteEmails(updated)
                          }}
                          placeholder={`Team member ${idx + 1} email`}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                        />
                      ))}
                      <button
                        onClick={() => completeStep(step.id)}
                        disabled={loading || !inviteEmails.some((e) => e.trim())}
                        className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 font-medium text-sm"
                      >
                        {loading ? 'Sending invites...' : 'Send Invitations'}
                      </button>
                    </div>
                  )}

                  {/* Pipeline Step */}
                  {step.id === 'pipeline' && (
                    <div className="space-y-3">
                      <p className="text-sm font-medium text-gray-700">Your pipeline stages:</p>
                      <div className="flex flex-wrap gap-2">
                        {stages.map((s, idx) => (
                          <span key={idx} className="flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                            {s}
                            <button onClick={() => setStages(stages.filter((_, i) => i !== idx))} className="text-blue-500 hover:text-blue-700 ml-1">×</button>
                          </span>
                        ))}
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={newStage}
                          onChange={(e) => setNewStage(e.target.value)}
                          placeholder="Add custom stage..."
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && newStage.trim()) {
                              setStages([...stages, newStage.trim()])
                              setNewStage('')
                            }
                          }}
                        />
                        <button
                          onClick={() => { if (newStage.trim()) { setStages([...stages, newStage.trim()]); setNewStage('') } }}
                          className="px-3 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 text-sm"
                        >
                          Add
                        </button>
                      </div>
                      <button
                        onClick={() => completeStep(step.id)}
                        disabled={loading || stages.length === 0}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 font-medium text-sm"
                      >
                        {loading ? 'Saving...' : 'Save Pipeline Stages'}
                      </button>
                    </div>
                  )}

                  {/* Sample Data Step */}
                  {step.id === 'sample' && (
                    <div className="space-y-3">
                      <p className="text-sm text-gray-600">Load 25 sample deals, signals, and AI predictions to explore the platform before connecting live data.</p>
                      <button
                        onClick={() => completeStep(step.id)}
                        disabled={loading}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 font-medium text-sm"
                      >
                        {loading ? 'Loading data...' : 'Load Sample Data'}
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )
        })}
      </div>

      {allDone && (
        <div className="mt-6 text-center">
          <button
            onClick={handleFinish}
            disabled={loading}
            className="px-8 py-3 bg-gradient-to-r from-green-500 to-blue-600 text-white rounded-xl font-bold text-lg hover:from-green-600 hover:to-blue-700 disabled:opacity-50"
          >
            {loading ? 'Finishing...' : '🎉 Complete Setup'}
          </button>
        </div>
      )}
    </div>
  )
}
