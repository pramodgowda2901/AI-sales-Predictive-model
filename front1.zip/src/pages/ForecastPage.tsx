import { useState } from 'react'
import { useQuery } from 'react-query'
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ComposedChart, Bar } from 'recharts'
import { apiClient } from '../services/api'
import { Forecast } from '../services/mockData'
import BackButton from '../components/BackButton'

// Export functions
const exportAsCSV = (forecasts: Forecast[]) => {
  const headers = ['Period Start', 'Period End', 'Horizon', 'Projected Value', 'Confidence Low', 'Confidence High']
  const rows = forecasts.map(f => [
    f.periodStart,
    f.periodEnd,
    f.horizon,
    f.projectedValue,
    f.confidenceLow,
    f.confidenceHigh
  ])
  
  const csv = [headers, ...rows].map(row => row.join(',')).join('\n')
  const blob = new Blob([csv], { type: 'text/csv' })
  const url = window.URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `forecasts-${new Date().toISOString().split('T')[0]}.csv`
  a.click()
  window.URL.revokeObjectURL(url)
}

const exportAsJSON = (forecasts: Forecast[]) => {
  const json = JSON.stringify(forecasts, null, 2)
  const blob = new Blob([json], { type: 'application/json' })
  const url = window.URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `forecasts-${new Date().toISOString().split('T')[0]}.json`
  a.click()
  window.URL.revokeObjectURL(url)
}

export default function ForecastPage() {
  const [selectedHorizon, setSelectedHorizon] = useState<'weekly' | 'monthly' | 'quarterly'>('monthly')

  const { data: forecasts = [], isLoading } = useQuery('forecasts', () => apiClient.getForecasts())

  const filteredForecasts = forecasts.filter((f: Forecast) => f.horizon === selectedHorizon)

  const chartData = filteredForecasts.map((f: Forecast) => ({
    period: new Date(f.periodStart).toLocaleDateString(),
    projected: f.projectedValue,
    low: f.confidenceLow,
    high: f.confidenceHigh,
    actual: Math.random() > 0.3 ? f.projectedValue * (0.85 + Math.random() * 0.3) : undefined,
  }))

  const totalProjected = filteredForecasts.reduce((sum, f: Forecast) => sum + f.projectedValue, 0)
  const avgConfidence = filteredForecasts.length > 0 ? 85 : 0

  if (isLoading) {
    return <div className="text-center py-8">Loading forecasts...</div>
  }

  return (
    <div>
      <BackButton />
      <h1 className="text-3xl font-bold mb-8 dark:text-slate-100">Revenue Forecasts</h1>

      <div className="mb-6 flex gap-2">
        {(['weekly', 'monthly', 'quarterly'] as const).map((horizon) => (
          <button
            key={horizon}
            onClick={() => setSelectedHorizon(horizon)}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              selectedHorizon === horizon
                ? 'bg-blue-600 text-white'
                : 'bg-gray-200 dark:bg-slate-700 text-gray-800 dark:text-slate-200 hover:bg-gray-300 dark:hover:bg-slate-600'
            }`}
          >
            {horizon.charAt(0).toUpperCase() + horizon.slice(1)}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow border border-gray-100 dark:border-slate-700">
          <p className="text-gray-500 dark:text-slate-400 text-sm font-medium">Total Projected</p>
          <p className="text-3xl font-bold mt-2 dark:text-slate-100">${(totalProjected / 1000000).toFixed(1)}M</p>
        </div>
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow border border-gray-100 dark:border-slate-700">
          <p className="text-gray-500 dark:text-slate-400 text-sm font-medium">Forecast Periods</p>
          <p className="text-3xl font-bold mt-2 dark:text-slate-100">{filteredForecasts.length}</p>
        </div>
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow border border-gray-100 dark:border-slate-700">
          <p className="text-gray-500 dark:text-slate-400 text-sm font-medium">Avg Confidence</p>
          <p className="text-3xl font-bold mt-2 text-green-600 dark:text-green-400">{avgConfidence}%</p>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow border border-gray-100 dark:border-slate-700 mb-8">
        <h2 className="text-xl font-bold mb-4 dark:text-slate-100">Forecast Trend</h2>
        {chartData.length > 0 ? (
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="period" tick={{ fontSize: 11, fill: '#9ca3af' }} />
              <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} />
              <Tooltip
                formatter={(value: any) => `$${(value / 1000).toFixed(0)}K`}
                contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: 8, color: '#f1f5f9' }}
              />
              <Legend />
              <Area type="monotone" dataKey="low" stackId="1" stroke="#93c5fd" fill="#dbeafe" name="Confidence Low" />
              <Area type="monotone" dataKey="projected" stackId="1" stroke="#3b82f6" fill="#bfdbfe" name="Projected" />
              <Area type="monotone" dataKey="high" stackId="1" stroke="#1e40af" fill="#93c5fd" name="Confidence High" />
            </AreaChart>
          </ResponsiveContainer>
        ) : (
          <p className="text-gray-500 dark:text-slate-400">No forecast data available</p>
        )}
      </div>

      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow border border-gray-100 dark:border-slate-700">
        <h2 className="text-xl font-bold mb-4 dark:text-slate-100">Forecast vs Actual</h2>
        {chartData.length > 0 ? (
          <ResponsiveContainer width="100%" height={300}>
            <ComposedChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="period" tick={{ fontSize: 11, fill: '#9ca3af' }} />
              <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} />
              <Tooltip
                formatter={(value: any) => `$${(value / 1000).toFixed(0)}K`}
                contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: 8, color: '#f1f5f9' }}
              />
              <Legend />
              <Bar dataKey="projected" fill="#3b82f6" name="Projected" />
              <Bar dataKey="actual" fill="#10b981" name="Actual" />
            </ComposedChart>
          </ResponsiveContainer>
        ) : (
          <p className="text-gray-500 dark:text-slate-400">No comparison data available</p>
        )}
      </div>

      <div className="mt-6 flex gap-3">
        <button
          onClick={() => exportAsCSV(filteredForecasts)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium text-sm"
        >
          📥 Export CSV
        </button>
        <button
          onClick={() => exportAsJSON(filteredForecasts)}
          className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium text-sm"
        >
          📋 Export JSON
        </button>
      </div>
    </div>
  )
}
