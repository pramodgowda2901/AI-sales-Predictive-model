import { useState, useEffect } from 'react'
import { apiClient } from '../services/api'
import BackButton from '../components/BackButton'

const TIMEZONES = ['UTC', 'America/New_York (EST)', 'America/Chicago (CST)', 'America/Denver (MST)', 'America/Los_Angeles (PST)', 'Europe/London (GMT)', 'Europe/Paris (CET)', 'Asia/Tokyo (JST)', 'Asia/Kolkata (IST)', 'Australia/Sydney (AEST)']

const INTEGRATIONS_INIT = [
  { name: 'Salesforce', icon: '☁️', connected: true },
  { name: 'HubSpot', icon: '🔗', connected: false },
  { name: 'Microsoft Dynamics', icon: '📊', connected: false },
  { name: 'Slack', icon: '💬', connected: true },
  { name: 'Gmail', icon: '📧', connected: false },
  { name: 'Outlook', icon: '📨', connected: false },
]

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState<'profile' | 'notifications' | 'security' | 'integrations'>('profile')

  // ── Profile ──
  const [editMode, setEditMode] = useState(false)
  const [profileSaved, setProfileSaved] = useState(false)
  const [profileLoading, setProfileLoading] = useState(false)
  const [profile, setProfile] = useState({ fullName: '', email: '', timezone: 'UTC', phone: '' })
  const [editProfile, setEditProfile] = useState({ ...profile })

  useEffect(() => {
    const raw = localStorage.getItem('user')
    if (raw) {
      const u = JSON.parse(raw)
      const p = { fullName: u.fullName || '', email: u.email || '', timezone: u.timezone || 'UTC', phone: u.phone || '' }
      setProfile(p)
      setEditProfile(p)
    }
  }, [])

  const handleSaveProfile = async () => {
    setProfileLoading(true)
    try {
      await apiClient.updateProfile(editProfile)
    } catch {}
    // persist to localStorage
    const raw = localStorage.getItem('user')
    const u = raw ? JSON.parse(raw) : {}
    localStorage.setItem('user', JSON.stringify({ ...u, ...editProfile }))
    setProfile({ ...editProfile })
    setProfileSaved(true)
    setEditMode(false)
    setProfileLoading(false)
    setTimeout(() => setProfileSaved(false), 2500)
  }

  // ── Notifications ──
  const [notifPrefs, setNotifPrefs] = useState({
    dealAlerts: true,
    forecastUpdates: true,
    insights: true,
    weeklyDigest: false,
    systemAlerts: true,
  })
  const [notifSaved, setNotifSaved] = useState(false)

  const handleSaveNotifs = async () => {
    try { await apiClient.updateProfile({ notifications: notifPrefs }) } catch {}
    setNotifSaved(true)
    setTimeout(() => setNotifSaved(false), 2000)
  }

  // ── Security ──
  const [showChangePwd, setShowChangePwd] = useState(false)
  const [pwdForm, setPwdForm] = useState({ current: '', newPwd: '', confirm: '' })
  const [pwdError, setPwdError] = useState('')
  const [pwdSuccess, setPwdSuccess] = useState('')
  const [pwdLoading, setPwdLoading] = useState(false)
  const [twoFAEnabled, setTwoFAEnabled] = useState(false)

  const handleChangePwd = async () => {
    setPwdError('')
    if (!pwdForm.current || !pwdForm.newPwd || !pwdForm.confirm) {
      setPwdError('All fields are required')
      return
    }
    if (pwdForm.newPwd !== pwdForm.confirm) {
      setPwdError('New passwords do not match')
      return
    }
    if (pwdForm.newPwd.length < 8) {
      setPwdError('Password must be at least 8 characters')
      return
    }
    setPwdLoading(true)
    try {
      await apiClient.changePassword(profile.email, pwdForm.current, pwdForm.newPwd)
      setPwdSuccess('Password changed successfully!')
      setPwdForm({ current: '', newPwd: '', confirm: '' })
      setTimeout(() => { setPwdSuccess(''); setShowChangePwd(false) }, 2000)
    } catch (e: any) {
      setPwdError(e?.response?.data?.message || 'Failed to change password')
    } finally {
      setPwdLoading(false)
    }
  }

  // ── Integrations ──
  const [integrations, setIntegrations] = useState(INTEGRATIONS_INIT)
  const [integMsg, setIntegMsg] = useState('')

  const handleToggleIntegration = (name: string) => {
    setIntegrations((prev) =>
      prev.map((i) => (i.name === name ? { ...i, connected: !i.connected } : i))
    )
    const integ = integrations.find((i) => i.name === name)
    setIntegMsg(integ?.connected ? `${name} disconnected` : `${name} connected`)
    setTimeout(() => setIntegMsg(''), 2000)
  }

  return (
    <div>
      <BackButton />
      <h1 className="text-3xl font-bold mb-8">Settings</h1>

      {/* Tabs */}
      <div className="flex gap-4 mb-8 border-b border-gray-200">
        {(['profile', 'notifications', 'security', 'integrations'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 font-medium border-b-2 transition-colors ${
              activeTab === tab ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* ── Profile Tab ── */}
      {activeTab === 'profile' && (
        <div className="bg-white p-6 rounded-lg shadow max-w-xl">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold">Profile Information</h2>
            {profileSaved && <span className="text-green-600 text-sm font-medium">✓ Saved!</span>}
          </div>

          {!editMode ? (
            <div className="space-y-4">
              {[
                { label: 'Full Name', value: profile.fullName || 'Not set' },
                { label: 'Email', value: profile.email || 'Not set' },
                { label: 'Timezone', value: profile.timezone },
                { label: 'Phone', value: profile.phone || 'Not set' },
              ].map((f) => (
                <div key={f.label} className="flex items-center justify-between py-3 border-b border-gray-100">
                  <span className="text-sm text-gray-500">{f.label}</span>
                  <span className="text-sm font-medium text-gray-900">{f.value}</span>
                </div>
              ))}
              <button
                onClick={() => { setEditProfile({ ...profile }); setEditMode(true) }}
                className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
              >
                Edit Profile
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                <input
                  type="text"
                  value={editProfile.fullName}
                  onChange={(e) => setEditProfile({ ...editProfile, fullName: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  value={editProfile.email}
                  disabled
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg bg-gray-50 text-gray-500"
                />
                <p className="text-xs text-gray-400 mt-1">Email cannot be changed</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input
                  type="tel"
                  value={editProfile.phone}
                  onChange={(e) => setEditProfile({ ...editProfile, phone: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder="+1-555-000-0000"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Timezone</label>
                <select
                  value={editProfile.timezone}
                  onChange={(e) => setEditProfile({ ...editProfile, timezone: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  {TIMEZONES.map((tz) => <option key={tz} value={tz}>{tz}</option>)}
                </select>
              </div>
              <div className="flex gap-2 pt-2">
                <button
                  onClick={handleSaveProfile}
                  disabled={profileLoading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 font-medium"
                >
                  {profileLoading ? 'Saving...' : 'Save Changes'}
                </button>
                <button
                  onClick={() => setEditMode(false)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Notifications Tab ── */}
      {activeTab === 'notifications' && (
        <div className="bg-white p-6 rounded-lg shadow max-w-xl">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold">Notification Preferences</h2>
            {notifSaved && <span className="text-green-600 text-sm font-medium">✓ Saved!</span>}
          </div>
          <div className="space-y-3">
            {[
              { key: 'dealAlerts', label: 'Deal Alerts', desc: 'When deals change stage or win probability' },
              { key: 'forecastUpdates', label: 'Forecast Updates', desc: 'When new forecasts are generated' },
              { key: 'insights', label: 'Insights', desc: 'New AI insights and recommendations' },
              { key: 'weeklyDigest', label: 'Weekly Digest', desc: 'Weekly summary email every Monday' },
              { key: 'systemAlerts', label: 'System Alerts', desc: 'Platform updates and maintenance notices' },
            ].map((pref) => (
              <label key={pref.key} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                <div>
                  <p className="font-medium text-gray-900">{pref.label}</p>
                  <p className="text-sm text-gray-500">{pref.desc}</p>
                </div>
                <div
                  onClick={() => setNotifPrefs((prev) => ({ ...prev, [pref.key]: !prev[pref.key as keyof typeof prev] }))}
                  className={`relative w-11 h-6 rounded-full transition-colors cursor-pointer ${
                    notifPrefs[pref.key as keyof typeof notifPrefs] ? 'bg-blue-600' : 'bg-gray-300'
                  }`}
                >
                  <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                    notifPrefs[pref.key as keyof typeof notifPrefs] ? 'translate-x-5' : 'translate-x-0'
                  }`} />
                </div>
              </label>
            ))}
          </div>
          <button
            onClick={handleSaveNotifs}
            className="mt-6 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
          >
            Save Preferences
          </button>
        </div>
      )}

      {/* ── Security Tab ── */}
      {activeTab === 'security' && (
        <div className="space-y-4 max-w-xl">
          {/* 2FA */}
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-gray-900">Two-Factor Authentication</h3>
                <p className="text-sm text-gray-500 mt-1">Add an extra layer of security to your account</p>
              </div>
              <button
                onClick={() => setTwoFAEnabled(!twoFAEnabled)}
                className={`px-4 py-2 rounded-lg font-medium text-sm ${
                  twoFAEnabled ? 'bg-red-100 text-red-700 hover:bg-red-200' : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
              >
                {twoFAEnabled ? 'Disable 2FA' : 'Enable 2FA'}
              </button>
            </div>
            {twoFAEnabled && (
              <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg text-sm text-green-700">
                ✓ Two-factor authentication is enabled on your account
              </div>
            )}
          </div>

          {/* Change Password */}
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold text-gray-900">Change Password</h3>
                <p className="text-sm text-gray-500 mt-1">Update your password regularly for security</p>
              </div>
              <button
                onClick={() => { setShowChangePwd(!showChangePwd); setPwdError(''); setPwdSuccess('') }}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 text-sm font-medium"
              >
                {showChangePwd ? 'Cancel' : 'Change Password'}
              </button>
            </div>

            {showChangePwd && (
              <div className="space-y-3 border-t border-gray-100 pt-4">
                {pwdError && <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm">{pwdError}</div>}
                {pwdSuccess && <div className="p-3 bg-green-50 border border-green-200 text-green-700 rounded-lg text-sm">✓ {pwdSuccess}</div>}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
                  <input
                    type="password"
                    value={pwdForm.current}
                    onChange={(e) => setPwdForm({ ...pwdForm, current: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="••••••••"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                  <input
                    type="password"
                    value={pwdForm.newPwd}
                    onChange={(e) => setPwdForm({ ...pwdForm, newPwd: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="••••••••"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
                  <input
                    type="password"
                    value={pwdForm.confirm}
                    onChange={(e) => setPwdForm({ ...pwdForm, confirm: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="••••••••"
                  />
                </div>
                <button
                  onClick={handleChangePwd}
                  disabled={pwdLoading}
                  className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 font-medium"
                >
                  {pwdLoading ? 'Updating...' : 'Update Password'}
                </button>
              </div>
            )}
          </div>

          {/* Active Sessions */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="font-semibold text-gray-900 mb-4">Active Sessions</h3>
            <div className="space-y-3">
              {[
                { device: 'Chrome on Windows', location: 'New York, US', time: 'Now (current)', current: true },
                { device: 'Safari on iPhone', location: 'New York, US', time: '2 hours ago', current: false },
              ].map((session, i) => (
                <div key={i} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{session.device}</p>
                    <p className="text-xs text-gray-500">{session.location} · {session.time}</p>
                  </div>
                  {session.current ? (
                    <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Current</span>
                  ) : (
                    <button className="text-xs text-red-600 hover:text-red-800 font-medium">Revoke</button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── Integrations Tab ── */}
      {activeTab === 'integrations' && (
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold">Connected Integrations</h2>
            {integMsg && <span className="text-blue-600 text-sm font-medium">✓ {integMsg}</span>}
          </div>
          <div className="grid grid-cols-2 gap-4">
            {integrations.map((integ) => (
              <div key={integ.name} className="p-4 border border-gray-200 rounded-lg hover:shadow-sm transition-shadow">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-2xl">{integ.icon}</span>
                  {integ.connected && (
                    <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded font-medium">Connected</span>
                  )}
                </div>
                <p className="font-medium text-gray-900 mb-1">{integ.name}</p>
                <p className="text-xs text-gray-500 mb-3">
                  {integ.connected ? 'Syncing data automatically' : 'Not connected'}
                </p>
                <button
                  onClick={() => handleToggleIntegration(integ.name)}
                  className={`w-full px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    integ.connected
                      ? 'border border-gray-300 text-gray-700 hover:bg-red-50 hover:border-red-300 hover:text-red-700'
                      : 'bg-blue-600 text-white hover:bg-blue-700'
                  }`}
                >
                  {integ.connected ? 'Disconnect' : 'Connect'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
