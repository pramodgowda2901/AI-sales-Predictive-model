import { useState } from 'react'
import { apiClient } from '../services/api'
import BackButton from '../components/BackButton'

const CATEGORIES = [
  { key: 'dealAlerts', label: 'Deal Alerts', desc: 'Win probability changes, stage transitions, overdue deals', icon: '📊' },
  { key: 'forecastUpdates', label: 'Forecast Updates', desc: 'New forecasts generated, recalibration events', icon: '📈' },
  { key: 'insightDigest', label: 'Insight Digest', desc: 'Weekly summary of AI-generated insights and recommendations', icon: '💡' },
  { key: 'billingNotices', label: 'Billing Notices', desc: 'Payment confirmations, invoices, usage limit warnings', icon: '💳' },
  { key: 'securityAlerts', label: 'Security Alerts', desc: 'Login from new device, password changes, session revocations', icon: '🔒' },
  { key: 'productAnnouncements', label: 'Product Announcements', desc: 'New features, platform updates, maintenance windows', icon: '📣' },
]

export default function EmailPreferencesPage() {
  const [prefs, setPrefs] = useState<Record<string, boolean>>({
    dealAlerts: true,
    forecastUpdates: true,
    insightDigest: true,
    billingNotices: true,
    securityAlerts: true,
    productAnnouncements: false,
  })
  const [saved, setSaved] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleToggle = (key: string) => {
    setPrefs((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  const handleSave = async () => {
    setLoading(true)
    try {
      await apiClient.updateProfile({ emailPreferences: prefs })
    } catch {}
    setSaved(true)
    setLoading(false)
    setTimeout(() => setSaved(false), 2500)
  }

  const handleUnsubscribeAll = () => {
    const allOff = Object.fromEntries(CATEGORIES.map((c) => [c.key, false]))
    setPrefs(allOff)
  }

  return (
    <div className="max-w-2xl">
      <BackButton />
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold">Email Preferences</h1>
          <p className="text-gray-600 mt-1">Control which emails you receive from the platform</p>
        </div>
        {saved && <span className="text-green-600 font-medium">✓ Preferences saved!</span>}
      </div>

      <div className="bg-white rounded-xl shadow divide-y divide-gray-100">
        {CATEGORIES.map((cat) => (
          <div key={cat.key} className="flex items-center justify-between px-6 py-4 hover:bg-gray-50">
            <div className="flex items-start gap-3">
              <span className="text-2xl mt-0.5">{cat.icon}</span>
              <div>
                <p className="font-medium text-gray-900">{cat.label}</p>
                <p className="text-sm text-gray-500">{cat.desc}</p>
              </div>
            </div>
            <button
              onClick={() => handleToggle(cat.key)}
              className={`relative w-12 h-6 rounded-full transition-colors flex-shrink-0 ml-4 ${
                prefs[cat.key] ? 'bg-blue-600' : 'bg-gray-300'
              }`}
            >
              <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                prefs[cat.key] ? 'translate-x-6' : 'translate-x-0'
              }`} />
            </button>
          </div>
        ))}
      </div>

      <div className="flex items-center justify-between mt-6">
        <button
          onClick={handleUnsubscribeAll}
          className="text-sm text-red-600 hover:text-red-700 font-medium"
        >
          Unsubscribe from all emails
        </button>
        <button
          onClick={handleSave}
          disabled={loading}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 font-medium"
        >
          {loading ? 'Saving...' : 'Save Preferences'}
        </button>
      </div>

      <div className="mt-8 p-4 bg-gray-50 rounded-lg border border-gray-200">
        <p className="text-sm text-gray-600">
          <strong>Note:</strong> Security alerts cannot be fully disabled as they are required for account safety. 
          You can unsubscribe from individual email categories using the unsubscribe link in any email footer.
        </p>
      </div>
    </div>
  )
}
