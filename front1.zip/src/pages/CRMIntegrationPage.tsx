import { useState } from 'react'
import BackButton from '../components/BackButton'

interface CRMConfig {
  name: string
  icon: string
  color: string
  fields: { label: string; key: string; type: string; placeholder: string }[]
}

const CRM_CONFIGS: CRMConfig[] = [
  {
    name: 'Salesforce',
    icon: '☁️',
    color: 'blue',
    fields: [
      { label: 'Instance URL', key: 'instanceUrl', type: 'url', placeholder: 'https://yourorg.salesforce.com' },
      { label: 'Client ID', key: 'clientId', type: 'text', placeholder: 'Connected App Client ID' },
      { label: 'Client Secret', key: 'clientSecret', type: 'password', placeholder: '••••••••' },
    ],
  },
  {
    name: 'HubSpot',
    icon: '🔗',
    color: 'orange',
    fields: [
      { label: 'API Key', key: 'apiKey', type: 'password', placeholder: 'pat-na1-...' },
      { label: 'Portal ID', key: 'portalId', type: 'text', placeholder: '12345678' },
    ],
  },
  {
    name: 'Microsoft Dynamics',
    icon: '📊',
    color: 'purple',
    fields: [
      { label: 'Tenant ID', key: 'tenantId', type: 'text', placeholder: 'Azure AD Tenant ID' },
      { label: 'Client ID', key: 'clientId', type: 'text', placeholder: 'App Registration Client ID' },
      { label: 'Client Secret', key: 'clientSecret', type: 'password', placeholder: '••••••••' },
      { label: 'Resource URL', key: 'resourceUrl', type: 'url', placeholder: 'https://yourorg.crm.dynamics.com' },
    ],
  },
]

interface SyncStatus {
  connected: boolean
  lastSync?: string
  recordsSynced?: number
  status: 'idle' | 'syncing' | 'error' | 'success'
  error?: string
}

export default function CRMIntegrationPage() {
  const [activeCRM, setActiveCRM] = useState<string | null>(null)
  const [formValues, setFormValues] = useState<Record<string, Record<string, string>>>({})
  const [syncStatus, setSyncStatus] = useState<Record<string, SyncStatus>>({
    Salesforce: { connected: true, lastSync: '2 minutes ago', recordsSynced: 1247, status: 'idle' },
    HubSpot: { connected: false, status: 'idle' },
    'Microsoft Dynamics': { connected: false, status: 'idle' },
  })
  const [connecting, setConnecting] = useState<string | null>(null)
  const [msg, setMsg] = useState('')

  const handleConnect = async (crmName: string) => {
    setConnecting(crmName)
    await new Promise((r) => setTimeout(r, 1500))
    setSyncStatus((prev) => ({
      ...prev,
      [crmName]: { connected: true, lastSync: 'Just now', recordsSynced: 0, status: 'success' },
    }))
    setConnecting(null)
    setActiveCRM(null)
    setMsg(`${crmName} connected successfully!`)
    setTimeout(() => setMsg(''), 3000)
  }

  const handleDisconnect = (crmName: string) => {
    if (!confirm(`Disconnect ${crmName}? Sync will stop immediately.`)) return
    setSyncStatus((prev) => ({ ...prev, [crmName]: { connected: false, status: 'idle' } }))
    setMsg(`${crmName} disconnected`)
    setTimeout(() => setMsg(''), 2000)
  }

  const handleSync = async (crmName: string) => {
    setSyncStatus((prev) => ({ ...prev, [crmName]: { ...prev[crmName], status: 'syncing' } }))
    await new Promise((r) => setTimeout(r, 2000))
    const count = Math.floor(Math.random() * 200) + 50
    setSyncStatus((prev) => ({
      ...prev,
      [crmName]: { ...prev[crmName], status: 'success', lastSync: 'Just now', recordsSynced: (prev[crmName].recordsSynced || 0) + count },
    }))
    setMsg(`Synced ${count} records from ${crmName}`)
    setTimeout(() => setMsg(''), 3000)
  }

  const statusBadge = (s: SyncStatus) => {
    if (s.status === 'syncing') return <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium animate-pulse">⟳ Syncing…</span>
    if (!s.connected) return <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs font-medium">Not connected</span>
    return <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">✓ Connected</span>
  }

  return (
    <div className="max-w-3xl">
      <BackButton />
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold dark:text-slate-100">CRM Integrations</h1>
          <p className="text-gray-600 dark:text-slate-400 mt-1">Connect your CRM to sync deals and signals automatically</p>
        </div>
        {msg && <span className="text-green-600 font-medium text-sm">✓ {msg}</span>}
      </div>

      <div className="space-y-4">
        {CRM_CONFIGS.map((crm) => {
          const status = syncStatus[crm.name]
          const isExpanded = activeCRM === crm.name

          return (
            <div key={crm.name} className="bg-white dark:bg-slate-800 rounded-xl shadow overflow-hidden">
              {/* Header */}
              <div className="flex items-center justify-between p-6">
                <div className="flex items-center gap-4">
                  <span className="text-3xl">{crm.icon}</span>
                  <div>
                    <h3 className="font-bold text-gray-900 dark:text-slate-100">{crm.name}</h3>
                    <div className="flex items-center gap-3 mt-1">
                      {statusBadge(status)}
                      {status.connected && status.lastSync && (
                        <span className="text-xs text-gray-500 dark:text-slate-400">Last sync: {status.lastSync}</span>
                      )}
                      {status.connected && status.recordsSynced !== undefined && (
                        <span className="text-xs text-gray-500 dark:text-slate-400">{status.recordsSynced.toLocaleString()} records</span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  {status.connected ? (
                    <>
                      <button
                        onClick={() => handleSync(crm.name)}
                        disabled={status.status === 'syncing'}
                        className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 disabled:bg-gray-400"
                      >
                        {status.status === 'syncing' ? 'Syncing…' : '⟳ Sync Now'}
                      </button>
                      <button
                        onClick={() => handleDisconnect(crm.name)}
                        className="px-3 py-1.5 border border-gray-300 text-gray-700 rounded-lg text-sm font-medium hover:bg-red-50 hover:border-red-300 hover:text-red-700"
                      >
                        Disconnect
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => setActiveCRM(isExpanded ? null : crm.name)}
                      className="px-4 py-1.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700"
                    >
                      {isExpanded ? 'Cancel' : 'Connect'}
                    </button>
                  )}
                </div>
              </div>

              {/* Connection Form */}
              {isExpanded && !status.connected && (
                <div className="px-6 pb-6 border-t border-gray-100 dark:border-slate-700 pt-4">
                  <div className="space-y-3">
                    {crm.fields.map((field) => (
                      <div key={field.key}>
                        <label className="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1">{field.label}</label>
                        <input
                          type={field.type}
                          value={formValues[crm.name]?.[field.key] || ''}
                          onChange={(e) => setFormValues((prev) => ({
                            ...prev,
                            [crm.name]: { ...prev[crm.name], [field.key]: e.target.value },
                          }))}
                          placeholder={field.placeholder}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100"
                        />
                      </div>
                    ))}
                    <div className="flex gap-2 pt-2">
                      <button
                        onClick={() => handleConnect(crm.name)}
                        disabled={connecting === crm.name}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 font-medium text-sm"
                      >
                        {connecting === crm.name ? 'Connecting…' : `Connect ${crm.name}`}
                      </button>
                      <button onClick={() => setActiveCRM(null)} className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium text-sm">
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Sync Details */}
              {status.connected && (
                <div className="px-6 pb-4 border-t border-gray-100 dark:border-slate-700 pt-3">
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    {[
                      { label: 'Deals synced', value: Math.floor((status.recordsSynced || 0) * 0.4) },
                      { label: 'Contacts synced', value: Math.floor((status.recordsSynced || 0) * 0.35) },
                      { label: 'Activities synced', value: Math.floor((status.recordsSynced || 0) * 0.25) },
                    ].map((item) => (
                      <div key={item.label} className="text-center p-2 bg-gray-50 dark:bg-slate-700 rounded-lg">
                        <p className="text-lg font-bold text-gray-900 dark:text-slate-100">{item.value.toLocaleString()}</p>
                        <p className="text-xs text-gray-500 dark:text-slate-400">{item.label}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>

      {/* Sync Settings */}
      <div className="mt-6 bg-white dark:bg-slate-800 rounded-xl shadow p-6">
        <h3 className="font-bold text-gray-900 dark:text-slate-100 mb-4">Sync Settings</h3>
        <div className="space-y-3">
          {[
            { label: 'Sync interval', value: 'Every 15 minutes' },
            { label: 'Bidirectional sync', value: 'Enabled' },
            { label: 'Conflict resolution', value: 'CRM wins' },
            { label: 'Field mapping', value: 'Auto-detected' },
          ].map((s) => (
            <div key={s.label} className="flex items-center justify-between py-2 border-b border-gray-100 dark:border-slate-700 last:border-0">
              <span className="text-sm text-gray-700 dark:text-slate-300">{s.label}</span>
              <span className="text-sm font-medium text-gray-900 dark:text-slate-100">{s.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
