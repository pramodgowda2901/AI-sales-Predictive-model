import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { apiClient } from '../services/api'

export default function SignupPage() {
  const navigate = useNavigate()
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    company: '',
    password: '',
    confirmPassword: '',
  })
  const [passwordValidation, setPasswordValidation] = useState<any>(null)
  const [errors, setErrors] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Real-time password validation
    if (name === 'password' && value) {
      apiClient.validatePassword(value).then((result) => {
        setPasswordValidation(result)
      })
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setErrors([])

    // Validation
    if (!formData.fullName || !formData.email || !formData.password) {
      setErrors(['All fields are required'])
      return
    }

    if (formData.password !== formData.confirmPassword) {
      setErrors(['Passwords do not match'])
      return
    }

    if (passwordValidation && !passwordValidation.valid) {
      setErrors(passwordValidation.errors)
      return
    }

    setLoading(true)

    try {
      const result = await apiClient.signup(
        formData.email,
        formData.password,
        formData.fullName,
        formData.company
      )

      if (result.success) {
        setSuccess(true)
        setTimeout(() => {
          navigate('/pipeline')
        }, 2000)
      } else {
        setErrors([result.message])
      }
    } catch (error: any) {
      setErrors([error.response?.data?.message || 'Signup failed. Please try again.'])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-blue-500 to-purple-600 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Decorative elements */}
        <div className="absolute top-10 left-10 w-20 h-20 bg-white opacity-10 rounded-full blur-xl"></div>
        <div className="absolute bottom-20 right-10 w-32 h-32 bg-white opacity-10 rounded-full blur-xl"></div>

        {/* Card */}
        <div className="relative bg-white rounded-2xl shadow-2xl p-8 backdrop-blur-sm">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Create Account</h1>
            <p className="text-gray-600">Join AI Sales Predictive Management</p>
          </div>

          {success && (
            <div className="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
              Account created successfully! Redirecting...
            </div>
          )}

          {errors.length > 0 && (
            <div className="mb-6 p-4 bg-red-100 border border-red-400 rounded-lg">
              {errors.map((error, idx) => (
                <p key={idx} className="text-red-700 text-sm">
                  • {error}
                </p>
              ))}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
              <input
                type="text"
                name="fullName"
                value={formData.fullName}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                placeholder="John Doe"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                placeholder="you@example.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Company (Optional)</label>
              <input
                type="text"
                name="company"
                value={formData.company}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                placeholder="Your Company"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                placeholder="••••••••"
              />
              {passwordValidation && (
                <div className="mt-2 text-sm">
                  {passwordValidation.valid ? (
                    <p className="text-green-600">✓ Password is strong</p>
                  ) : (
                    <div className="text-red-600">
                      {passwordValidation.errors.map((err: string, idx: number) => (
                        <p key={idx}>• {err}</p>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Confirm Password</label>
              <input
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                placeholder="••••••••"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-6 px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 disabled:from-gray-400 disabled:to-gray-400 font-semibold transition-all transform hover:scale-105 disabled:scale-100"
            >
              {loading ? 'Creating Account...' : 'Create Account'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600">
              Already have an account?{' '}
              <Link to="/login" className="text-blue-600 hover:text-blue-700 font-semibold">
                Sign In
              </Link>
            </p>
          </div>

          {/* Features */}
          <div className="mt-8 pt-6 border-t border-gray-200">
            <p className="text-xs text-gray-600 text-center mb-4">What you get:</p>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div>
                <p className="text-lg font-bold text-blue-600">25+</p>
                <p className="text-xs text-gray-600">Deals</p>
              </div>
              <div>
                <p className="text-lg font-bold text-blue-600">AI</p>
                <p className="text-xs text-gray-600">Predictions</p>
              </div>
              <div>
                <p className="text-lg font-bold text-blue-600">Real</p>
                <p className="text-xs text-gray-600">Analytics</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
