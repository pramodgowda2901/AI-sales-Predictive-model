import { useEffect, useRef } from 'react'
import { useQueryClient } from 'react-query'
import { useUIStore } from '../store/uiStore'

/**
 * Real-time updates via polling.
 * Refreshes deals, pipeline, insights, notifications every N seconds.
 * Also simulates win probability changes to show live updates.
 */
export function useRealTimeUpdates(intervalMs = 15000) {
  const queryClient = useQueryClient()
  const { setWsStatus } = useUIStore()
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    setWsStatus('connected')

    timerRef.current = setInterval(() => {
      // Refresh all live data queries
      queryClient.invalidateQueries('deals')
      queryClient.invalidateQueries('pipeline')
      queryClient.invalidateQueries('insights')
      queryClient.invalidateQueries('notifications')
      queryClient.invalidateQueries('forecasts')
    }, intervalMs)

    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [queryClient, intervalMs, setWsStatus])
}

/**
 * Simulates a live activity feed of events happening in the system.
 * In production this would come from a WebSocket connection.
 */
export function useLiveActivityFeed(onEvent: (event: LiveEvent) => void) {
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    const EVENTS: LiveEvent[] = [
      { type: 'prediction', icon: '🤖', message: 'AI updated win probability for "Acme Corp Deal" → 78%', time: 'just now' },
      { type: 'deal', icon: '💼', message: 'New deal created: "TechVision Integration" — $120K', time: 'just now' },
      { type: 'insight', icon: '💡', message: 'Stalled deal alert: "Global Solutions" — no activity for 14 days', time: 'just now' },
      { type: 'forecast', icon: '📈', message: 'Monthly forecast updated: $2.8M projected (+12%)', time: 'just now' },
      { type: 'signal', icon: '📧', message: 'Email opened: "CloudFirst Systems" — proposal viewed', time: 'just now' },
      { type: 'prediction', icon: '🤖', message: 'Win probability dropped: "DataFlow Analytics" 65% → 48%', time: 'just now' },
      { type: 'deal', icon: '💼', message: 'Deal stage changed: "NextGen Software" moved to Negotiation', time: 'just now' },
      { type: 'insight', icon: '💡', message: 'High win probability: "Innovation Labs" at 89% — act now', time: 'just now' },
    ]

    let idx = 0
    timerRef.current = setInterval(() => {
      onEvent({ ...EVENTS[idx % EVENTS.length], time: 'just now' })
      idx++
    }, 8000)

    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [onEvent])
}

export interface LiveEvent {
  type: 'prediction' | 'deal' | 'insight' | 'forecast' | 'signal'
  icon: string
  message: string
  time: string
}
