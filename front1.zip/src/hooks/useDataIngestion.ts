import { useEffect, useRef, useCallback } from 'react'
import { useQueryClient } from 'react-query'
import { useUIStore } from '../store/uiStore'

export interface IngestionEvent {
  id: string
  timestamp: string
  source: 'CRM' | 'Email' | 'Calendar' | 'Web' | 'Signal' | 'AI'
  type: string
  entity: string
  detail: string
  impact: 'high' | 'medium' | 'low'
}

// Simulated incoming signals from CRM, email, calendar, web
const SIGNAL_POOL: Omit<IngestionEvent, 'id' | 'timestamp'>[] = [
  { source: 'CRM', type: 'Deal Stage Changed', entity: 'Acme Corp', detail: 'Moved from Qualification → Proposal', impact: 'high' },
  { source: 'Email', type: 'Email Opened', entity: 'TechVision Inc', detail: 'Proposal email opened 3 times in last hour', impact: 'high' },
  { source: 'CRM', type: 'New Deal Created', entity: 'CloudFirst Systems', detail: 'New $85K deal added by John Doe', impact: 'medium' },
  { source: 'Calendar', type: 'Meeting Scheduled', entity: 'DataFlow Analytics', detail: 'Demo call booked for tomorrow 2pm', impact: 'high' },
  { source: 'Web', type: 'Pricing Page Visit', entity: 'NextGen Software', detail: 'Visited pricing page 4 times today', impact: 'medium' },
  { source: 'AI', type: 'Win Probability Updated', entity: 'Innovation Labs', detail: 'Score updated 45% → 72% after engagement spike', impact: 'high' },
  { source: 'Email', type: 'Reply Received', entity: 'Enterprise Plus', detail: 'Contact replied to follow-up email', impact: 'medium' },
  { source: 'Signal', type: 'Document Downloaded', entity: 'Future Tech', detail: 'Case study PDF downloaded from proposal link', impact: 'medium' },
  { source: 'CRM', type: 'Contact Updated', entity: 'Smart Systems', detail: 'Decision maker contact info updated in Salesforce', impact: 'low' },
  { source: 'AI', type: 'Stalled Deal Alert', entity: 'Quantum Computing', detail: 'No activity for 14 days — AI flagged as stalled', impact: 'high' },
  { source: 'Web', type: 'Demo Request', entity: 'AI Solutions Co', detail: 'Free consultation form submitted on website', impact: 'high' },
  { source: 'Calendar', type: 'Meeting Completed', entity: 'Cloud Native Ltd', detail: 'Discovery call completed — notes synced to CRM', impact: 'medium' },
  { source: 'Email', type: 'Link Clicked', entity: 'DevOps Pro', detail: 'ROI calculator link clicked in outreach email', impact: 'medium' },
  { source: 'Signal', type: 'Contract Viewed', entity: 'Security First', detail: 'Contract document opened via DocuSign', impact: 'high' },
  { source: 'AI', type: 'Forecast Recalibrated', entity: 'All Deals', detail: 'Monthly forecast updated to $2.8M (+12% vs last week)', impact: 'high' },
]

let eventCounter = 0

function makeEvent(template: Omit<IngestionEvent, 'id' | 'timestamp'>): IngestionEvent {
  eventCounter++
  return {
    ...template,
    id: `evt-${Date.now()}-${eventCounter}`,
    timestamp: new Date().toISOString(),
  }
}

// Global ingestion log (shared across components)
export const ingestionLog: IngestionEvent[] = []
export const ingestionListeners: Set<() => void> = new Set()

function notifyListeners() {
  ingestionListeners.forEach((fn) => fn())
}

export function startIngestion() {
  // Fire first event immediately
  const first = makeEvent(SIGNAL_POOL[Math.floor(Math.random() * SIGNAL_POOL.length)])
  ingestionLog.unshift(first)
  notifyListeners()

  // Then fire every 6–12 seconds
  const interval = setInterval(() => {
    const template = SIGNAL_POOL[Math.floor(Math.random() * SIGNAL_POOL.length)]
    const event = makeEvent(template)
    ingestionLog.unshift(event)
    if (ingestionLog.length > 50) ingestionLog.pop() // keep last 50
    notifyListeners()
  }, 6000 + Math.random() * 6000)

  return () => clearInterval(interval)
}

export function useDataIngestion() {
  const queryClient = useQueryClient()
  const { setWsStatus } = useUIStore()
  const stopRef = useRef<(() => void) | null>(null)

  useEffect(() => {
    setWsStatus('connected')
    stopRef.current = startIngestion()

    // Every ingestion event also refreshes relevant queries
    const refresh = () => {
      const latest = ingestionLog[0]
      if (!latest) return
      if (latest.source === 'CRM' || latest.type.includes('Deal')) {
        queryClient.invalidateQueries('deals')
        queryClient.invalidateQueries('pipeline')
      }
      if (latest.source === 'AI' || latest.type.includes('Probability')) {
        queryClient.invalidateQueries('deals')
        queryClient.invalidateQueries('insights')
      }
      if (latest.type.includes('Forecast')) {
        queryClient.invalidateQueries('forecasts')
      }
      queryClient.invalidateQueries('notifications')
    }

    ingestionListeners.add(refresh)
    return () => {
      ingestionListeners.delete(refresh)
      stopRef.current?.()
    }
  }, [queryClient, setWsStatus])
}
