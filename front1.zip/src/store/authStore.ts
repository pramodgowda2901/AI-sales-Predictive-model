import { create } from 'zustand'

interface AuthState {
  isAuthenticated: boolean
  user: any | null
  token: string | null
  login: (email: string, password: string) => Promise<void>
  logout: () => void
  setUser: (user: any) => void
}

export const useAuthStore = create<AuthState>((set) => ({
  isAuthenticated: !!localStorage.getItem('token'),
  user: null,
  token: localStorage.getItem('token'),
  login: async (_email: string, _password: string) => {
    // Simplified login - in production, use Cognito
    const token = 'mock-token-' + Date.now()
    localStorage.setItem('token', token)
    set({ isAuthenticated: true, token })
  },
  logout: () => {
    localStorage.removeItem('token')
    set({ isAuthenticated: false, user: null, token: null })
  },
  setUser: (user: any) => {
    set({ user })
  },
}))
