import { create } from 'zustand'

export interface CompanyData {
  name: string
  tagline: string
  industry: string
  location: string
  type: string
  founded: string
  employees: string
  website: string
  phone: string
  email: string
  description: string
  services: string[]
  clients: { name: string; role: string; feedback: string; website?: string }[]
  dealValue: number
  dealStage: string
  winProbability: number
  closeDate: string
  signals: { type: string; source: string; date: string }[]
  insights: { type: string; text: string; impact: number }[]
}

// Pre-built profiles for known companies
const COMPANY_PROFILES: Record<string, CompanyData> = {
  'digital solution ai': {
    name: 'Digital Solution AI Private Limited',
    tagline: 'A Leading Digital Marketing Agency',
    industry: 'Digital Marketing Agency',
    location: 'Bengaluru, Karnataka, India',
    type: 'Private Limited Company',
    founded: '2020',
    employees: '11–50',
    website: 'https://digitalsolutionai.com',
    phone: '+92 300 748 4232',
    email: 'info@digitalsolutionai.com',
    description: 'Digital Solution AI is a leading digital marketing agency that helps businesses achieve digital success through expert website design, SEO, social media marketing, and AI-powered digital strategies. They serve international clients across India, Dubai, and Pakistan, helping brands increase online visibility, attract more customers, and grow their business.',
    services: ['Website Design & Development', 'Search Engine Optimisation (SEO)', 'Social Media Marketing', 'Digital Marketing Strategy', 'AI-Powered Marketing Solutions', 'Brand Identity & Online Presence', 'E-Commerce Solutions', 'Online Business Consultation'],
    clients: [
      { name: 'SKZ Travels & Tours', website: 'www.skztravel.com', role: 'Co-founder', feedback: 'Working with Digital Solution AI has been a fantastic experience! They designed a stunning, user-friendly website which has elevated our brand image and significantly increased our online visibility.' },
      { name: 'GoldTech Technical Services LLC Dubai', website: 'www.goldtechservice.com', role: 'CEO — Mr. Tahir Bashir', feedback: 'Their SEO and digital marketing strategies have significantly boosted our online presence. Highly professional, results-driven.' },
      { name: 'Quickon.pk E-Commerce', website: 'quickon.pk', role: 'CEO — Mr. Irfan Kharal', feedback: 'Their SEO and digital marketing strategies have significantly increased our traffic and sales. Brand engagement has skyrocketed.' },
      { name: 'Green Leaf E-commerce', role: 'Founder — James R.', feedback: 'A professional and dedicated team that delivers real results. Massive increase in organic traffic and social media engagement.' },
    ],
    dealValue: 299, dealStage: 'Proposal', winProbability: 72, closeDate: '2024-06-30',
    signals: [
      { type: 'Website Visit', source: 'digitalsolutionai.com', date: '2024-04-18' },
      { type: 'Pricing Page View', source: 'Web Analytics', date: '2024-04-19' },
      { type: 'Free Consultation Requested', source: 'Contact Form', date: '2024-04-20' },
      { type: 'WhatsApp Message Sent', source: '+92 300 748 4232', date: '2024-04-21' },
    ],
    insights: [
      { type: 'High Win Probability', text: 'DS AI serves international clients and actively seeks tools to scale. Viewed pricing page 3 times — strong buying intent for Growth plan.', impact: 89000 },
      { type: 'Next Best Action', text: 'Send a personalised case study showing how SalesPred AI helps digital agencies track client pipelines. Reach via WhatsApp at +92 300 748 4232.', impact: 65000 },
      { type: 'Engagement Spike', text: 'DS AI submitted a free consultation request. Follow up within 24 hours to maximise conversion probability.', impact: 45000 },
    ],
  },
  'salesforce': {
    name: 'Salesforce Inc.',
    tagline: 'The World\'s #1 CRM Platform',
    industry: 'Enterprise Software / CRM',
    location: 'San Francisco, California, USA',
    type: 'Public Company (NYSE: CRM)',
    founded: '1999',
    employees: '70,000+',
    website: 'https://salesforce.com',
    phone: '+1 800 667 6389',
    email: 'sales@salesforce.com',
    description: 'Salesforce is the world\'s leading CRM platform, helping companies of every size and industry connect with their customers. With headquarters in San Francisco, Salesforce offers cloud-based applications for sales, service, marketing, and more.',
    services: ['Sales Cloud', 'Service Cloud', 'Marketing Cloud', 'Commerce Cloud', 'Analytics Cloud', 'AppExchange', 'Slack Integration', 'Einstein AI'],
    clients: [
      { name: 'Toyota', role: 'Global Automotive', feedback: 'Salesforce helped us unify our customer data across 50+ markets.' },
      { name: 'Amazon Web Services', role: 'Cloud Partner', feedback: 'Deep integration with AWS has accelerated our digital transformation.' },
      { name: 'Spotify', role: 'Technology', feedback: 'Salesforce powers our B2B sales operations globally.' },
    ],
    dealValue: 999, dealStage: 'Negotiation', winProbability: 45, closeDate: '2024-07-31',
    signals: [
      { type: 'Enterprise Demo Attended', source: 'Zoom', date: '2024-04-15' },
      { type: 'RFP Submitted', source: 'Email', date: '2024-04-18' },
      { type: 'Legal Review Started', source: 'DocuSign', date: '2024-04-20' },
    ],
    insights: [
      { type: 'Timeline Risk', text: 'Salesforce procurement cycles average 90 days. Current deal is at day 45 — push for a decision before quarter end.', impact: 250000 },
      { type: 'Next Best Action', text: 'Engage the VP of Sales directly. Current contact is mid-level — escalate to decision maker.', impact: 180000 },
    ],
  },
  'hubspot': {
    name: 'HubSpot Inc.',
    tagline: 'Grow Better with HubSpot',
    industry: 'Marketing & Sales Software',
    location: 'Cambridge, Massachusetts, USA',
    type: 'Public Company (NYSE: HUBS)',
    founded: '2006',
    employees: '7,000+',
    website: 'https://hubspot.com',
    phone: '+1 888 482 7768',
    email: 'sales@hubspot.com',
    description: 'HubSpot is a leading CRM platform that provides software and support to help businesses grow better. HubSpot\'s platform includes marketing, sales, service, and website management products that start free and scale to meet customers\' needs at any stage of growth.',
    services: ['Marketing Hub', 'Sales Hub', 'Service Hub', 'CMS Hub', 'Operations Hub', 'CRM Free', 'HubSpot Academy', 'App Marketplace'],
    clients: [
      { name: 'Trello', role: 'SaaS', feedback: 'HubSpot helped us scale our inbound marketing 10x.' },
      { name: 'SurveyMonkey', role: 'Technology', feedback: 'Our sales team productivity doubled after switching to HubSpot.' },
    ],
    dealValue: 299, dealStage: 'Qualification', winProbability: 58, closeDate: '2024-06-15',
    signals: [
      { type: 'Free Trial Started', source: 'hubspot.com', date: '2024-04-10' },
      { type: 'Integration Demo Viewed', source: 'YouTube', date: '2024-04-14' },
      { type: 'Sales Rep Contacted', source: 'Email', date: '2024-04-17' },
    ],
    insights: [
      { type: 'Engagement Spike', text: 'HubSpot contact viewed the CRM integration page 5 times this week. High interest in connecting SalesPred AI with HubSpot.', impact: 72000 },
      { type: 'Next Best Action', text: 'Offer a live integration demo showing HubSpot ↔ SalesPred AI bidirectional sync. This is their primary evaluation criterion.', impact: 55000 },
    ],
  },
  'zoho': {
    name: 'Zoho Corporation Pvt. Ltd.',
    tagline: 'One Operating System for Your Entire Business',
    industry: 'Business Software / SaaS',
    location: 'Chennai, Tamil Nadu, India',
    type: 'Private Company',
    founded: '1996',
    employees: '15,000+',
    website: 'https://zoho.com',
    phone: '+91 44 6965 5000',
    email: 'sales@zoho.com',
    description: 'Zoho Corporation is an Indian multinational technology company that makes web-based business tools. It is best known for the online office suite Zoho Office Suite. The company was founded in 1996 and is headquartered in Chennai, India with offices worldwide.',
    services: ['Zoho CRM', 'Zoho Books', 'Zoho Projects', 'Zoho Desk', 'Zoho Analytics', 'Zoho Mail', 'Zoho Creator', 'Zoho One'],
    clients: [
      { name: 'Amazon India', role: 'E-Commerce', feedback: 'Zoho CRM helped us manage thousands of vendor relationships.' },
      { name: 'Hyundai India', role: 'Automotive', feedback: 'Zoho\'s suite replaced 5 different tools for us.' },
    ],
    dealValue: 299, dealStage: 'Prospecting', winProbability: 35, closeDate: '2024-08-31',
    signals: [
      { type: 'LinkedIn Ad Clicked', source: 'LinkedIn', date: '2024-04-12' },
      { type: 'Blog Post Read', source: 'salespred.ai/blog', date: '2024-04-16' },
    ],
    insights: [
      { type: 'Stalled Deal', text: 'No engagement from Zoho contact in 12 days. Send a re-engagement email with a free trial offer.', impact: 42000 },
      { type: 'Next Best Action', text: 'Zoho already has CRM — position SalesPred AI as an AI layer on top of their existing tools, not a replacement.', impact: 38000 },
    ],
  },
  'infosys': {
    name: 'Infosys Limited',
    tagline: 'Navigate Your Next',
    industry: 'IT Services & Consulting',
    location: 'Bengaluru, Karnataka, India',
    type: 'Public Company (NSE: INFY)',
    founded: '1981',
    employees: '300,000+',
    website: 'https://infosys.com',
    phone: '+91 80 2852 0261',
    email: 'askus@infosys.com',
    description: 'Infosys is a global leader in next-generation digital services and consulting. They enable clients in more than 50 countries to navigate their digital transformation. With over four decades of experience in managing the systems and workings of global enterprises.',
    services: ['Digital Transformation', 'Cloud Services', 'AI & Automation', 'Data Analytics', 'Cybersecurity', 'Enterprise Applications', 'Engineering Services', 'BPM'],
    clients: [
      { name: 'Goldman Sachs', role: 'Financial Services', feedback: 'Infosys transformed our core banking infrastructure.' },
      { name: 'Daimler AG', role: 'Automotive', feedback: 'Digital transformation partner for our global operations.' },
    ],
    dealValue: 999, dealStage: 'Qualification', winProbability: 52, closeDate: '2024-09-30',
    signals: [
      { type: 'RFI Submitted', source: 'Procurement Portal', date: '2024-04-08' },
      { type: 'Technical Evaluation Started', source: 'Internal', date: '2024-04-15' },
      { type: 'Reference Check Requested', source: 'Email', date: '2024-04-19' },
    ],
    insights: [
      { type: 'High Win Probability', text: 'Infosys is evaluating AI sales tools for their 300K+ employee sales org. Enterprise deal with massive expansion potential.', impact: 450000 },
      { type: 'Next Best Action', text: 'Provide a proof-of-concept deployment for one business unit. Infosys evaluates all enterprise tools with a pilot first.', impact: 320000 },
    ],
  },
}

// Generate a profile for any unknown company
function generateProfile(name: string): CompanyData {
  const initials = name.slice(0, 2).toUpperCase()
  return {
    name: name,
    tagline: `Leading solutions provider`,
    industry: 'Technology / Business Services',
    location: 'India',
    type: 'Private Limited Company',
    founded: '2018',
    employees: '11–50',
    website: `https://${name.toLowerCase().replace(/\s+/g, '')}.com`,
    phone: '+91 98765 43210',
    email: `info@${name.toLowerCase().replace(/\s+/g, '')}.com`,
    description: `${name} is a growing company providing innovative solutions to businesses. They are actively looking to scale their sales operations and improve deal visibility across their pipeline.`,
    services: ['Core Business Services', 'Digital Solutions', 'Consulting', 'Technology Integration', 'Customer Support'],
    clients: [
      { name: 'Client A', role: 'Partner', feedback: `${name} delivered excellent results for our business.` },
      { name: 'Client B', role: 'Customer', feedback: 'Professional team with great attention to detail.' },
    ],
    dealValue: 99,
    dealStage: 'Prospecting',
    winProbability: Math.floor(Math.random() * 40) + 30,
    closeDate: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    signals: [
      { type: 'Website Visit', source: 'Web Analytics', date: new Date().toISOString().split('T')[0] },
      { type: 'Contact Form Submitted', source: 'Website', date: new Date().toISOString().split('T')[0] },
    ],
    insights: [
      { type: 'Next Best Action', text: `Reach out to ${name} with a personalised demo offer. They recently visited your pricing page.`, impact: 25000 },
      { type: 'Engagement Spike', text: `${name} has shown interest. Follow up within 24 hours for best conversion rate.`, impact: 18000 },
    ],
  }
}

interface CompanyState {
  currentCompany: string
  companyData: CompanyData | null
  loading: boolean
  setCompany: (name: string) => Promise<void>
  clearCompany: () => void
}

export const useCompanyStore = create<CompanyState>((set) => ({
  currentCompany: 'Digital Solution AI',
  companyData: COMPANY_PROFILES['digital solution ai'],
  loading: false,

  setCompany: async (name: string) => {
    set({ loading: true, currentCompany: name })
    // Simulate a brief fetch delay
    await new Promise((r) => setTimeout(r, 800))
    const key = name.toLowerCase().trim()
    const data = COMPANY_PROFILES[key] || generateProfile(name)
    set({ companyData: data, loading: false })
  },

  clearCompany: () => set({ currentCompany: '', companyData: null }),
}))
