import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface UIState {
  darkMode: boolean
  wsStatus: 'connected' | 'reconnecting' | 'disconnected'
  toggleDarkMode: () => void
  setWsStatus: (status: 'connected' | 'reconnecting' | 'disconnected') => void
}

export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      darkMode: false,
      wsStatus: 'connected',
      toggleDarkMode: () =>
        set((state) => {
          const next = !state.darkMode
          if (next) {
            document.documentElement.classList.add('dark')
          } else {
            document.documentElement.classList.remove('dark')
          }
          return { darkMode: next }
        }),
      setWsStatus: (status) => set({ wsStatus: status }),
    }),
    { name: 'ui-prefs' }
  )
)

// Apply dark mode on initial load
const stored = localStorage.getItem('ui-prefs')
if (stored) {
  try {
    const parsed = JSON.parse(stored)
    if (parsed?.state?.darkMode) {
      document.documentElement.classList.add('dark')
    }
  } catch {}
}
