import axios, { AxiosInstance, AxiosError } from 'axios'
import {
  mockDeals,
  mockForecasts,
  mockInsights,
  mockBillingInfo,
  getMockPredictionsForDeal,
  getMockPipelineView,
  getMockFunnelData,
  getMockHeatmapData,
  Deal,
  Forecast,
  Insight,
  BillingInfo,
  Prediction,
} from './mockData'

// API client configuration — relative URL goes through Vite proxy in dev,
// and works with same-origin deployment in production.
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? '/api'

class ApiClient {
  private client: AxiosInstance
  private mockMode = false // set to true to use in-memory mock data

  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
      },
    })

    // Add request interceptor for auth token
    this.client.interceptors.request.use((config) => {
      const token = localStorage.getItem('token')
      if (token) {
        config.headers.Authorization = `Bearer ${token}`
      }
      return config
    })

    // Add response interceptor for error handling
    this.client.interceptors.response.use(
      (response) => response,
      (error: AxiosError) => {
        if (error.response?.status === 401) {
          // Handle unauthorized - redirect to login
          localStorage.removeItem('token')
          window.location.href = '/login'
        }
        return Promise.reject(error)
      }
    )
  }

  // ============ AUTHENTICATION ============

  async signup(email: string, password: string, fullName: string, company?: string) {
    const response = await this.client.post('/v1/auth/signup', {
      email,
      password,
      fullName,
      company,
    })
    if (response.data.token) {
      localStorage.setItem('token', response.data.token)
      localStorage.setItem('user', JSON.stringify(response.data.user))
    }
    return response.data
  }

  async login(email: string, password: string) {
    const response = await this.client.post('/v1/auth/login', {
      email,
      password,
    })
    if (response.data.token) {
      localStorage.setItem('token', response.data.token)
      localStorage.setItem('user', JSON.stringify(response.data.user))
    }
    return response.data
  }

  async forgotPassword(email: string) {
    const response = await this.client.post('/v1/auth/forgot-password', { email })
    return response.data
  }

  async resetPassword(resetToken: string, newPassword: string) {
    const response = await this.client.post('/v1/auth/reset-password', {
      resetToken,
      newPassword,
    })
    return response.data
  }

  async validatePassword(password: string) {
    const response = await this.client.post('/v1/auth/validate-password', { password })
    return response.data
  }

  async changePassword(email: string, currentPassword: string, newPassword: string) {
    const response = await this.client.post('/v1/auth/change-password', { email, currentPassword, newPassword })
    return response.data
  }

  // ============ PAYMENT ============

  async createPaymentSession(email: string, tier: string, amount: number) {
    const response = await this.client.post('/v1/billing/payment-session', {
      email,
      tier,
      amount,
    })
    return response.data
  }

  async processPayment(sessionId: string, cardToken: string, cardDetails: any) {
    const response = await this.client.post('/v1/billing/process-payment', {
      sessionId,
      cardToken,
      cardDetails,
    })
    return response.data
  }

  async getPaymentSession(sessionId: string) {
    const response = await this.client.get(`/v1/billing/payment-session/${sessionId}`)
    return response.data
  }

  // ============ USER PROFILE ============

  async updateProfile(data: any) {
    const response = await this.client.put('/v1/profile', data)
    return response.data
  }

  async inviteUser(data: any) {
    const response = await this.client.post('/v1/admin/users/invite', data)
    return response.data
  }

  async createAPIKey(data: any) {
    const response = await this.client.post('/v1/api-keys', data)
    return response.data
  }

  async getNotifications() {
    if (this.mockMode) {
      return [
        { id: '1', type: 'deal_alert', message: 'Acme Corp deal probability dropped to 25%', read: false, createdAt: new Date().toISOString() },
        { id: '2', type: 'insight', message: 'New insight: TechVision deal stalled for 14 days', read: false, createdAt: new Date(Date.now() - 3600000).toISOString() },
        { id: '3', type: 'forecast', message: 'Q2 forecast generated: $2.5M projected', read: true, createdAt: new Date(Date.now() - 86400000).toISOString() },
        { id: '4', type: 'billing', message: 'Invoice generated for April 2024', read: true, createdAt: new Date(Date.now() - 172800000).toISOString() },
      ]
    }
    const response = await this.client.get('/v1/notifications')
    return response.data
  }

  async markNotificationsRead() {
    if (this.mockMode) return { success: true }
    const response = await this.client.put('/v1/notifications/read-all')
    return response.data
  }

  // ============ DATA PRIVACY (GDPR/CCPA) ============

  async requestDataExport() {
    if (this.mockMode) return { success: true, message: 'Export request submitted. You will receive an email within 72 hours.' }
    const response = await this.client.post('/v1/admin/data-export')
    return response.data
  }

  async requestDataDeletion() {
    if (this.mockMode) return { success: true, message: 'Deletion scheduled within 30 days.' }
    const response = await this.client.post('/v1/admin/data-delete')
    return response.data
  }

  // ============ DEALS ============

  async getDeals(): Promise<Deal[]> {
    if (this.mockMode) {
      return new Promise((resolve) => {
        setTimeout(() => resolve(mockDeals), 300)
      })
    }
    const response = await this.client.get('/v1/deals')
    return response.data
  }

  async getDealById(id: string): Promise<Deal> {
    if (this.mockMode) {
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          const deal = mockDeals.find((d) => d.id === id)
          if (deal) {
            resolve(deal)
          } else {
            reject(new Error('Deal not found'))
          }
        }, 200)
      })
    }
    const response = await this.client.get(`/v1/deals/${id}`)
    return response.data
  }

  async createDeal(deal: Partial<Deal>): Promise<Deal> {
    if (this.mockMode) {
      return new Promise((resolve) => {
        setTimeout(() => {
          const newDeal: Deal = {
            id: `deal-${Date.now()}`,
            name: deal.name || 'New Deal',
            value: deal.value || 0,
            stage: deal.stage || 'Prospecting',
            winProbability: 25,
            closeDate: deal.closeDate || new Date().toISOString(),
            accountName: deal.accountName || '',
            contact: deal.contact || '',
            email: deal.email || '',
            phone: deal.phone || '',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            signals: [],
          }
          mockDeals.push(newDeal)
          resolve(newDeal)
        }, 300)
      })
    }
    const response = await this.client.post('/v1/deals', deal)
    return response.data
  }

  async updateDeal(id: string, deal: Partial<Deal>): Promise<Deal> {
    if (this.mockMode) {
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          const index = mockDeals.findIndex((d) => d.id === id)
          if (index !== -1) {
            mockDeals[index] = { ...mockDeals[index], ...deal, updatedAt: new Date().toISOString() }
            resolve(mockDeals[index])
          } else {
            reject(new Error('Deal not found'))
          }
        }, 200)
      })
    }
    const response = await this.client.put(`/v1/deals/${id}`, deal)
    return response.data
  }

  async deleteDeal(id: string): Promise<void> {
    if (this.mockMode) {
      return new Promise((resolve) => {
        setTimeout(() => {
          const index = mockDeals.findIndex((d) => d.id === id)
          if (index !== -1) {
            mockDeals.splice(index, 1)
          }
          resolve()
        }, 200)
      })
    }
    await this.client.delete(`/v1/deals/${id}`)
  }

  // ============ PIPELINE ============

  async getPipeline() {
    if (this.mockMode) {
      return new Promise((resolve) => {
        setTimeout(() => resolve(getMockPipelineView()), 300)
      })
    }
    const response = await this.client.get('/v1/pipeline')
    return response.data
  }

  async getPipelineFunnel() {
    if (this.mockMode) {
      return new Promise((resolve) => {
        setTimeout(() => resolve(getMockFunnelData()), 200)
      })
    }
    const response = await this.client.get('/v1/pipeline/funnel')
    return response.data
  }

  async getPipelineHeatmap() {
    if (this.mockMode) {
      return new Promise((resolve) => {
        setTimeout(() => resolve(getMockHeatmapData()), 200)
      })
    }
    const response = await this.client.get('/v1/pipeline/heatmap')
    return response.data
  }

  // ============ PREDICTIONS ============

  async getPredictionsForDeal(dealId: string): Promise<Prediction[]> {
    if (this.mockMode) {
      return new Promise((resolve) => {
        setTimeout(() => resolve(getMockPredictionsForDeal(dealId)), 200)
      })
    }
    const response = await this.client.get(`/v1/deals/${dealId}/predictions`)
    return response.data
  }

  // ============ FORECASTS ============

  async getForecasts(): Promise<Forecast[]> {
    if (this.mockMode) {
      return new Promise((resolve) => {
        setTimeout(() => resolve(mockForecasts), 300)
      })
    }
    const response = await this.client.get('/v1/forecasts')
    return response.data
  }

  async getForecastById(id: string): Promise<Forecast> {
    if (this.mockMode) {
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          const forecast = mockForecasts.find((f) => f.id === id)
          if (forecast) {
            resolve(forecast)
          } else {
            reject(new Error('Forecast not found'))
          }
        }, 200)
      })
    }
    const response = await this.client.get(`/v1/forecasts/${id}`)
    return response.data
  }

  async exportForecast(id: string, format: 'csv' | 'json' = 'csv'): Promise<Blob> {
    if (this.mockMode) {
      return new Promise((resolve) => {
        setTimeout(() => {
          const forecast = mockForecasts.find((f) => f.id === id)
          const data = format === 'csv' ? this.convertToCsv([forecast]) : JSON.stringify([forecast])
          resolve(new Blob([data], { type: format === 'csv' ? 'text/csv' : 'application/json' }))
        }, 200)
      })
    }
    const response = await this.client.get(`/v1/forecasts/${id}?format=${format}`, {
      responseType: 'blob',
    })
    return response.data
  }

  // ============ INSIGHTS ============

  async getInsights(): Promise<Insight[]> {
    if (this.mockMode) {
      return new Promise((resolve) => {
        setTimeout(() => resolve(mockInsights.filter((i) => i.status !== 'dismissed')), 300)
      })
    }
    const response = await this.client.get('/v1/insights')
    return response.data
  }

  async actOnInsight(id: string): Promise<Insight> {
    if (this.mockMode) {
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          const insight = mockInsights.find((i) => i.id === id)
          if (insight) {
            insight.status = 'acted'
            resolve(insight)
          } else {
            reject(new Error('Insight not found'))
          }
        }, 200)
      })
    }
    const response = await this.client.put(`/v1/insights/${id}/act`)
    return response.data
  }

  async dismissInsight(id: string): Promise<Insight> {
    if (this.mockMode) {
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          const insight = mockInsights.find((i) => i.id === id)
          if (insight) {
            insight.status = 'dismissed'
            insight.dismissedUntil = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
            resolve(insight)
          } else {
            reject(new Error('Insight not found'))
          }
        }, 200)
      })
    }
    const response = await this.client.put(`/v1/insights/${id}/dismiss`)
    return response.data
  }

  // ============ BILLING ============

  async getBillingInfo(): Promise<BillingInfo> {
    if (this.mockMode) {
      return new Promise((resolve) => {
        setTimeout(() => resolve(mockBillingInfo), 300)
      })
    }
    const response = await this.client.get('/v1/billing')
    return response.data
  }

  async updateBillingTier(newTier: string): Promise<BillingInfo> {
    if (this.mockMode) {
      return new Promise((resolve) => {
        setTimeout(() => {
          mockBillingInfo.currentTier = newTier as any
          resolve(mockBillingInfo)
        }, 300)
      })
    }
    const response = await this.client.put('/v1/billing/tier', { newTier })
    return response.data
  }

  // ============ UTILITIES ============

  private convertToCsv(data: any[]): string {
    if (!data || data.length === 0) return ''

    const headers = Object.keys(data[0])
    const rows = data.map((item) => headers.map((header) => JSON.stringify(item[header])).join(','))

    return [headers.join(','), ...rows].join('\n')
  }

  // Enable/disable mock mode
  setMockMode(enabled: boolean) {
    this.mockMode = enabled
  }
}

export const apiClient = new ApiClient()
