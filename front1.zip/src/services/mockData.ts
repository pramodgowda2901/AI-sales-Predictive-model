// Mock data service with realistic sample data for the AI Sales Predictive Management platform

export interface Deal {
  id: string
  name: string
  value: number
  stage: string
  winProbability: number
  closeDate: string
  accountName: string
  contact: string
  email: string
  phone: string
  createdAt: string
  updatedAt: string
  signals: Signal[]
}

export interface Signal {
  id: string
  dealId: string
  type: string
  value: string
  timestamp: string
  source: string
}

export interface Prediction {
  id: string
  dealId: string
  winProbability: number
  confidenceLow: number
  confidenceHigh: number
  topFactors: string[]
  computedAt: string
}

export interface Forecast {
  id: string
  horizon: 'weekly' | 'monthly' | 'quarterly'
  projectedValue: number
  confidenceLow: number
  confidenceHigh: number
  periodStart: string
  periodEnd: string
  createdAt: string
}

export interface Insight {
  id: string
  dealId: string
  type: string
  text: string
  revenueImpact: number
  status: 'active' | 'acted' | 'dismissed'
  dismissedUntil?: string
  createdAt: string
}

export interface BillingInfo {
  currentTier: 'starter' | 'growth' | 'enterprise'
  monthlyPrice: number
  nextBillingDate: string
  status: 'active' | 'past_due' | 'cancelled'
  usageMetrics: {
    apiRequests: number
    predictions: number
    users: number
    deals: number
  }
  tierLimits: {
    maxUsers: number
    maxDeals: number
    maxApiRequests: number
  }
}

const stages = ['Prospecting', 'Qualification', 'Proposal', 'Negotiation', 'Closed Won']
const companies = [
  'Acme Corp',
  'TechVision Inc',
  'Global Solutions',
  'Digital Dynamics',
  'CloudFirst Systems',
  'DataFlow Analytics',
  'NextGen Software',
  'Enterprise Plus',
  'Innovation Labs',
  'Future Tech',
  'Smart Systems',
  'Quantum Computing',
  'AI Solutions',
  'Cloud Native',
  'DevOps Pro',
  'Security First',
  'Analytics Hub',
  'Integration Plus',
  'Automation Works',
  'Digital Transform',
]

const contacts = [
  'John Smith',
  'Sarah Johnson',
  'Michael Chen',
  'Emily Davis',
  'Robert Wilson',
  'Jessica Martinez',
  'David Brown',
  'Lisa Anderson',
  'James Taylor',
  'Maria Garcia',
  'Christopher Lee',
  'Amanda White',
  'Daniel Harris',
  'Rachel Clark',
  'Kevin Martin',
]

const signalTypes = [
  'Email Opened',
  'Link Clicked',
  'Demo Attended',
  'Proposal Viewed',
  'Call Scheduled',
  'Document Downloaded',
  'Website Visit',
  'Pricing Page View',
  'Feature Demo',
  'Contract Review',
]

const insightTypes = [
  'Stalled Deal',
  'High Win Probability',
  'Engagement Spike',
  'Competitor Mention',
  'Budget Concern',
  'Timeline Risk',
  'Next Best Action',
  'Upsell Opportunity',
]

function getRandomItem<T>(array: T[]): T {
  return array[Math.floor(Math.random() * array.length)]
}

function getRandomNumber(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

function getRandomDate(daysAgo: number = 90): string {
  const date = new Date()
  date.setDate(date.getDate() - getRandomNumber(0, daysAgo))
  return date.toISOString()
}

function getRandomFutureDate(daysAhead: number = 90): string {
  const date = new Date()
  date.setDate(date.getDate() + getRandomNumber(1, daysAhead))
  return date.toISOString()
}

export function generateMockDeals(count: number = 25): Deal[] {
  const deals: Deal[] = []

  for (let i = 1; i <= count; i++) {
    const stage = getRandomItem(stages)
    const createdAt = getRandomDate(180)
    const winProbability = stage === 'Closed Won' ? 100 : stage === 'Prospecting' ? getRandomNumber(5, 25) : getRandomNumber(25, 85)

    deals.push({
      id: `deal-${i}`,
      name: `${getRandomItem(companies)} - ${getRandomNumber(10, 500)}k Deal`,
      value: getRandomNumber(50000, 500000),
      stage,
      winProbability,
      closeDate: getRandomFutureDate(120),
      accountName: getRandomItem(companies),
      contact: getRandomItem(contacts),
      email: `contact${i}@example.com`,
      phone: `+1-555-${getRandomNumber(100, 999)}-${getRandomNumber(1000, 9999)}`,
      createdAt,
      updatedAt: getRandomDate(30),
      signals: generateMockSignals(`deal-${i}`, getRandomNumber(3, 8)),
    })
  }

  return deals
}

export function generateMockSignals(dealId: string, count: number = 5): Signal[] {
  const signals: Signal[] = []

  for (let i = 1; i <= count; i++) {
    signals.push({
      id: `signal-${dealId}-${i}`,
      dealId,
      type: getRandomItem(signalTypes),
      value: `Signal value ${i}`,
      timestamp: getRandomDate(30),
      source: getRandomItem(['Email', 'Website', 'CRM', 'Calendar', 'Document']),
    })
  }

  return signals
}

export function generateMockPredictions(dealId: string, count: number = 12): Prediction[] {
  const predictions: Prediction[] = []
  let baseProb = getRandomNumber(20, 80)

  for (let i = 1; i <= count; i++) {
    const variance = getRandomNumber(-15, 15)
    const prob = Math.max(0, Math.min(100, baseProb + variance))
    baseProb = prob

    predictions.push({
      id: `prediction-${dealId}-${i}`,
      dealId,
      winProbability: prob,
      confidenceLow: Math.max(0, prob - 15),
      confidenceHigh: Math.min(100, prob + 15),
      topFactors: [
        'Deal Age',
        'Engagement Score',
        'Stage Velocity',
        'Historical Close Rate',
        'Contact Seniority',
      ],
      computedAt: new Date(Date.now() - (count - i) * 7 * 24 * 60 * 60 * 1000).toISOString(),
    })
  }

  return predictions
}

export function generateMockForecasts(count: number = 12): Forecast[] {
  const forecasts: Forecast[] = []
  const now = new Date()

  for (let i = 0; i < count; i++) {
    const periodStart = new Date(now.getFullYear(), now.getMonth() + i, 1)
    const periodEnd = new Date(now.getFullYear(), now.getMonth() + i + 1, 0)
    const baseValue = getRandomNumber(500000, 2000000)
    const variance = getRandomNumber(-100000, 100000)

    forecasts.push({
      id: `forecast-${i}`,
      horizon: i < 4 ? 'weekly' : i < 8 ? 'monthly' : 'quarterly',
      projectedValue: baseValue + variance,
      confidenceLow: baseValue + variance - 150000,
      confidenceHigh: baseValue + variance + 150000,
      periodStart: periodStart.toISOString(),
      periodEnd: periodEnd.toISOString(),
      createdAt: new Date().toISOString(),
    })
  }

  return forecasts
}

export function generateMockInsights(deals: Deal[], count: number = 15): Insight[] {
  const insights: Insight[] = []

  for (let i = 1; i <= count; i++) {
    const deal = getRandomItem(deals)
    const type = getRandomItem(insightTypes)
    const revenueImpact = getRandomNumber(10000, 200000)

    insights.push({
      id: `insight-${i}`,
      dealId: deal.id,
      type,
      text: `${type} detected for ${deal.name}. Recommended action: ${getRandomItem(['Schedule follow-up call', 'Send proposal', 'Check in with stakeholder', 'Review pricing', 'Escalate to manager'])}`,
      revenueImpact,
      status: getRandomItem(['active', 'active', 'active', 'acted', 'dismissed']),
      createdAt: getRandomDate(30),
    })
  }

  return insights.sort((a, b) => b.revenueImpact - a.revenueImpact)
}

export function generateMockBillingInfo(): BillingInfo {
  const tier = getRandomItem(['starter', 'growth', 'enterprise'] as const)
  const tierConfig = {
    starter: { price: 99, maxUsers: 5, maxDeals: 100, maxApiRequests: 10000 },
    growth: { price: 299, maxUsers: 25, maxDeals: 1000, maxApiRequests: 100000 },
    enterprise: { price: 999, maxUsers: 999, maxDeals: 999999, maxApiRequests: 1000000 },
  }

  const config = tierConfig[tier]

  return {
    currentTier: tier,
    monthlyPrice: config.price,
    nextBillingDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'active',
    usageMetrics: {
      apiRequests: getRandomNumber(1000, config.maxApiRequests * 0.8),
      predictions: getRandomNumber(100, 5000),
      users: getRandomNumber(1, config.maxUsers),
      deals: getRandomNumber(10, Math.min(config.maxDeals, 500)),
    },
    tierLimits: {
      maxUsers: config.maxUsers,
      maxDeals: config.maxDeals,
      maxApiRequests: config.maxApiRequests,
    },
  }
}

// Generate all mock data
export const mockDeals = generateMockDeals(25)
export const mockForecasts = generateMockForecasts(12)
export const mockInsights = generateMockInsights(mockDeals, 15)
export const mockBillingInfo = generateMockBillingInfo()

// Helper to get predictions for a specific deal
export function getMockPredictionsForDeal(dealId: string): Prediction[] {
  return generateMockPredictions(dealId, 12)
}

// Helper to get pipeline view (deals grouped by stage)
export function getMockPipelineView() {
  return stages.map((stage) => ({
    stage,
    deals: mockDeals.filter((d) => d.stage === stage),
    totalValue: mockDeals
      .filter((d) => d.stage === stage)
      .reduce((sum, d) => sum + d.value, 0),
    dealCount: mockDeals.filter((d) => d.stage === stage).length,
  }))
}

// Helper to get funnel data
export function getMockFunnelData() {
  return stages.map((stage) => {
    const stageDeal = mockDeals.filter((d) => d.stage === stage)
    return {
      stage,
      value: stageDeal.reduce((sum, d) => sum + d.value, 0),
      count: stageDeal.length,
    }
  })
}

// Helper to get heatmap data (users vs stages)
export function getMockHeatmapData() {
  const users = ['Alice Johnson', 'Bob Smith', 'Carol White', 'David Brown', 'Emma Davis']
  return users.map((user) => ({
    user,
    stages: stages.map((stage) => ({
      stage,
      probability: getRandomNumber(20, 90),
      dealCount: getRandomNumber(1, 5),
    })),
  }))
}
