import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from 'react-query'
import Layout from './components/Layout'
import LoginPage from './pages/LoginPage'
import SignupPage from './pages/SignupPage'
import ForgotPasswordPage from './pages/ForgotPasswordPage'
import DealListPage from './pages/DealListPage'
import DealDetailPage from './pages/DealDetailPage'
import PipelinePage from './pages/PipelinePage'
import ForecastPage from './pages/ForecastPage'
import InsightsPage from './pages/InsightsPage'
import BillingPage from './pages/BillingPage'
import SettingsPage from './pages/SettingsPage'
import AdminPage from './pages/AdminPage'
import AnalyticsPage from './pages/AnalyticsPage'
import APIKeysPage from './pages/APIKeysPage'
import OnboardingPage from './pages/OnboardingPage'
import EmailPreferencesPage from './pages/EmailPreferencesPage'
import SuperAdminPage from './pages/SuperAdminPage'
import LandingPage from './pages/LandingPage'
import DataPrivacyPage from './pages/DataPrivacyPage'
import CRMIntegrationPage from './pages/CRMIntegrationPage'
import ReportsPage from './pages/ReportsPage'
import CompanyProfilePage from './pages/CompanyProfilePage'
import SalesPredictionPage from './pages/SalesPredictionPage'
import { useAuthStore } from './store/authStore'

const queryClient = new QueryClient()

function App() {
  const { isAuthenticated } = useAuthStore()

  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <Routes>
          {/* / always shows landing page — regardless of auth state */}
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/signup" element={<SignupPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          {isAuthenticated ? (
            <Route element={<Layout />}>
              <Route path="/dashboard" element={<Navigate to="/pipeline" replace />} />
              <Route path="/deals" element={<DealListPage />} />
              <Route path="/deals/:id" element={<DealDetailPage />} />
              <Route path="/pipeline" element={<PipelinePage />} />
              <Route path="/forecasts" element={<ForecastPage />} />
              <Route path="/insights" element={<InsightsPage />} />
              <Route path="/analytics" element={<AnalyticsPage />} />
              <Route path="/billing" element={<BillingPage />} />
              <Route path="/settings" element={<SettingsPage />} />
              <Route path="/admin" element={<AdminPage />} />
              <Route path="/api-keys" element={<APIKeysPage />} />
              <Route path="/onboarding" element={<OnboardingPage />} />
              <Route path="/email-preferences" element={<EmailPreferencesPage />} />
              <Route path="/super-admin" element={<SuperAdminPage />} />
              <Route path="/data-privacy" element={<DataPrivacyPage />} />
              <Route path="/crm-integrations" element={<CRMIntegrationPage />} />
              <Route path="/reports" element={<ReportsPage />} />
              <Route path="/company/:name" element={<CompanyProfilePage />} />
              <Route path="/company" element={<CompanyProfilePage />} />
              <Route path="/sales-prediction" element={<SalesPredictionPage />} />
              <Route path="/notifications" element={<Navigate to="/settings" replace />} />
            </Route>
          ) : (
            <Route path="*" element={<Navigate to="/" replace />} />
          )}
        </Routes>
      </Router>
    </QueryClientProvider>
  )
}

export default App
